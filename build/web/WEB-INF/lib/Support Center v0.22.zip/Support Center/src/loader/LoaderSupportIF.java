/*
 v 0.16
 - Added
 */

package loader;

import eservicesmanager.SupportCenter;
import feedback.AgedFeedbackIF;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JDialog;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.Result;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.task.CustomTask;
import net.neoremind.sshxcute.task.impl.ExecCommand;

public class LoaderSupportIF extends JInternalFrame {
    
   private String PRD_SERVER = "cintrnesvapp001.trans.ge.com";    
   private String PRD_USER = "lg159775";
   private String PRD_PASSWORD = "P@55w0rd";
   private SupportCenter parent;
   private SimpleDateFormat dateFormatter;
   private StringBuffer buf;
   private boolean done;
   private int days;
   private boolean resultsFound;
   private ImageIcon iiRed;
   private ImageIcon iiGreen;
   private ImageIcon iiGrey;
   private ImageIcon iiDoc;      
   
   private JPopupMenu popMenu;
   private String selectedLoader;
   
   private JMenuItem miLog;
   private JMenuItem miDoc;
      
   //B2B Constants
   private final String T107_INBOUND = "T107 Inbound";
   private final String T1_T3_INBOUND = "T1 T3 Inbound";
   private final String CP_T3_INBOUND = "CP T3 Inbound";
   private final String M_T102_INBOUND = "CP/UP T102 Inbound";
   private final String W_T102_INBOUND = "BNSF T102 Inbound";   
   private final String T3_INBOUND = "T3 CSX Inbound";
   private final String MAT_T151 = "T151 Materials";
   private final String T7_INBOUND = "T7 Inbound";
   private final String ESTP_RMD = "eSTP RMD";
   private final String CSX_T103 = "CSX T103";   
   
   //eServices constants
   private final String LITE_TOOL_SERVER = "Lite Tool Server";
   private final String EVO_SERVER = "EVO Server";
   private final String EGU_TOOL_SERVER = "EGU Tool Server";
   private final String LTB_LOADER = "LTB Loader";
   private final String XML_GENERATOR = "XML Generator";
   private final String REC_TOOL_SERVER = "REC Tool Server";
   private final String EVO_DPK_SERVER = "EVO DPK Server";
   private final String EVO_MATCHER = "EVO Matcher";
   private final String EWG_LOADER = "EWG Loader";
   private final String CBM_LOADER = "CBM Loader";
   private final String INCIDENT_LOADER = "Incident Loader";
   private final String SNAPSHOT_LOADER = "Snapshot Loader";   
   private final String CCA_XML_SENDER = "CCA XML Sender";
   private final String BS_LOADER = "BS Loader";
   private final String EVO_MONITOR = "EVO Monitor";

    public LoaderSupportIF(final JDesktopPane desktop, SupportCenter parent, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);          
     this.parent = parent;
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearchEServices);
     
     /* Set up the contextual menu */
     popMenu = new JPopupMenu("Loader Menu");
     miLog = new JMenuItem("Check Log");
     miLog.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent e) {           
           fetchLoaderLog();
       }
     });
     popMenu.add(miLog);
 
     miDoc = new JMenuItem("View Documentation");
     miDoc.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent e) {
            fetchLoaderDoc();
       }
     });
     popMenu.add(miDoc);     
     /*************************************/
     
     buf = new StringBuffer();
                    
     dateFormatter = new SimpleDateFormat("HH:mm");
     try {
        BufferedImage imgRed = ImageIO.read(getClass().getResource("/util/resources/red_button.png"));
        BufferedImage imgGreen = ImageIO.read(getClass().getResource("/util/resources/green_button.png"));
        BufferedImage imgGrey = ImageIO.read(getClass().getResource("/util/resources/grey_button.png"));
        BufferedImage imgDoc = ImageIO.read(getClass().getResource("/util/resources/doc_icon.png"));
        Image imageRedButton = imgRed.getScaledInstance(32, 32, Image.SCALE_SMOOTH); 
        Image imageGreenButton = imgGreen.getScaledInstance(32, 32, Image.SCALE_SMOOTH); 
        Image imageGreyButton = imgGrey.getScaledInstance(32, 32, Image.SCALE_SMOOTH); 
        Image imageDocIcon = imgDoc.getScaledInstance(20, 20, Image.SCALE_SMOOTH); 
        iiRed = new ImageIcon(imageRedButton);  
        iiGreen = new ImageIcon(imageGreenButton);  
        iiGrey = new ImageIcon(imageGreyButton);
        iiDoc = new ImageIcon(imageDocIcon);

        prepareButtons();        
        
     } catch(Exception e){
         System.out.println("BOOM!");
     }

     done = false;
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { LoaderSupportIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
     areaLogEServices.setText("Initializing...");
     probeLoaders();
   }
   
   private void prepareButtons(){
       //eServices buttons
       lblEVOServerImg.setIcon(iiGrey);
       lblLiteToolImg.setIcon(iiGrey);
       lblEGUToolServerImg.setIcon(iiGrey);
       lblEWGLoaderImg.setIcon(iiGrey);
       lblXMLGeneratorImg.setIcon(iiGrey);
       lblRECToolServerImg.setIcon(iiGrey);
       lblEVODPKServerImg.setIcon(iiGrey);
       lblEVOMatcherImg.setIcon(iiGrey);
       lblLTBLoaderImg.setIcon(iiGrey);
       lblCBMLoaderImg.setIcon(iiGrey);
       lblSnapshotLoaderImg.setIcon(iiGrey);
       lblEVOMonitorImg.setIcon(iiGrey);
       lblCCXMLSenderImg.setIcon(iiGrey);
       lblBSLoaderImg.setIcon(iiGrey);
       lblIncidentLoaderImg.setIcon(iiGrey);

       //B2B Buttons
       lblMT102Inbound.setIcon(iiGrey);
       lblT1T3Inbound.setIcon(iiGrey);
       lblWT102Inbound.setIcon(iiGrey);
       lblT7Processor.setIcon(iiGrey);
       lblCPT3Inbound.setIcon(iiGrey);
       lblMaterialT151.setIcon(iiGrey);
       lblRMDMain.setIcon(iiGrey);
       lblT107Inbound.setIcon(iiGrey);
       lblT3Inbound.setIcon(iiGrey);
       lblT103InboundImg.setIcon(iiGrey);
       
       //eServices Documentation - Set the Icons
       lblRecToolServerDoc.setText("");
       lblRecToolServerDoc.setIcon(iiDoc);
       lblEGUToolServerDoc.setText("");
       lblEGUToolServerDoc.setIcon(iiDoc);
       lblEVOServerDoc.setText("");
       lblEVOServerDoc.setIcon(iiDoc);
       lblIncidentLoaderDoc.setText("");
       lblIncidentLoaderDoc.setIcon(iiDoc);
       lblSnapshotLoaderDoc.setText("");
       lblSnapshotLoaderDoc.setIcon(iiDoc);
       lblCBMLoaderDoc.setText("");
       lblCBMLoaderDoc.setIcon(iiDoc);
       lblCCXMLSenderDoc.setText("");
       lblCCXMLSenderDoc.setIcon(iiDoc);
       lblEVOMonitorDoc.setText("");
       lblEVOMonitorDoc.setIcon(iiDoc);
       lblXMLGeneratorDoc.setText("");
       lblXMLGeneratorDoc.setIcon(iiDoc);
       lblLTBLoaderDoc.setText("");
       lblLTBLoaderDoc.setIcon(iiDoc);
       lblEVODPKServerDoc.setText("");
       lblEVODPKServerDoc.setIcon(iiDoc);
       lblLiteToolDoc.setText("");
       lblLiteToolDoc.setIcon(iiDoc);
       
       editorResultsEServices.setText("<HTML><H3>Right click on each loader's button for options.</H3><HTML>");
       editorResultsB2B.setText("<HTML><H3>Right click on each loader's button for options.</H3><HTML>");
   } 
    
   private void cleanClose() {
     dispose();
   }

   private void protectFields(){
       btnSearchEServices.setEnabled(false);
       btnSearchB2B.setEnabled(false);
       miDoc.setEnabled(false);
       miLog.setEnabled(false);
       
   }
   
   private void releaseFields(){
       btnSearchEServices.setEnabled(true);
       btnSearchB2B.setEnabled(true);
       miDoc.setEnabled(true);
       miLog.setEnabled(true);       
   }
   
   private void probeLoaders() { new Thread(new Runnable() {
       public void run() {
         populateLoaderData();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
           }
         });
       }
     }).start(); 
   }   
   
   private void populateLoaderData(){
       
        protectFields();
        
        SSHExec ssh;

        // Initialize a ConnBean object, parameter list is ip, username, password
        ConnBean cb = new ConnBean(PRD_SERVER, PRD_USER, PRD_PASSWORD);
        
        // Put the ConnBean instance as parameter for SSHExec static method getInstance(ConnBean) to retrieve a singleton SSHExec instance        
        ssh = SSHExec.getInstance(cb);          
        // Connect to server        
        ssh.connect();        
        log("Probing loader status. Connecting to cintrnesvapp001.trans.ge.com...");
        //CustomTask sampleTask = new ExecCommand("pwd");
        CustomTask sampleTask;
        sampleTask = new ExecCommand("/trnapp/eservices/rmdlite/scripts/chkvcs");
        log("Executing chkvcs...");
        
        Result res;
        try {
            res =  ssh.exec(sampleTask);
            //Probe for loaders
            
            /*************************************** eServices Loaders *******************************/
            //1. Lite Tool Server
            if(res.sysout.contains("LiteToolServer")){     
              lblLiteToolImg.setIcon(iiGreen);
            }  else {
              lblLiteToolImg.setIcon(iiRed);  
            }

            //2. EVO Server
            if(res.sysout.contains("EVOServer")){     
              lblEVOServerImg.setIcon(iiGreen);
            }  else {
              lblEVOServerImg.setIcon(iiRed);  
            }
            
            //3. EGU Tool Server
            if(res.sysout.contains("EGUToolServer")){     
              lblEGUToolServerImg.setIcon(iiGreen);
            }  else {
              lblEGUToolServerImg.setIcon(iiRed);  
            }
            
            //4. LTB Loader
            if(res.sysout.contains("LTBLoader")){     
              lblLTBLoaderImg.setIcon(iiGreen);
            }  else {
              lblLTBLoaderImg.setIcon(iiRed);  
            }
            
            //5. XML Generator
            if(res.sysout.contains("XMLGenerator")){     
              lblXMLGeneratorImg.setIcon(iiGreen);
            }  else {
              lblXMLGeneratorImg.setIcon(iiRed);  
            }
            
            //6. REC Tool Server
            if(res.sysout.contains("RECToolServer")){     
              lblRECToolServerImg.setIcon(iiGreen);
            }  else {
              lblRECToolServerImg.setIcon(iiRed);  
            }
            
            //7. EVO DPK Server
            if(res.sysout.contains("EVODPKServer")){     
              lblEVODPKServerImg.setIcon(iiGreen);
            }  else {
              lblEVODPKServerImg.setIcon(iiRed);  
            }
            
            //8. EVO Matcher
            if(res.sysout.contains("EVOMatcher")){     
              lblEVOMatcherImg.setIcon(iiGreen);
            }  else {
              lblEVOMatcherImg.setIcon(iiRed);  
            }
            
            //9. EWG Loader Server
            if(res.sysout.contains("EWGLoaderServer")){     
              lblEWGLoaderImg.setIcon(iiGreen);
            }  else {
              lblEWGLoaderImg.setIcon(iiRed);  
            }            

            //10. CBM Loader
            if(res.sysout.contains("CBMLoader")){     
              lblCBMLoaderImg.setIcon(iiGreen);
            }  else {
              lblCBMLoaderImg.setIcon(iiRed);  
            }  

            //11. Incident Loader
            if(res.sysout.contains("IncidentLoader")){     
              lblIncidentLoaderImg.setIcon(iiGreen);
            }  else {
              lblIncidentLoaderImg.setIcon(iiRed);  
            }  

            //12. Snapshot Loader
            if(res.sysout.contains("SnapshotLoader")){     
              lblSnapshotLoaderImg.setIcon(iiGreen);
            }  else {
              lblSnapshotLoaderImg.setIcon(iiRed);  
            }  
            
            //13. CCA XML Sender
            if(res.sysout.contains("CCAXMLSender")){     
              lblCCXMLSenderImg.setIcon(iiGreen);
            }  else {
              lblCCXMLSenderImg.setIcon(iiRed);  
            }  
            
            //14. BS Loader
            if(res.sysout.contains("BSLoader")){     
              lblBSLoaderImg.setIcon(iiGreen);
            }  else {
              lblBSLoaderImg.setIcon(iiRed);  
            }  
            
            //15. EVO Monitoring
            if(res.sysout.contains("EVOMonitoring")){     
              lblEVOMonitorImg.setIcon(iiGreen);
            }  else {
              lblEVOMonitorImg.setIcon(iiRed);  
            }              
            /*************************************** eServices Loaders *******************************/
            
            /*************************************** B2B Loaders *******************************/
            //1. Maintenance T102 Inbound
            if(res.sysout.contains("maintenance.T102_INBNDMain")){     
              lblMT102Inbound.setIcon(iiGreen);
            }  else {
              lblMT102Inbound.setIcon(iiRed);  
            }              

            //2. T1 T3 Inbound
            if(res.sysout.contains("1_T3_Inbound dbprop_T1_T3.properties")){     
              lblT1T3Inbound.setIcon(iiGreen);
            }  else {
              lblT1T3Inbound.setIcon(iiRed);  
            }              

            //3. Workorder T102 Inbound
            if(res.sysout.contains("GETS_T102_INBOUNDMain_S")){     
              lblWT102Inbound.setIcon(iiGreen);
            }  else {
              lblWT102Inbound.setIcon(iiRed);  
            }              

            //4. T7 Processor
            if(res.sysout.contains("T7processor")){     
              lblT7Processor.setIcon(iiGreen);
            }  else {
              lblT7Processor.setIcon(iiRed);  
            }              

            //5. CP T3 Inbound
            if(res.sysout.contains("incidents.Gets_CP_T3_Inbound")){     
              lblCPT3Inbound.setIcon(iiGreen);
            }  else {
              lblCPT3Inbound.setIcon(iiRed);  
            }              

            //6. Material T151
            if(res.sysout.contains("materials.Mat_T151Main")){     
              lblMaterialT151.setIcon(iiGreen);
            }  else {
              lblMaterialT151.setIcon(iiRed);  
            }              

            //7. RMD Main
            if(res.sysout.contains("eSTP.eSTP_RMDMain")){     
              lblRMDMain.setIcon(iiGreen);
            }  else {
              lblRMDMain.setIcon(iiRed);  
            }              

            //8. T107 Inbound
            if(res.sysout.contains("Gets_T107_Inbound")){     
              lblT107Inbound.setIcon(iiGreen);
            }  else {
              lblT107Inbound.setIcon(iiRed);  
            }              

            //9. T3 Inbound
            if(res.sysout.contains("incidents.GETS_T3_INBOUNDMain_S")){     
              lblT3Inbound.setIcon(iiGreen);
            }  else {
              lblT3Inbound.setIcon(iiRed);  
            }                                     
            
            //10. T103 Inbound
            if(res.sysout.contains("GETS_T103_INBOUNDMain")){     
              lblT103InboundImg.setIcon(iiGreen);
            }  else {
              lblT103InboundImg.setIcon(iiRed);  
            }                                        
            /*************************************** B2B Loaders *******************************/
            
            log("Success!");
        }catch(Exception e){
            log("Error, could not connect. Reason: " + (e.getMessage() == null ? "Unable to reach host. Check your network connection." : e.getMessage() ));
            releaseFields();
        }
        
        //5. Disconnect
        ssh.disconnect();       
        releaseFields();
       
   }
  
   private void log(String l){
       areaLogEServices.setText(areaLogEServices.getText() + "\n\n" + dateFormatter.format(Calendar.getInstance().getTime()) + ": " + l);
       areaLogEServices.setCaretPosition(areaLogEServices.getText().length());
       areaLogB2B.setText(areaLogB2B.getText() + "\n\n" + dateFormatter.format(Calendar.getInstance().getTime()) + ": " + l);
       areaLogB2B.setCaretPosition(areaLogB2B.getText().length());       
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tpLoaderSupport = new javax.swing.JTabbedPane();
        paneleServices = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblLiteToolImg = new javax.swing.JLabel();
        lblLiteToolText = new javax.swing.JLabel();
        lblLiteToolDoc = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblEVOServerImg = new javax.swing.JLabel();
        lblEVOServerText = new javax.swing.JLabel();
        lblEVOServerDoc = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblEGUToolServerImg = new javax.swing.JLabel();
        lblEGUToolServerText = new javax.swing.JLabel();
        lblEGUToolServerDoc = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        lblEWGLoaderImg = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lblXMLGeneratorImg = new javax.swing.JLabel();
        lblXMLGeneratorText = new javax.swing.JLabel();
        lblXMLGeneratorDoc = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        lblRECToolServerImg = new javax.swing.JLabel();
        lblRECToolServerText = new javax.swing.JLabel();
        lblRecToolServerDoc = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        lblEVODPKServerImg = new javax.swing.JLabel();
        lblEVODPKServerText = new javax.swing.JLabel();
        lblEVODPKServerDoc = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        lblEVOMatcherImg = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        lblLTBLoaderImg = new javax.swing.JLabel();
        lblLTBLoaderText = new javax.swing.JLabel();
        lblLTBLoaderDoc = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        lblCBMLoaderImg = new javax.swing.JLabel();
        lblCBMLoaderText = new javax.swing.JLabel();
        lblCBMLoaderDoc = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        lblSnapshotLoaderImg = new javax.swing.JLabel();
        lblSnapshotLoaderText = new javax.swing.JLabel();
        lblSnapshotLoaderDoc = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        lblEVOMonitorImg = new javax.swing.JLabel();
        lblEVOMonitorText = new javax.swing.JLabel();
        lblEVOMonitorDoc = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        lblCCXMLSenderImg = new javax.swing.JLabel();
        lblCCXMLSenderText = new javax.swing.JLabel();
        lblCCXMLSenderDoc = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        lblBSLoaderImg = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        lblIncidentLoaderImg = new javax.swing.JLabel();
        lblIncidentLoaderText = new javax.swing.JLabel();
        lblIncidentLoaderDoc = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResultsEServices = new javax.swing.JEditorPane();
        jPanel18 = new javax.swing.JPanel();
        btnSearchEServices = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaLogEServices = new javax.swing.JTextArea();
        panelB2B = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        lblMT102Inbound = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        lblT1T3Inbound = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        lblWT102Inbound = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        lblT7Processor = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        lblCPT3Inbound = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        lblMaterialT151 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        lblRMDMain = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        lblT107Inbound = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        lblT3Inbound = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        btnSearchB2B = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        areaLogB2B = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        editorResultsB2B = new javax.swing.JEditorPane();
        jPanel29 = new javax.swing.JPanel();
        lblT103InboundImg = new javax.swing.JLabel();
        lblT103InboundText = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblLiteToolImg.setText("jLabel1");
        lblLiteToolImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblLiteToolImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblLiteToolImgMouseReleased(evt);
            }
        });

        lblLiteToolText.setText("Lite Tool Server");

        lblLiteToolDoc.setText("jLabel1");
        lblLiteToolDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLiteToolDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLiteToolImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblLiteToolText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblLiteToolDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLiteToolImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLiteToolText)
                    .addComponent(lblLiteToolDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEVOServerImg.setText("jLabel1");
        lblEVOServerImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEVOServerImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEVOServerImgMouseReleased(evt);
            }
        });

        lblEVOServerText.setText("EVO Server");

        lblEVOServerDoc.setText("jLabel2");
        lblEVOServerDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEVOServerDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEVOServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEVOServerText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEVOServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEVOServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEVOServerText)
                    .addComponent(lblEVOServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEGUToolServerImg.setText("jLabel1");
        lblEGUToolServerImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEGUToolServerImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEGUToolServerImgMouseReleased(evt);
            }
        });

        lblEGUToolServerText.setText("EGU Tool Server");

        lblEGUToolServerDoc.setText("jLabel2");
        lblEGUToolServerDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEGUToolServerDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEGUToolServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEGUToolServerText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblEGUToolServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEGUToolServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEGUToolServerText)
                    .addComponent(lblEGUToolServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEWGLoaderImg.setText("jLabel1");
        lblEWGLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEWGLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEWGLoaderImgMouseReleased(evt);
            }
        });

        jLabel10.setText("EWG Loader");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEWGLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEWGLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblXMLGeneratorImg.setText("jLabel1");
        lblXMLGeneratorImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblXMLGeneratorImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblXMLGeneratorImgMouseReleased(evt);
            }
        });

        lblXMLGeneratorText.setText("XML Generator");

        lblXMLGeneratorDoc.setText("jLabel2");
        lblXMLGeneratorDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblXMLGeneratorDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblXMLGeneratorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblXMLGeneratorText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblXMLGeneratorDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblXMLGeneratorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblXMLGeneratorText)
                    .addComponent(lblXMLGeneratorDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblRECToolServerImg.setText("jLabel1");
        lblRECToolServerImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRECToolServerImgMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblRECToolServerImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblRECToolServerImgMouseReleased(evt);
            }
        });

        lblRECToolServerText.setText("REC Tool Server");

        lblRecToolServerDoc.setText("jLabel1");
        lblRecToolServerDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecToolServerDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRECToolServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblRECToolServerText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblRecToolServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRECToolServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRECToolServerText)
                    .addComponent(lblRecToolServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEVODPKServerImg.setText("jLabel1");
        lblEVODPKServerImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEVODPKServerImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEVODPKServerImgMouseReleased(evt);
            }
        });

        lblEVODPKServerText.setText("EVO DPK Server");

        lblEVODPKServerDoc.setText("jLabel1");
        lblEVODPKServerDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEVODPKServerDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEVODPKServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEVODPKServerText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblEVODPKServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEVODPKServerImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEVODPKServerText)
                    .addComponent(lblEVODPKServerDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEVOMatcherImg.setText("jLabel1");
        lblEVOMatcherImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEVOMatcherImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEVOMatcherImgMouseReleased(evt);
            }
        });

        jLabel18.setText("EVO Matcher");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEVOMatcherImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel18)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEVOMatcherImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblLTBLoaderImg.setText("jLabel1");
        lblLTBLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblLTBLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblLTBLoaderImgMouseReleased(evt);
            }
        });

        lblLTBLoaderText.setText("LTB Loader");

        lblLTBLoaderDoc.setText("jLabel2");
        lblLTBLoaderDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLTBLoaderDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLTBLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblLTBLoaderText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblLTBLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLTBLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLTBLoaderText)
                    .addComponent(lblLTBLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblCBMLoaderImg.setText("jLabel1");
        lblCBMLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCBMLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblCBMLoaderImgMouseReleased(evt);
            }
        });

        lblCBMLoaderText.setText("CBM Loader");

        lblCBMLoaderDoc.setText("jLabel2");
        lblCBMLoaderDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCBMLoaderDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCBMLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblCBMLoaderText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCBMLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCBMLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCBMLoaderText)
                    .addComponent(lblCBMLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblSnapshotLoaderImg.setText("jLabel1");
        lblSnapshotLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblSnapshotLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblSnapshotLoaderImgMouseReleased(evt);
            }
        });

        lblSnapshotLoaderText.setText("Snapshot Loader");

        lblSnapshotLoaderDoc.setText("jLabel2");
        lblSnapshotLoaderDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSnapshotLoaderDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblSnapshotLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSnapshotLoaderText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSnapshotLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSnapshotLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSnapshotLoaderText)
                    .addComponent(lblSnapshotLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblEVOMonitorImg.setText("jLabel1");
        lblEVOMonitorImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEVOMonitorImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEVOMonitorImgMouseReleased(evt);
            }
        });

        lblEVOMonitorText.setText("EVO Monitoring");

        lblEVOMonitorDoc.setText("jLabel2");
        lblEVOMonitorDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEVOMonitorDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEVOMonitorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEVOMonitorText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblEVOMonitorDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEVOMonitorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEVOMonitorText)
                    .addComponent(lblEVOMonitorDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblCCXMLSenderImg.setText("jLabel1");
        lblCCXMLSenderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCCXMLSenderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblCCXMLSenderImgMouseReleased(evt);
            }
        });

        lblCCXMLSenderText.setText("CCA XML Sender");

        lblCCXMLSenderDoc.setText("jLabel2");
        lblCCXMLSenderDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCCXMLSenderDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCCXMLSenderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblCCXMLSenderText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCCXMLSenderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCCXMLSenderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCCXMLSenderText)
                    .addComponent(lblCCXMLSenderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblBSLoaderImg.setText("jLabel1");
        lblBSLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblBSLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblBSLoaderImgMouseReleased(evt);
            }
        });

        jLabel26.setText("BS Loader");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblBSLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel26)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBSLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblIncidentLoaderImg.setText("jLabel1");
        lblIncidentLoaderImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblIncidentLoaderImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblIncidentLoaderImgMouseReleased(evt);
            }
        });

        lblIncidentLoaderText.setText("Incident Loader");

        lblIncidentLoaderDoc.setText("jLabel2");
        lblIncidentLoaderDoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIncidentLoaderDocMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblIncidentLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblIncidentLoaderText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblIncidentLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIncidentLoaderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIncidentLoaderText)
                    .addComponent(lblIncidentLoaderDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editorResultsEServices.setEditable(false);
        editorResultsEServices.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResultsEServices);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        btnSearchEServices.setText("Probe Again!");
        btnSearchEServices.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchEServicesActionPerformed(evt);
            }
        });

        areaLogEServices.setEditable(false);
        areaLogEServices.setColumns(20);
        areaLogEServices.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        areaLogEServices.setLineWrap(true);
        areaLogEServices.setRows(5);
        areaLogEServices.setWrapStyleWord(true);
        jScrollPane2.setViewportView(areaLogEServices);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                    .addComponent(btnSearchEServices, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearchEServices)
                .addContainerGap())
        );

        javax.swing.GroupLayout paneleServicesLayout = new javax.swing.GroupLayout(paneleServices);
        paneleServices.setLayout(paneleServicesLayout);
        paneleServicesLayout.setHorizontalGroup(
            paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneleServicesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(paneleServicesLayout.createSequentialGroup()
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        paneleServicesLayout.setVerticalGroup(
            paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneleServicesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(paneleServicesLayout.createSequentialGroup()
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(paneleServicesLayout.createSequentialGroup()
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, paneleServicesLayout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(paneleServicesLayout.createSequentialGroup()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(paneleServicesLayout.createSequentialGroup()
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(paneleServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(paneleServicesLayout.createSequentialGroup()
                            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(21, 21, 21)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        tpLoaderSupport.addTab("eServices Loaders", paneleServices);

        lblMT102Inbound.setText("jLabel1");
        lblMT102Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblMT102InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblMT102InboundMouseReleased(evt);
            }
        });

        jLabel5.setText("CP / UP  T102");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMT102Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMT102Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblT1T3Inbound.setText("jLabel1");
        lblT1T3Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblT1T3InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblT1T3InboundMouseReleased(evt);
            }
        });

        jLabel7.setText("T1 / T3 RMD");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblT1T3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblT1T3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblWT102Inbound.setText("jLabel1");
        lblWT102Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblWT102InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblWT102InboundMouseReleased(evt);
            }
        });

        jLabel9.setText("BNSF T102");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblWT102Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblWT102Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblT7Processor.setText("jLabel1");
        lblT7Processor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblT7ProcessorMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblT7ProcessorMouseReleased(evt);
            }
        });

        jLabel21.setText("UP T7");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblT7Processor, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel21)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblT7Processor, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblCPT3Inbound.setText("jLabel1");
        lblCPT3Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCPT3InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblCPT3InboundMouseReleased(evt);
            }
        });

        jLabel13.setText("CP T3");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCPT3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addContainerGap(81, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCPT3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblMaterialT151.setText("jLabel1");
        lblMaterialT151.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblMaterialT151MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblMaterialT151MouseReleased(evt);
            }
        });

        jLabel15.setText("UP T151");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMaterialT151, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMaterialT151, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblRMDMain.setText("jLabel1");
        lblRMDMain.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblRMDMainMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblRMDMainMouseReleased(evt);
            }
        });

        jLabel17.setText("eSTP RMD");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRMDMain, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel17)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRMDMain, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblT107Inbound.setText("jLabel1");
        lblT107Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblT107InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblT107InboundMouseReleased(evt);
            }
        });

        jLabel19.setText("T107 BNSF / CSX / CP");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblT107Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel19)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblT107Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblT3Inbound.setText("jLabel1");
        lblT3Inbound.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblT3InboundMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblT3InboundMouseReleased(evt);
            }
        });

        jLabel11.setText("CSX T3");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblT3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblT3Inbound, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnSearchB2B.setText("Probe Again!");
        btnSearchB2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchB2BActionPerformed(evt);
            }
        });

        areaLogB2B.setEditable(false);
        areaLogB2B.setColumns(20);
        areaLogB2B.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        areaLogB2B.setLineWrap(true);
        areaLogB2B.setRows(5);
        areaLogB2B.setWrapStyleWord(true);
        jScrollPane3.setViewportView(areaLogB2B);

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                    .addComponent(btnSearchB2B, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearchB2B)
                .addContainerGap())
        );

        editorResultsB2B.setEditable(false);
        editorResultsB2B.setContentType("text/html"); // NOI18N
        jScrollPane4.setViewportView(editorResultsB2B);

        lblT103InboundImg.setText("jLabel1");
        lblT103InboundImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblT103InboundImgMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblT103InboundImgMouseReleased(evt);
            }
        });

        lblT103InboundText.setText("CSX T103");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblT103InboundImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblT103InboundText)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblT103InboundImg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblT103InboundText))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelB2BLayout = new javax.swing.GroupLayout(panelB2B);
        panelB2B.setLayout(panelB2BLayout);
        panelB2BLayout.setHorizontalGroup(
            panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelB2BLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelB2BLayout.createSequentialGroup()
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel27, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel26, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel25, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel29, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel24, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 296, Short.MAX_VALUE)
                        .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane4))
                .addContainerGap())
        );
        panelB2BLayout.setVerticalGroup(
            panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelB2BLayout.createSequentialGroup()
                .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelB2BLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelB2BLayout.createSequentialGroup()
                                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelB2BLayout.createSequentialGroup()
                                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelB2BLayout.createSequentialGroup()
                                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelB2BLayout.createSequentialGroup()
                                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelB2BLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tpLoaderSupport.addTab("B2B Loaders", panelB2B);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tpLoaderSupport)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tpLoaderSupport)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchEServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchEServicesActionPerformed
        probeLoaders();
    }//GEN-LAST:event_btnSearchEServicesActionPerformed

    private void btnSearchB2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchB2BActionPerformed
        probeLoaders();
    }//GEN-LAST:event_btnSearchB2BActionPerformed

    private void lblRECToolServerImgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRECToolServerImgMouseClicked

    }//GEN-LAST:event_lblRECToolServerImgMouseClicked

    private void lblRecToolServerDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecToolServerDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\RECToolServer.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblRecToolServerDocMouseClicked

    private void lblEGUToolServerDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEGUToolServerDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\EGUToolServer.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblEGUToolServerDocMouseClicked

    private void lblEVOServerDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOServerDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\EVOServer.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblEVOServerDocMouseClicked

    private void lblIncidentLoaderDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIncidentLoaderDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\IncidentLoader.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblIncidentLoaderDocMouseClicked

    private void lblSnapshotLoaderDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSnapshotLoaderDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\SnapshotLoader.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblSnapshotLoaderDocMouseClicked

    private void lblCBMLoaderDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCBMLoaderDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\CBMLoader.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblCBMLoaderDocMouseClicked

    private void lblCCXMLSenderDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCCXMLSenderDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\CCAXMLSender.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblCCXMLSenderDocMouseClicked

    private void lblEVOMonitorDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOMonitorDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\EVOMonitoring.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblEVOMonitorDocMouseClicked

    private void lblXMLGeneratorDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblXMLGeneratorDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\XMLGenerator.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblXMLGeneratorDocMouseClicked

    private void lblLTBLoaderDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLTBLoaderDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\LTBLoader.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblLTBLoaderDocMouseClicked

    private void lblEVODPKServerDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVODPKServerDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\EVODPKServer.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblEVODPKServerDocMouseClicked

    private void lblLiteToolDocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLiteToolDocMouseClicked
        if (evt.getClickCount() == 2) {
            try {
              File file = new File("ExternalDocs\\LoaderSupport\\LiteToolServer.htm");
              this.editorResultsEServices.setPage(file.toURI().toURL());
            }
            catch (Exception e) {}            
        }
    }//GEN-LAST:event_lblLiteToolDocMouseClicked

    private void lblLiteToolImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLiteToolImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.LITE_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }        
    }//GEN-LAST:event_lblLiteToolImgMousePressed

    private void lblLiteToolImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLiteToolImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.LITE_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }  
    }//GEN-LAST:event_lblLiteToolImgMouseReleased

    private void lblT107InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT107InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T107_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT107InboundMousePressed

    private void lblT107InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT107InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T107_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT107InboundMouseReleased

    private void lblT1T3InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT1T3InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T1_T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT1T3InboundMousePressed

    private void lblT1T3InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT1T3InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T1_T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT1T3InboundMouseReleased

    private void lblCPT3InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCPT3InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CP_T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblCPT3InboundMousePressed

    private void lblCPT3InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCPT3InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CP_T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblCPT3InboundMouseReleased

    private void lblMT102InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMT102InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.M_T102_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblMT102InboundMousePressed

    private void lblMT102InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMT102InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.M_T102_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblMT102InboundMouseReleased

    private void lblT3InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT3InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT3InboundMousePressed

    private void lblT3InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT3InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T3_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT3InboundMouseReleased

    private void lblMaterialT151MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMaterialT151MousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.MAT_T151;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblMaterialT151MousePressed

    private void lblMaterialT151MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMaterialT151MouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.MAT_T151;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblMaterialT151MouseReleased

    private void lblWT102InboundMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblWT102InboundMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.W_T102_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblWT102InboundMousePressed

    private void lblWT102InboundMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblWT102InboundMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.W_T102_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblWT102InboundMouseReleased

    private void lblT7ProcessorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT7ProcessorMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T7_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT7ProcessorMousePressed

    private void lblT7ProcessorMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT7ProcessorMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.T7_INBOUND;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        } 
    }//GEN-LAST:event_lblT7ProcessorMouseReleased

    private void lblRMDMainMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRMDMainMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.ESTP_RMD;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblRMDMainMousePressed

    private void lblRMDMainMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRMDMainMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.ESTP_RMD;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblRMDMainMouseReleased

    private void lblEVOServerImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOServerImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOServerImgMousePressed

    private void lblEVOServerImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOServerImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOServerImgMouseReleased

    private void lblEGUToolServerImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEGUToolServerImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EGU_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEGUToolServerImgMousePressed

    private void lblEGUToolServerImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEGUToolServerImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EGU_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEGUToolServerImgMouseReleased

    private void lblLTBLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLTBLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.LTB_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblLTBLoaderImgMousePressed

    private void lblLTBLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLTBLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.LTB_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblLTBLoaderImgMouseReleased

    private void lblXMLGeneratorImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblXMLGeneratorImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.XML_GENERATOR;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblXMLGeneratorImgMousePressed

    private void lblXMLGeneratorImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblXMLGeneratorImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.XML_GENERATOR;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblXMLGeneratorImgMouseReleased

    private void lblRECToolServerImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRECToolServerImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.REC_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblRECToolServerImgMousePressed

    private void lblRECToolServerImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRECToolServerImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.REC_TOOL_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblRECToolServerImgMouseReleased

    private void lblEVODPKServerImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVODPKServerImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_DPK_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVODPKServerImgMousePressed

    private void lblEVODPKServerImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVODPKServerImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_DPK_SERVER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVODPKServerImgMouseReleased

    private void lblEVOMatcherImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOMatcherImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_MATCHER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOMatcherImgMouseReleased

    private void lblEVOMatcherImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOMatcherImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_MATCHER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOMatcherImgMousePressed

    private void lblEWGLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEWGLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EWG_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEWGLoaderImgMouseReleased

    private void lblEWGLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEWGLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EWG_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEWGLoaderImgMousePressed

    private void lblCBMLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCBMLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CBM_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblCBMLoaderImgMousePressed

    private void lblCBMLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCBMLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CBM_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblCBMLoaderImgMouseReleased

    private void lblIncidentLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIncidentLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.INCIDENT_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblIncidentLoaderImgMousePressed

    private void lblIncidentLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIncidentLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.INCIDENT_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblIncidentLoaderImgMouseReleased

    private void lblSnapshotLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSnapshotLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.SNAPSHOT_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblSnapshotLoaderImgMousePressed

    private void lblSnapshotLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSnapshotLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.SNAPSHOT_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblSnapshotLoaderImgMouseReleased

    private void lblCCXMLSenderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCCXMLSenderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CCA_XML_SENDER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblCCXMLSenderImgMousePressed

    private void lblCCXMLSenderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCCXMLSenderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CCA_XML_SENDER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblCCXMLSenderImgMouseReleased

    private void lblBSLoaderImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBSLoaderImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.BS_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblBSLoaderImgMousePressed

    private void lblBSLoaderImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBSLoaderImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.BS_LOADER;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblBSLoaderImgMouseReleased

    private void lblEVOMonitorImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOMonitorImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_MONITOR;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOMonitorImgMousePressed

    private void lblEVOMonitorImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEVOMonitorImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.EVO_MONITOR;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblEVOMonitorImgMouseReleased

    private void lblT103InboundImgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT103InboundImgMousePressed
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CSX_T103;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblT103InboundImgMousePressed

    private void lblT103InboundImgMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblT103InboundImgMouseReleased
        if (evt.isPopupTrigger()) {
          selectedLoader = this.CSX_T103;
          popMenu.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_lblT103InboundImgMouseReleased

  //Looking for the chkdls. To be implemented.
 private void fetchDownloadStatus() { 
        new Thread(new Runnable() {
       public void run() {
         loadDownloadStatus();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
           }
         });
       }
     }).start(); 
   }   
        
   private void loadDownloadStatus(){
        SSHExec ssh;
        String command = new String();        
        protectFields();             
        
        command = "/trnapp/eservices/rmdlite/scripts/chkdls";
      
        // Initialize a ConnBean object, parameter list is ip, username, password
        ConnBean cb = new ConnBean(PRD_SERVER, PRD_USER, PRD_PASSWORD);
        
        // Put the ConnBean instance as parameter for SSHExec static method getInstance(ConnBean) to retrieve a singleton SSHExec instance        
        ssh = SSHExec.getInstance(cb);          
        // Connect to server        
        ssh.connect();        
        log("Attempting to connect to " + PRD_SERVER + " to check download status...");
        //CustomTask sampleTask = new ExecCommand("pwd");
        CustomTask sampleTask;
        sampleTask = new ExecCommand(command);
        
        Result res;
        try {
            res =  ssh.exec(sampleTask);
            editorResultsB2B.setText("<HTML><PRE>" + res.sysout + "</PRE></HTML>");
            log("Success!");
            releaseFields();
        }catch(Exception e){
            log("Error, could not connect. Reason: " + (e.getMessage() == null ? "Unable to reach host. Check your network connection." : e.getMessage() ));
            releaseFields();
        }
    }
       
 
    private void fetchLoaderDoc(){

        String docURL = "";
        boolean isEServicesLoader = false;
        boolean isB2BLoader = false;
                          
        switch(selectedLoader){
            
            //eServices
            case LITE_TOOL_SERVER:
                docURL = "ExternalDocs\\LoaderSupport\\LiteToolServer.htm";
                isEServicesLoader = true;
                break;
                
            case EVO_SERVER:
                docURL = "ExternalDocs\\LoaderSupport\\EVOServer.htm";
                isEServicesLoader = true;
                break;

            case EGU_TOOL_SERVER:
                docURL = "ExternalDocs\\LoaderSupport\\EGUToolServer.htm";
                isEServicesLoader = true;
                break;

            case LTB_LOADER:
                docURL = "ExternalDocs\\LoaderSupport\\LTBLoader.htm";
                isEServicesLoader = true;
                break;

            case XML_GENERATOR:
                docURL = "ExternalDocs\\LoaderSupport\\XMLGenerator.htm";
                isEServicesLoader = true;
                break;

            case REC_TOOL_SERVER:
                docURL = "ExternalDocs\\LoaderSupport\\RECToolServer.htm";
                isEServicesLoader = true;
                break;

            case EVO_DPK_SERVER:
                docURL = "ExternalDocs\\LoaderSupport\\EVODPKServer.htm";
                isEServicesLoader = true;
                break;

            case EVO_MATCHER:
                docURL = "";
                isEServicesLoader = true;
                break;

            case EWG_LOADER:
                docURL = "";
                isEServicesLoader = true;
                break;

            case CBM_LOADER:
                docURL = "ExternalDocs\\LoaderSupport\\CBMLoader.htm";
                isEServicesLoader = true;
                break;

            case INCIDENT_LOADER:
                docURL = "ExternalDocs\\LoaderSupport\\IncidentLoader.htm";
                isEServicesLoader = true;
                break;

            case SNAPSHOT_LOADER:
                docURL = "ExternalDocs\\LoaderSupport\\SnapshotLoader.htm";
                isEServicesLoader = true;
                break;
                
            case CCA_XML_SENDER:
                docURL = "ExternalDocs\\LoaderSupport\\CCAXMLSender.htm";
                isEServicesLoader = true;
                break;
                
            case BS_LOADER:
                docURL = "";
                isEServicesLoader = true;
                break;
                
            case EVO_MONITOR :
                docURL = "ExternalDocs\\LoaderSupport\\EVOMonitoring.htm";
                isEServicesLoader = true;
                break;
                       
             //B2B
            case T107_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;

            case T1_T3_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;
                
            case CP_T3_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;
                
            case M_T102_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;
                
            case W_T102_INBOUND  :
                docURL = "";
                isB2BLoader = true;
                break;

            case T3_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;

            case MAT_T151 :
                docURL = "";
                isB2BLoader = true;
                break;
                
            case T7_INBOUND :
                docURL = "";
                isB2BLoader = true;
                break;
                
            case ESTP_RMD :
                docURL = "";
                isB2BLoader = true;
                break;
                  
        }
        try {
          if(docURL.isEmpty()){
              if(isEServicesLoader){
                editorResultsEServices.setText("<HTML><H3>Documentation not available.</H3></HTML>"); 
              } else if (isB2BLoader) {
                editorResultsB2B.setText("<HTML><H3>Documentation not available.</H3></HTML>"); 
              }
              return;
          }
          File file = new File(docURL);
          if(isEServicesLoader){
            editorResultsEServices.setPage(file.toURI().toURL());
          } else if (isB2BLoader) {
            editorResultsB2B.setPage(file.toURI().toURL());
          }          

        }
        catch (Exception e) {
              if(isEServicesLoader){
                editorResultsEServices.setText("<HTML><H3>Documentation not available.</H3></HTML>"); 
              } else if (isB2BLoader) {
                editorResultsB2B.setText("<HTML><H3>Documentation not available.</H3></HTML>"); 
              }
        }          
        
    }
    
/************************ FETCH LOG METHODS **************************/
    private void fetchLoaderLog() { 
        new Thread(new Runnable() {
       public void run() {
         loadLoaderLog();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
           }
         });
       }
     }).start(); 
   }   
    
    private void loadLoaderLog(){
        
        //is it one of the implemented ones? eServices are not accessible
        switch(selectedLoader){
            
            //eServices
            case LITE_TOOL_SERVER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>");
                return;
                                
            case EVO_SERVER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case EGU_TOOL_SERVER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case LTB_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case XML_GENERATOR:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case REC_TOOL_SERVER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case EVO_DPK_SERVER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case EVO_MATCHER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case EWG_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;
                
            case CBM_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case INCIDENT_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;

            case SNAPSHOT_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;
                
            case CCA_XML_SENDER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;
                
            case BS_LOADER:
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;
                
            case EVO_MONITOR :
                editorResultsEServices.setText("<HTML><H3>Sorry, logs not yet available for this loader.</H3></HTML>"); 
                return;
        }        
        
        SSHExec ssh;
        String command = new String();        
        protectFields();
        
        //Grab how many lines:
        String lines = JOptionPane.showInputDialog(parent, "How many log lines?", "50");           
        
        if(null == lines){
            releaseFields();
            return;
        }
        
        try{
            Integer.parseInt(lines);
        } catch(Exception e){
            JOptionPane.showMessageDialog(parent, "Please enter only numbers", "Input error",JOptionPane.ERROR_MESSAGE);
            releaseFields();
            return;
        }
        
        switch(selectedLoader){
           //eServices loaders


           //B2B loaders
           case T107_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/GETS_B2B_T107_BNSF.log";
               break;
           
           case T1_T3_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/Gets_T1_T3.log";
               break;
               
           case CP_T3_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/Gets_CP_T3_In.log";
               break;  
               
           case M_T102_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/T102_inbnd.log";
               break;
     
           case T3_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/T3Log.log";
               break;               
     
           case MAT_T151:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/Mat_T151.log";
               break;                

           case W_T102_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/T102B2Bver2Log.log";
               break;       
               
           case T7_INBOUND:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/T7Log.log";
               break;    
               
           case ESTP_RMD:
               command = "tail -" + lines + " /trnapp/eservices/eservb2b/prd/bin/java/log/eSTP_RMD.log";
               break;                  
        }        
        
        // Initialize a ConnBean object, parameter list is ip, username, password
        ConnBean cb = new ConnBean(PRD_SERVER, PRD_USER, PRD_PASSWORD);
        
        // Put the ConnBean instance as parameter for SSHExec static method getInstance(ConnBean) to retrieve a singleton SSHExec instance        
        ssh = SSHExec.getInstance(cb);          
        // Connect to server        
        ssh.connect();        
        log("Attempting to connect to " + PRD_SERVER + " to pull log files...");
        //CustomTask sampleTask = new ExecCommand("pwd");
        CustomTask sampleTask;
        sampleTask = new ExecCommand(command);
        log("Pulling " + lines + " lines from the " + selectedLoader + " log file...");
        
        Result res;
        try {
            res =  ssh.exec(sampleTask);
            editorResultsB2B.setText("<HTML><PRE>" + res.sysout + "</PRE></HTML>");
            log("Success!");
            releaseFields();
        }catch(Exception e){
            log("Error, could not connect. Reason: " + (e.getMessage() == null ? "Unable to reach host. Check your network connection." : e.getMessage() ));
            releaseFields();
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaLogB2B;
    private javax.swing.JTextArea areaLogEServices;
    private javax.swing.JButton btnSearchB2B;
    private javax.swing.JButton btnSearchEServices;
    private javax.swing.JEditorPane editorResultsB2B;
    private javax.swing.JEditorPane editorResultsEServices;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblBSLoaderImg;
    private javax.swing.JLabel lblCBMLoaderDoc;
    private javax.swing.JLabel lblCBMLoaderImg;
    private javax.swing.JLabel lblCBMLoaderText;
    private javax.swing.JLabel lblCCXMLSenderDoc;
    private javax.swing.JLabel lblCCXMLSenderImg;
    private javax.swing.JLabel lblCCXMLSenderText;
    private javax.swing.JLabel lblCPT3Inbound;
    private javax.swing.JLabel lblEGUToolServerDoc;
    private javax.swing.JLabel lblEGUToolServerImg;
    private javax.swing.JLabel lblEGUToolServerText;
    private javax.swing.JLabel lblEVODPKServerDoc;
    private javax.swing.JLabel lblEVODPKServerImg;
    private javax.swing.JLabel lblEVODPKServerText;
    private javax.swing.JLabel lblEVOMatcherImg;
    private javax.swing.JLabel lblEVOMonitorDoc;
    private javax.swing.JLabel lblEVOMonitorImg;
    private javax.swing.JLabel lblEVOMonitorText;
    private javax.swing.JLabel lblEVOServerDoc;
    private javax.swing.JLabel lblEVOServerImg;
    private javax.swing.JLabel lblEVOServerText;
    private javax.swing.JLabel lblEWGLoaderImg;
    private javax.swing.JLabel lblIncidentLoaderDoc;
    private javax.swing.JLabel lblIncidentLoaderImg;
    private javax.swing.JLabel lblIncidentLoaderText;
    private javax.swing.JLabel lblLTBLoaderDoc;
    private javax.swing.JLabel lblLTBLoaderImg;
    private javax.swing.JLabel lblLTBLoaderText;
    private javax.swing.JLabel lblLiteToolDoc;
    private javax.swing.JLabel lblLiteToolImg;
    private javax.swing.JLabel lblLiteToolText;
    private javax.swing.JLabel lblMT102Inbound;
    private javax.swing.JLabel lblMaterialT151;
    private javax.swing.JLabel lblRECToolServerImg;
    private javax.swing.JLabel lblRECToolServerText;
    private javax.swing.JLabel lblRMDMain;
    private javax.swing.JLabel lblRecToolServerDoc;
    private javax.swing.JLabel lblSnapshotLoaderDoc;
    private javax.swing.JLabel lblSnapshotLoaderImg;
    private javax.swing.JLabel lblSnapshotLoaderText;
    private javax.swing.JLabel lblT103InboundImg;
    private javax.swing.JLabel lblT103InboundText;
    private javax.swing.JLabel lblT107Inbound;
    private javax.swing.JLabel lblT1T3Inbound;
    private javax.swing.JLabel lblT3Inbound;
    private javax.swing.JLabel lblT7Processor;
    private javax.swing.JLabel lblWT102Inbound;
    private javax.swing.JLabel lblXMLGeneratorDoc;
    private javax.swing.JLabel lblXMLGeneratorImg;
    private javax.swing.JLabel lblXMLGeneratorText;
    private javax.swing.JPanel panelB2B;
    private javax.swing.JPanel paneleServices;
    private javax.swing.JTabbedPane tpLoaderSupport;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential