/*
 v 0.17
 - Added.
 v 0.19
 - Added "Subsection" as a search field.
 v 0.20
 - Corrected the fact that one could just select a Date range and it would complain that you need to fill a field.
 - The Checkboxes were not being protected when the app was fetching records. This has been corrected.
 - Added Search Functionality.
 */

package feedback;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import javax.swing.SpinnerDateModel;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import javax.swing.text.MaskFormatter;
import util.feedback.*;


public class FeedbackLookupIF extends JInternalFrame {

   private java.sql.Connection conn;
   private java.sql.PreparedStatement prepStm;
   private ResultSet rs;
   private SimpleDateFormat dateFormatter;
   private SimpleDateFormat timeFormatter;
   private SimpleDateFormat queryFormatter;
   private SimpleDateFormat shortListFormatter;
   private StringBuffer buf;
   private boolean done;
   private ArrayList<FeedbackData> fbArray;   
   private MaskFormatter dateMask;
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;      
   
    public FeedbackLookupIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);

     try {
        dateMask = new MaskFormatter("##/##/####");
        dateMask.setPlaceholderCharacter('_');
        dateFormatter = new SimpleDateFormat("EEE, MM-dd-yyyy, ");
        timeFormatter = new SimpleDateFormat("HH:mm z"); 
        shortListFormatter = new SimpleDateFormat("dd-MMM-yyyy");
        queryFormatter = new SimpleDateFormat("MM-dd-yyyy");
     }catch(Exception e){
         System.out.println("BOOM!");
         e.printStackTrace();
     }     
     
     initComponents();

        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
      
     
     this.getRootPane().setDefaultButton(btnSearch);
     
     hideDateElements();
     
     
     buf = new StringBuffer();
     progressBar.setIndeterminate(true);
     progressBar.setVisible(false);

     fbArray = new ArrayList<>();
     done = false;    

     Calendar calendar = Calendar.getInstance();
     Date initDate = calendar.getTime();
     calendar.add(Calendar.YEAR, -100);
     Date earliestDate = calendar.getTime();
     calendar.add(Calendar.YEAR, 200);
     Date latestDate = calendar.getTime();
     
     SpinnerDateModel fromModel = new SpinnerDateModel(initDate,
                             earliestDate,
                             latestDate,
                             Calendar.YEAR);     
     SpinnerDateModel toModel = new SpinnerDateModel(initDate,
                             earliestDate,
                             latestDate,
                             Calendar.YEAR);  
     
     spFromDate.setModel(fromModel);
     spFromDate.setEditor(new JSpinner.DateEditor(spFromDate, "MMM-dd-yyyy"));
     spToDate.setModel(toModel);
     spToDate.setEditor(new JSpinner.DateEditor(spToDate, "MMM-dd-yyyy"));

          
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FeedbackLookupIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
      
    
   private void cleanClose() {
     dispose();
   }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtFeedbackID = new javax.swing.JTextField();
        txtRaisedBy = new javax.swing.JTextField();
        txtSuggestion = new javax.swing.JTextField();
        txtResponseMsg = new javax.swing.JTextField();
        txtITComments = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        chkBoxAcceptDates = new javax.swing.JCheckBox();
        panelDate = new javax.swing.JPanel();
        lblFromDate = new javax.swing.JLabel();
        spFromDate = new javax.swing.JSpinner();
        lblToDate = new javax.swing.JLabel();
        spToDate = new javax.swing.JSpinner();
        txtRoadNumber = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        comboSubsection = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        comboStatus = new javax.swing.JComboBox();
        chkBoxDetailedList = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtFeedbackID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFeedbackIDFocusGained(evt);
            }
        });

        txtRaisedBy.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRaisedByFocusGained(evt);
            }
        });

        txtSuggestion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSuggestionFocusGained(evt);
            }
        });

        txtResponseMsg.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtResponseMsgFocusGained(evt);
            }
        });

        txtITComments.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtITCommentsFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        jLabel1.setText("Feedback ID:");

        jLabel2.setText("Raised by:");

        jLabel3.setText("IT Comments:");

        jLabel4.setText("Suggestion:");

        jLabel5.setText("Response:");

        chkBoxAcceptDates.setText("Use range");
        chkBoxAcceptDates.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkBoxAcceptDatesActionPerformed(evt);
            }
        });

        lblFromDate.setText("from date:");

        lblToDate.setText("to:");

        javax.swing.GroupLayout panelDateLayout = new javax.swing.GroupLayout(panelDate);
        panelDate.setLayout(panelDateLayout);
        panelDateLayout.setHorizontalGroup(
            panelDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDateLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblFromDate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spFromDate, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblToDate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spToDate, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDateLayout.setVerticalGroup(
            panelDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDateLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFromDate)
                    .addComponent(lblToDate)
                    .addComponent(spFromDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(spToDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        txtRoadNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRoadNumberFocusGained(evt);
            }
        });

        jLabel6.setText("Road Number:");

        jLabel7.setText("Subsection:");

        comboSubsection.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Select Subsection --", "ACCOUNTS/LOGINS", "B2B", "CBM", "CCS LOCO CONFIG AUDIT", "CORELOAD", "EDEFECT", "EMANUALS", "EMISSIONS", "FAMS", "FEEDBACK", "FMI", "HARDWARE", "HOME PAGE", "MATERIAL REPAIR KITS", "MATERIALS", "MCD ADMINISTRATOR", "MI DOCUMENTATION", "MONITOR BOARD", "PARTS CATALOG", "PDA", "REPORTING", "RMD", "SCHEDULING", "SCHEMATICS", "SERVICE SHEET", "SHOP MAP", "SHOP SUMMARY", "SOFTWARE RELEASE TOOL", "TIME KEEPING", "TOOLBOX", "TRAINING", "TROUBLESHOOTING", "WHEELS", "WORK ORDER", "WORKSCOPE" }));

        jLabel8.setText("Status:");

        comboStatus.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Status --", "Open", "Closed", "Being Worked", "Closed for Validation", "Development Matrix" }));

        chkBoxDetailedList.setSelected(true);
        chkBoxDetailedList.setText("Detailed List");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtFeedbackID)
                            .addComponent(txtRaisedBy)
                            .addComponent(txtITComments, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboSubsection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtResponseMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtSuggestion, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel8)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboStatus, 0, 132, Short.MAX_VALUE)
                                    .addComponent(txtRoadNumber))
                                .addGap(27, 27, 27))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(chkBoxAcceptDates)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(chkBoxDetailedList)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFeedbackID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSuggestion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8)
                    .addComponent(comboStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtRaisedBy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtResponseMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chkBoxAcceptDates)
                            .addComponent(jLabel3)
                            .addComponent(txtITComments, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSearch)
                        .addComponent(chkBoxDetailedList))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(comboSubsection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        editorResults.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                editorResultsHyperlinkUpdate(evt);
            }
        });
        jScrollPane1.setViewportView(editorResults);

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 637, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFeedbackIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFeedbackIDFocusGained
        txtFeedbackID.selectAll();
    }//GEN-LAST:event_txtFeedbackIDFocusGained

    private void txtRaisedByFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRaisedByFocusGained
        txtRaisedBy.selectAll();
    }//GEN-LAST:event_txtRaisedByFocusGained

    private void txtITCommentsFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtITCommentsFocusGained
        txtITComments.selectAll();
    }//GEN-LAST:event_txtITCommentsFocusGained

    private void txtSuggestionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSuggestionFocusGained
        txtSuggestion.selectAll();
    }//GEN-LAST:event_txtSuggestionFocusGained

    private void txtResponseMsgFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtResponseMsgFocusGained
        txtResponseMsg.selectAll();
    }//GEN-LAST:event_txtResponseMsgFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        if(txtFeedbackID.getText().trim().isEmpty() && 
                txtRaisedBy.getText().trim().isEmpty() && 
                   txtITComments.getText().trim().isEmpty() && 
                      txtSuggestion.getText().trim().isEmpty() && 
                        txtResponseMsg.getText().trim().isEmpty() &&
                            txtRoadNumber.getText().trim().isEmpty() &&
                               (comboSubsection.getSelectedIndex() == 0) &&
                                  (comboStatus.getSelectedIndex() == 0) && 
                                      !chkBoxAcceptDates.isSelected()){
            editorResults.setText("Please fill at least one field."); 
            return;            
        } else {
            
            try {
                if(!txtFeedbackID.getText().trim().isEmpty())
                    Integer.parseInt(txtFeedbackID.getText().trim());
            }catch(Exception e){
                editorResults.setText("Feedback ID should be a number.");  
                return;
            }
            
        }
        loadList();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void editorResultsHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {//GEN-FIRST:event_editorResultsHyperlinkUpdate
     if (evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
       try {
         java.awt.Desktop.getDesktop().browse(new java.net.URI(evt.getURL().toString()));
       } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(this, "Could not open browser, reason:\n" + e.getMessage(), "Error!", 0);
       }
     }
    }//GEN-LAST:event_editorResultsHyperlinkUpdate

    private void chkBoxAcceptDatesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkBoxAcceptDatesActionPerformed
       if(chkBoxAcceptDates.isSelected()){          
          showDateElements();
       } else {
          hideDateElements();
       }
       
    }//GEN-LAST:event_chkBoxAcceptDatesActionPerformed

    private void txtRoadNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRoadNumberFocusGained
        txtRoadNumber.selectAll();
    }//GEN-LAST:event_txtRoadNumberFocusGained

    private void hideDateElements(){
        lblFromDate.setVisible(false);
        spFromDate.setVisible(false);
        lblToDate.setVisible(false);
        spToDate.setVisible(false);      
        panelDate.setPreferredSize(new Dimension(322, 40)); //STAY THE SIZE YOU SHOULD BE, DAMN IT ALL!
    }

    private void showDateElements(){
        lblFromDate.setVisible(true);
        spFromDate.setVisible(true);
        lblToDate.setVisible(true);
        spToDate.setVisible(true);        
    }    
    
    private void protectFields(){
        txtFeedbackID.setEditable(false);
        txtRaisedBy.setEditable(false);
        txtSuggestion.setEditable(false);
        txtResponseMsg.setEditable(false);
        txtITComments.setEditable(false);
        btnSearch.setEnabled(false);
        spFromDate.setEnabled(false);
        spToDate.setEnabled(false);        
        comboStatus.setEnabled(false);
        comboSubsection.setEnabled(false);        
        chkBoxAcceptDates.setEnabled(false);
        chkBoxDetailedList.setEnabled(false);
        progressBar.setVisible(true);        
    }
    
    private void releaseFields(){
        txtFeedbackID.setEditable(true);
        txtRaisedBy.setEditable(true);
        txtSuggestion.setEditable(true);
        txtResponseMsg.setEditable(true);
        txtITComments.setEditable(true);
        btnSearch.setEnabled(true);
        spFromDate.setEnabled(true);
        spToDate.setEnabled(true);
        comboSubsection.setEnabled(true);
        comboStatus.setEnabled(true);
        chkBoxAcceptDates.setEnabled(true);
        chkBoxDetailedList.setEnabled(true);
        progressBar.setVisible(false);
    }
    
   private void loadList() { new Thread(new Runnable() {
       public void run() {
         progressBar.setVisible(true);
         populateFeedbackList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
             progressBar.setValue((int)(Math.random() * 100.0D));
           }
         });
       }
     }).start(); 
   }
   
   private void populateFeedbackList()
   {
     String fbQuery = "";
     protectFields();
     try
     {       
       editorResults.setText("");
       buf = new StringBuffer();
       
       conn = util.OracleConnectionManager.getConnection(0);
       
       fbQuery = "  SELECT fb.*, "
               + "NVL((select tag_value from gets_lms_feedback_tags where tag_id = fb.feedback_tags), 'No Tag') as current_status "
               + "FROM gets_etc.gets_etc_ESERVICES_feedback fb "
               + "WHERE fb.cust_name <> 'EMSAUser' "
               + (txtFeedbackID.getText().trim().isEmpty() ? "" : " AND fb.feedback_id = " + txtFeedbackID.getText().trim())
               + (txtRaisedBy.getText().trim().isEmpty() ? "" : " AND lower(fb.user_fullname) like '%" + txtRaisedBy.getText().trim().toLowerCase() + "%'")
               + (txtSuggestion.getText().trim().isEmpty() ? "" : " AND lower(fb.suggestion) like '%" + txtSuggestion.getText().trim().toLowerCase() + "%'")
               + (txtResponseMsg.getText().trim().isEmpty() ? "" : " AND lower(fb.response_msg) like '%" + txtResponseMsg.getText().trim().toLowerCase() + "%'")
               + (txtITComments.getText().trim().isEmpty() ? "" : " AND lower(fb.it_comments) like '%" + txtITComments.getText().trim().toLowerCase() + "%'")
               + (txtRoadNumber.getText().trim().isEmpty() ? "" : " AND lower(fb.road_number) like '%" + txtRoadNumber.getText().trim().toLowerCase() + "%'")
               + (comboSubsection.getSelectedIndex() == 0 ? "" : " AND subsection = '" + (String)comboSubsection.getSelectedItem() + "'")
               + (comboStatus.getSelectedIndex() == 0 ? "" : " AND lower(status) = '" + ((String)comboStatus.getSelectedItem()).toLowerCase() + "'")
               + (chkBoxAcceptDates.isSelected() ? " AND trunc(fb.feedback_date) between "
               + " to_date('" + queryFormatter.format(spFromDate.getValue()) + " 00:00:00','MM/DD/YYYY HH24:MI:SS') and "
               + " to_date('" + queryFormatter.format(spToDate.getValue()) + " 23:59:59','MM/DD/YYYY HH24:MI:SS') " : "" )
               + " ORDER BY fb.feedback_date DESC";
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       prepStm = conn.prepareStatement(fbQuery);
       
       rs = prepStm.executeQuery();
       
       fbArray = new ArrayList();
       
       if(rs.next()){
       
           do {
                fbArray.add(new FeedbackData(rs.getString("feedback_id"), 
                 rs.getDate("feedback_date"), 
                 new java.sql.Date(rs.getTime("feedback_date").getTime()), 
                 rs.getString("status"), rs.getString("user_id"), 
                 rs.getString("user_fullname"), 
                 rs.getString("cust_location"), 
                 rs.getString("cust_name"), 
                 rs.getString("subsection"), 
                 rs.getString("suggestion"), 
                 rs.getString("contact_email"), 
                 rs.getString("response_msg"), 
                 rs.getString("critical"), 
                 rs.getString("phone_number"), 
                 rs.getString("response_By"), 
                 rs.getString("road_number"), 
                 rs.getString("current_status"), 
                 rs.getString("it_comments")));                                             
           } while (rs.next()); 
           
        } else {
           editorResults.setText("No feedbacks found with that criteria.");
           releaseFields();
           return;
       }
      
       // Display the data in either Detailed form or   
       if(chkBoxDetailedList.isSelected()){
            for (FeedbackData f : fbArray) {
              buf.append("<FONT face=\"Courier\"><table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">"
                      + "<tr>  "
                      + "<td width=\"16%\" align=\"center\" bgcolor=\"" + (f.getCritical().equals("1") ? "#FF3333" : "#9999FF") + "\">&nbsp;&nbsp;<font color=\"white\" " + "size=\"4\"><b>" + f.getStatus() + "</b></font>&nbsp;&nbsp;</td>" + "  <td colspan=\"2\" >&nbsp;<big><b>Feedback# " + f.getFeedbackId() + "</b></big><FONT size=6 " + ((f.getCurrentStatus().toLowerCase().trim().equals("not started")) || (f.getCurrentStatus().toLowerCase().trim().equals("no tag")) ? " color=RED " : "") + "> (" + f.getCurrentStatus() + ") </FONT>" + "</td>" + "  <td width=\"10%\" align=\"right\" nowrap><B>Date :</B>&nbsp;</td>" + "  <td width=\"10%\" nowrap>" + dateFormatter.format(f.getFeedbackDate()) + " " + timeFormatter.format(f.getFeedbackTime()) + "</td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Section:</b></td>" + "<td width=\"32%\" nowrap>" + f.getSubsection() + "</td>" + "<td width=\"32%\"></td>" + "<td align=\"right\" nowrap><b>Customer:</b></td>" + "<td>" + f.getCustomer() + "</td>" + "</tr>" + "<tr>" + " <td align=\"right\"  nowrap><b>Contact Name:</b></td>" + " <td nowrap>" + (f.getContactEmail() == null ? f.getUserName() : new StringBuilder().append("<a href=\"mailto:").append(f.getContactEmail()).append("\"><u>").append(f.getUserName()).append("</u></a>").toString()) + " (" + f.getUserId() + ")</td>" + " <td></td>" + " <td align=\"right\" nowrap><B>Shop:</B></td>" + " <td> " + (f.getCustomerLocation() == null ? "None" : f.getCustomerLocation()) + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Phone Number:</b></td>" + "<td colspan=\"2\" ><a>" + (null == f.getPhoneNumber() ? "None Available" : f.getPhoneNumber()) + "</a></td>" + "<td align=\"left\" nowrap><b>Last response by:</b></TD><TD>" + (f.getResponseBy() == null ? "-" : f.getResponseBy()) + "</td></tr>" + "<tr valign=\"top\">" + " <td align=\"right\"  nowrap><b>Suggestion:</b></td>" + " <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getSuggestion() + "</p>" + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Road Number:</b></TD><TD>" + (f.getRoadNumber() == null ? "None" : f.getRoadNumber()) + " </td></tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>Response:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + (f.getResponse() == null ? "<H2><FONT COLOR=\"RED\"> NO RESPONSE MESSAGE, PLEASE ANSWER THIS FEEDBACK</FONT></H2>" : f.getResponse()) + "</p>" + "</td>" + " </tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>IT Comments:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getItComments() + "</p>" + "</td>" + " </tr>" + " <tr>" + "  <td colspan=\"5\" align=\"center\"><H2><A HREF=\"http:/eservices.getransportation.com/eservices/" + "efeedback/login.jsp?row=" + f.getFeedbackId() + "\">CLICK HERE TO RESPOND FEEDBACK </A></H2>" + " </td>" + "</tr>" + " </table> </FONT><HR>");
            }
       } else {
           buf.append("<TABLE width=100%>"
                   + "<TR bgcolor=\"#92CDDC\">"
                        + "<TD align=center><B>Feedback ID</B></TD>"
                        + "<TD align=center><B>Subsection</B></TD>"          
                        + "<TD align=center><B>Status</B></TD>"                   
                        + "<TD align=center><B>Raised by</B></TD>"
                        + "<TD align=center><B>Customer Info</B></TD>"
                        + "<TD align=center><B>Feedback Date</B></TD>"
                        + "<TD align=center><B>Suggestion</B></TD>"
                        + "<TD align=center><B>Response</B></TD>"                    
                        + "<TD align=center><B>Road Number</B></TD>" 
                        + "<TD align=center><B>IT Comments</B></TD>"                    
                        + "<TD align=center><B>IT Status</B></TD>"
                   + "</TR>");
            for (FeedbackData f : fbArray) {
               buf.append("<TR>"
               + "<TD align=center><FONT size=-1>" + f.getFeedbackId() + "</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + f.getSubsection() + "</FONT></TD>" 
               + "<TD align=center bgcolor=\"" + (f.getCritical().equals("1") ? "#FF3333" : "#9999FF") + "\"><FONT size=-1>" + f.getStatus() + "</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + f.getUserName() + "</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + f.getCustomer() + " (" + f.getCustomerLocation() +")</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + shortListFormatter.format(f.getFeedbackDate()) + "</FONT></TD>" 
               + "<TD><FONT size=-1>" + f.getSuggestion() + "</FONT></TD>" 
               + "<TD><FONT size=-1>" + f.getResponse() + "</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + (f.getRoadNumber() == null ? "None" : f.getRoadNumber()) + "</FONT></TD>" 
               + "<TD><FONT size=-1>" + f.getItComments() + "</FONT></TD>" 
               + "<TD align=center><FONT size=-1>" + f.getCurrentStatus() + "</FONT></TD>"
               + "</TR>");
            }
            buf.append("</TABLE></HTML>");
       }
 
       editorResults.setText(buf.toString());              
 
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtFeedbackID: \"" + txtFeedbackID.getText() + "\"\n");
       buf.append("txtRaisedBy: \"" + txtRaisedBy.getText() + "\"\n");
       buf.append("txtSuggestion: \"" + txtSuggestion.getText() + "\"\n");  
       buf.append("txtResponseMsg: \"" + txtResponseMsg.getText() + "\"\n");  
       buf.append("txtITComments: \"" + txtITComments.getText() + "\"\n");  
       buf.append("txtRoadNumber: \"" + txtITComments.getText() + "\"\n");  
       if(chkBoxAcceptDates.isSelected()){
           buf.append("spFromDate: \"" + queryFormatter.format(spFromDate.getValue()));
           buf.append("spToDate: \"" + queryFormatter.format(spToDate.getValue()));
       }
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: FeedbackLookupIF, Method: populateFeedbackList", fbQuery, buf.toString());
       editorResults.setText("<HTML><H3>An error occurred, please check the logs.</H3></HTML>");
       releaseFields();
     }
       
     editorResults.setCaretPosition(0);
     done = true;
     progressBar.setVisible(false);
     releaseFields();
   }
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JCheckBox chkBoxAcceptDates;
    private javax.swing.JCheckBox chkBoxDetailedList;
    private javax.swing.JComboBox comboStatus;
    private javax.swing.JComboBox comboSubsection;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFromDate;
    private javax.swing.JLabel lblToDate;
    private javax.swing.JPanel panelDate;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JSpinner spFromDate;
    private javax.swing.JSpinner spToDate;
    private javax.swing.JTextField txtFeedbackID;
    private javax.swing.JTextField txtITComments;
    private javax.swing.JTextField txtRaisedBy;
    private javax.swing.JTextField txtResponseMsg;
    private javax.swing.JTextField txtRoadNumber;
    private javax.swing.JTextField txtSuggestion;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential