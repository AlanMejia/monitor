 package feedback;
 
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
 import javax.swing.GroupLayout;
 import javax.swing.GroupLayout.ParallelGroup;
 import javax.swing.GroupLayout.SequentialGroup;
 import javax.swing.JButton;
import javax.swing.JComponent;
 import javax.swing.JDesktopPane;
 import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
 
 public class FeedbackTextUpdaterIF extends javax.swing.JInternalFrame
 {
   private util.PropertyManager pm;
   private JButton btnClear;
   private JButton btnGenerate;
   private JButton btnSaveDefaultUsername;
   private javax.swing.JCheckBox chkBoxAddToClipboard;
   private javax.swing.JLabel lblDefaultUsername;
   private javax.swing.JLabel lblNotification;
   private JTextField txtDefaultUsername;
   private JTextField txtFeedbackText;
   
   public FeedbackTextUpdaterIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
 
     initComponents();
     
     this.getRootPane().setDefaultButton(btnGenerate);
     
     this.lblNotification.setVisible(false);
     
 
     this.pm = new util.PropertyManager();
     this.txtDefaultUsername.setText(this.pm.getProperty(0));
     
 
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FeedbackTextUpdaterIF.this.cleanClose(); }
       
 
       public void internalFrameClosed(InternalFrameEvent e) {}
       
 
       public void internalFrameIconified(InternalFrameEvent e) {}
       
 
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
 
       public void internalFrameActivated(InternalFrameEvent e) {}
       
 
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
 
   public FeedbackTextUpdaterIF() {}
   
   private void cleanClose()
   {
     dispose();
   }
   
 
 
 
 
 
 
 
   private void initComponents()
   {
     this.txtFeedbackText = new JTextField();
     this.btnGenerate = new JButton();
     this.lblDefaultUsername = new javax.swing.JLabel();
     this.txtDefaultUsername = new JTextField();
     this.btnSaveDefaultUsername = new JButton();
     this.lblNotification = new javax.swing.JLabel();
     this.chkBoxAddToClipboard = new javax.swing.JCheckBox();
     this.btnClear = new JButton();
     
     setDefaultCloseOperation(2);
     
     this.txtFeedbackText.addFocusListener(new java.awt.event.FocusAdapter() {
       public void focusGained(java.awt.event.FocusEvent evt) {
         FeedbackTextUpdaterIF.this.txtFeedbackTextFocusGained(evt);
       }
       
     });
     this.btnGenerate.setText("Generate");
     this.btnGenerate.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(java.awt.event.ActionEvent evt) {
         FeedbackTextUpdaterIF.this.btnGenerateActionPerformed(evt);
       }
       
     });
     this.lblDefaultUsername.setText("Default username:");
     
     this.btnSaveDefaultUsername.setText("Save");
     this.btnSaveDefaultUsername.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(java.awt.event.ActionEvent evt) {
         FeedbackTextUpdaterIF.this.btnSaveDefaultUsernameActionPerformed(evt);
       }
       
     });
     this.lblNotification.setForeground(new java.awt.Color(0, 204, 0));
     this.lblNotification.setText("Username saved!");
     
     this.chkBoxAddToClipboard.setSelected(true);
     this.chkBoxAddToClipboard.setText("Add to system clipboard");
     
     this.btnClear.setText("Clear");
     this.btnClear.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(java.awt.event.ActionEvent evt) {
         FeedbackTextUpdaterIF.this.btnClearActionPerformed(evt);
       }
       
     });
     GroupLayout layout = new GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false).addComponent(this.btnClear, javax.swing.GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.btnGenerate, javax.swing.GroupLayout.Alignment.LEADING, -1, 102, 32767)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFeedbackText, -1, 257, 32767)).addGroup(layout.createSequentialGroup().addComponent(this.chkBoxAddToClipboard, -2, 179, -2).addGap(0, 0, 32767)).addGroup(layout.createSequentialGroup().addGap(14, 14, 14).addComponent(this.lblDefaultUsername).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtDefaultUsername, -2, 87, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnSaveDefaultUsername).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lblNotification, -1, -1, 32767))).addContainerGap()));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(this.txtFeedbackText, -2, -1, -2).addComponent(this.btnGenerate)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnClear).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(this.lblDefaultUsername).addComponent(this.txtDefaultUsername, -2, -1, -2).addComponent(this.btnSaveDefaultUsername).addComponent(this.lblNotification)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.chkBoxAddToClipboard).addGap(19, 19, 19)));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     pack();
   }
   
   private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {
     java.util.Calendar cal = java.util.Calendar.getInstance();
     cal.add(10, 1);
     java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy - hh:mm a");
     String updateString = "Update~" + this.pm.getProperty(0) + "~" + sdf.format(cal.getTime()) + "~ ";
     
 
     String existingText = this.txtFeedbackText.getText();
     this.txtFeedbackText.setText(updateString + existingText);
     this.lblNotification.setVisible(false);
     
     if (this.chkBoxAddToClipboard.isSelected()) {
       java.awt.datatransfer.StringSelection stringSelection = new java.awt.datatransfer.StringSelection(this.txtFeedbackText.getText());
       java.awt.datatransfer.Clipboard clpbrd = java.awt.Toolkit.getDefaultToolkit().getSystemClipboard();
       clpbrd.setContents(stringSelection, null);
     }
   }
   
   private void btnSaveDefaultUsernameActionPerformed(java.awt.event.ActionEvent evt)
   {
     this.pm.setProperty(0, this.txtDefaultUsername.getText());
     this.lblNotification.setVisible(true);
   }
   
   private void txtFeedbackTextFocusGained(java.awt.event.FocusEvent evt) {
     this.txtFeedbackText.selectAll();
   }
   
   private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {
     this.txtFeedbackText.setText("");
   }
 }


//GE Confidential