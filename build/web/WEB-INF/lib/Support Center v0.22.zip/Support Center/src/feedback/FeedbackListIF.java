/*
  v 0.15
  - Remade as a Netbeans form.
  v 0.16
  - Form would not release the fields when there was a connection failure, this has been corrected.
  v 0.18
  - Corrected a small bug when there is no database connection, the progress bar would linger endlessly.
  v 0.20
  - Implemented search functionality.
*/

package feedback;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.feedback.FeedbackData;


public class FeedbackListIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private SimpleDateFormat dateFormatter;
    private SimpleDateFormat timeFormatter;
    private ArrayList<FeedbackData> fbArray;
    private StringBuffer buf;
    private boolean done;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;    
    
    public FeedbackListIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     buf = new StringBuffer();
     progressBar.setIndeterminate(true);
     dateFormatter = new SimpleDateFormat("EEE, MM-dd-yyyy, ");
     timeFormatter = new SimpleDateFormat("HH:mm z");
     done = false;
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
             
     
     loadList();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FeedbackListIF.this.cleanClose(); }        
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
   private void cleanClose()
   {
     dispose();
   }
       
   private void protectFields(){
      btnSearch.setEnabled(false);
   }
   
   private void releaseFields(){
      btnSearch.setEnabled(true); 
      progressBar.setVisible(false);
   }
    
   private void loadList() { new Thread(new Runnable() {
       public void run() {
         progressBar.setVisible(true);
         populateFeedbackSummary();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
             progressBar.setValue((int)(Math.random() * 100.0D));
           }
         });
       }
     }).start(); 
   }
   
   private void populateFeedbackSummary()
   {
     String fbQuery = "";
     protectFields();
     try
     {
       lblNumberOpen.setText("<HTML><B>Fetching feedback list, please wait...</B></HTML>");
       
       editorResults.setText("");
       buf = new StringBuffer();
       
       conn = util.OracleConnectionManager.getConnection(0);
       
       fbQuery = "  SELECT fb.*, NVL((select tag_value from gets_lms_feedback_tags where tag_id = fb.feedback_tags), 'No Tag') as current_status FROM gets_etc.gets_etc_ESERVICES_feedback fb WHERE fb.STATUS <> 'CLOSED' AND fb.cust_name <> 'EMSAUser' ORDER BY fb.feedback_date DESC";
       
 
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       prepStm = conn.prepareStatement(fbQuery);
       
       rs = prepStm.executeQuery();
       
       fbArray = new ArrayList();
       
       while (rs.next()) {
         fbArray.add(new FeedbackData(rs.getString("feedback_id"), 
                 rs.getDate("feedback_date"), 
                 new java.sql.Date(rs.getTime("feedback_date").getTime()), 
                 rs.getString("status"), rs.getString("user_id"), 
                 rs.getString("user_fullname"), 
                 rs.getString("cust_location"), 
                 rs.getString("cust_name"), 
                 rs.getString("subsection"), 
                 rs.getString("suggestion"), 
                 rs.getString("contact_email"), 
                 rs.getString("response_msg"), 
                 rs.getString("critical"), 
                 rs.getString("phone_number"), 
                 rs.getString("response_By"), 
                 rs.getString("road_number"), 
                 rs.getString("current_status"), 
                 rs.getString("it_comments")));
       }
       
       for (FeedbackData f : fbArray) {
         buf.append("<FONT face=\"Courier\"><table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\"><tr>  <td width=\"16%\" align=\"center\" bgcolor=\"" + (f.getCritical().equals("1") ? "#FF3333" : "#9999FF") + "\">&nbsp;&nbsp;<font color=\"white\" " + "size=\"4\"><b>" + f.getStatus() + "</b></font>&nbsp;&nbsp;</td>" + "  <td colspan=\"2\" >&nbsp;<big><b>Feedback# " + f.getFeedbackId() + "</b></big><FONT size=6 " + ((f.getCurrentStatus().toLowerCase().trim().equals("not started")) || (f.getCurrentStatus().toLowerCase().trim().equals("no tag")) ? " color=RED " : "") + "> (" + f.getCurrentStatus() + ") </FONT>" + "</td>" + "  <td width=\"10%\" align=\"right\" nowrap><B>Date :</B>&nbsp;</td>" + "  <td width=\"10%\" nowrap>" + dateFormatter.format(f.getFeedbackDate()) + " " + timeFormatter.format(f.getFeedbackTime()) + "</td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Section:</b></td>" + "<td width=\"32%\" nowrap>" + f.getSubsection() + "</td>" + "<td width=\"32%\"></td>" + "<td align=\"right\" nowrap><b>Customer:</b></td>" + "<td>" + f.getCustomer() + "</td>" + "</tr>" + "<tr>" + " <td align=\"right\"  nowrap><b>Contact Name:</b></td>" + " <td nowrap>" + (f.getContactEmail() == null ? f.getUserName() : new StringBuilder().append("<a href=\"mailto:").append(f.getContactEmail()).append("\"><u>").append(f.getUserName()).append("</u></a>").toString()) + " (" + f.getUserId() + ")</td>" + " <td></td>" + " <td align=\"right\" nowrap><B>Shop:</B></td>" + " <td> " + (f.getCustomerLocation() == null ? "None" : f.getCustomerLocation()) + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Phone Number:</b></td>" + "<td colspan=\"2\" ><a>" + (null == f.getPhoneNumber() ? "None Available" : f.getPhoneNumber()) + "</a></td>" + "<td align=\"left\" nowrap><b>Last response by:</b></TD><TD>" + (f.getResponseBy() == null ? "-" : f.getResponseBy()) + "</td></tr>" + "<tr valign=\"top\">" + " <td align=\"right\"  nowrap><b>Suggestion:</b></td>" + " <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getSuggestion() + "</p>" + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Road Number:</b></TD><TD>" + (f.getRoadNumber() == null ? "None" : f.getRoadNumber()) + " </td></tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>Response:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + (f.getResponse() == null ? "<H2><FONT COLOR=\"RED\"> NO RESPONSE MESSAGE, PLEASE ANSWER THIS FEEDBACK</FONT></H2>" : f.getResponse()) + "</p>" + "</td>" + " </tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>IT Comments:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getItComments() + "</p>" + "</td>" + " </tr>" + " <tr>" + "  <td colspan=\"5\" align=\"center\"><H2><A HREF=\"http:/eservices.getransportation.com/eservices/" + "efeedback/login.jsp?row=" + f.getFeedbackId() + "\">CLICK HERE TO RESPOND FEEDBACK </A></H2>" + " </td>" + "</tr>" + " </table> </FONT><HR>");
       }
       
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
       editorResults.setText(buf.toString());
       int openNonCrits;
       int openCrits = openNonCrits = 0;
       
       prepStm = conn.prepareStatement("select count(*) as open_criticals from gets_etc.gets_etc_eservices_feedback where cust_name <> 'EMSAUser' and critical = '1' AND status!='CLOSED'");
       
       rs = prepStm.executeQuery();
       while (rs.next()) {
         openCrits = rs.getInt("open_criticals");
       }
       
       prepStm = conn.prepareStatement("select count(*) as open_non_criticals from gets_etc.gets_etc_eservices_feedback where cust_name <> 'EMSAUser' and critical = '0' AND status!='CLOSED'");
       
       rs = prepStm.executeQuery();
       while (rs.next()) {
         openNonCrits = rs.getInt("open_non_criticals");
       }
       
       lblNumberOpen.setText("<HTML><B>Currently there are: <FONT COLOR = RED>" + openCrits + " Critical </FONT> and <FONT COLOR = BLUE>" + openNonCrits + " Non-Critical </FONT> open feedbacks </B></HTML>");
 
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: FeedbackListIF, Method: searchOpenFeedbacks", fbQuery, buf.toString());
       releaseFields();
     }
       
     editorResults.setCaretPosition(0);
     done = true;
     progressBar.setVisible(false);
     releaseFields();
   }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnSearch = new javax.swing.JButton();
        lblNumberOpen = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        btnSearch.setText("Refresh");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        lblNumberOpen.setText("Feedback open count");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblNumberOpen, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSearch)
                        .addComponent(lblNumberOpen)))
                .addContainerGap())
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        editorResults.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                editorResultsHyperlinkUpdate(evt);
            }
        });
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        loadList();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void editorResultsHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {//GEN-FIRST:event_editorResultsHyperlinkUpdate
     if (evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
       try {
         java.awt.Desktop.getDesktop().browse(new java.net.URI(evt.getURL().toString()));
       } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(this, "Could not open browser, reason:\n" + e.getMessage(), "Error!", 0);
       }
     }
    }//GEN-LAST:event_editorResultsHyperlinkUpdate


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNumberOpen;
    private javax.swing.JProgressBar progressBar;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential