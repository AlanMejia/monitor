 package feedback;
 
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
 import java.sql.Connection;
 import java.sql.PreparedStatement;
 import java.sql.ResultSet;
import javax.swing.AbstractAction;
import javax.swing.Action;
 import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.JComponent;
 import javax.swing.JDesktopPane;
import javax.swing.JTextField;
 import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
 
 public class FeedbackCPTrackerUpdaterIF extends javax.swing.JInternalFrame
 {
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private java.text.SimpleDateFormat dateFormatter;
   private java.text.SimpleDateFormat timeFormatter;
   private java.util.ArrayList<util.feedback.FeedbackData> fbArray;
   private StringBuffer buf;
   private boolean done;
   private javax.swing.JTextArea areaLog;
   private javax.swing.JButton btnRun;
   private javax.swing.JLabel jLabel1;
   private javax.swing.JLabel jLabel2;
   private javax.swing.JScrollPane jScrollPane1;
   private javax.swing.JProgressBar progressBar;
   private JTextField txtFrom;
   private JTextField txtTo;
   
   public FeedbackCPTrackerUpdaterIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.progressBar.setIndeterminate(true);
     this.progressBar.setVisible(false);
     this.dateFormatter = new java.text.SimpleDateFormat("dd/mm/yyyy");
     this.done = false;
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FeedbackCPTrackerUpdaterIF.this.cleanClose(); }
       
 
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose()
   {
     dispose();
   }
   
   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         FeedbackCPTrackerUpdaterIF.this.progressBar.setVisible(true);
         FeedbackCPTrackerUpdaterIF.this.getCPTrackerList();
         while (FeedbackCPTrackerUpdaterIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
             FeedbackCPTrackerUpdaterIF.this.progressBar.setValue((int)(Math.random() * 100.0D));
           }
         });
       }
     }).start();
   }
   
   private void getCPTrackerList() {
     try {
       this.buf = new StringBuffer();
       this.conn = util.OracleConnectionManager.getConnection(0);
       
       if (this.conn == null) {
         this.areaLog.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       int receivedCriticals = 0;
       int closedCriticals = 0;
       int lastYearCriticals = 0;
       int lastYearNonCriticals = 0;
       int slaCriticals = 0;
       int receivedNonCriticals = 0;
       int closedNonCriticals = 0;
       int slaNonCriticals = 0;
       int openCriticals = 0;
       int openNonCriticals = 0;
       int createdUsers = 0;
       int inservicedLocomotives = 0;
       
 
       String query = "SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='1'  and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='1'  " + "and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser') " + " ) " + " AS Received_Criticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         receivedCriticals = this.rs.getInt("Received_Criticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "  SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='1'   and  RESPONSE_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS')  " + "and RESPONSE_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')  " + "and cust_name <> 'EMSAUser' and status ='CLOSED')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='1'  " + " and RESPONSE_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS')  " + "and RESPONSE_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')  " + " and cust_name <> 'EMSAUser' and status ='CLOSED') " + " ) " + " AS Closed_Criticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         closedCriticals = this.rs.getInt("Closed_Criticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='1'  and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') - 365" + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') - 365" + " and cust_name <> 'EMSAUser')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='1'  " + "and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') - 365" + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') - 365" + " and cust_name <> 'EMSAUser') " + " ) " + " AS Received_Criticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         lastYearCriticals = this.rs.getInt("Received_Criticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='0'  and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') - 365" + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') - 365" + " and cust_name <> 'EMSAUser')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='0'  " + "and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') - 365" + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') - 365" + " and cust_name <> 'EMSAUser') " + " ) " + " AS Received_NonCriticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         lastYearNonCriticals = this.rs.getInt("Received_NonCriticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "  SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='1' and  RESPONSE_DATE <= (FEEDBACK_DATE + 4/24)  and  FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') AND  " + " to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser' AND status='CLOSED')  " + " + " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='1'and  RESPONSE_DATE <= (FEEDBACK_DATE + 4/24) " + " and  FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') AND  " + " to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')       " + " and cust_name <> 'EMSAUser' AND status='CLOSED') " + " ) " + " AS Closed_Criticals_Within_SLA from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         slaCriticals = this.rs.getInt("Closed_Criticals_Within_SLA");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='0'  and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='0'  " + "and FEEDBACK_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "and FEEDBACK_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser') " + " ) " + " AS Received_NonCriticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         receivedNonCriticals = this.rs.getInt("Received_NonCriticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "  SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='0'   and  RESPONSE_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS')  " + "and RESPONSE_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')  " + "and cust_name <> 'EMSAUser' and status ='CLOSED')  " + " +  " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='0'  " + " and RESPONSE_DATE > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS')  " + "and RESPONSE_DATE < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')  " + " and cust_name <> 'EMSAUser' and status ='CLOSED') " + " ) " + " AS Closed_NonCriticals from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         closedNonCriticals = this.rs.getInt("Closed_NonCriticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "  SELECT ( (select count(*) from gets_etc.GETS_ETC_ARCHIVED_FEEDBACK where critical='0' and  RESPONSE_DATE <= (FEEDBACK_DATE + 1)  and  FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') AND  " + " to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser' AND status='CLOSED')  " + " + " + "(select count(*) from gets_etc.gets_etc_ESERVICES_feedback where critical='0'and  RESPONSE_DATE <= (FEEDBACK_DATE + 1) " + " and  FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') AND  " + " to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')       " + " and cust_name <> 'EMSAUser' AND status='CLOSED') " + " ) " + " AS Closed_NonCriticals_Within_SLA from dual";
       
 
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         slaNonCriticals = this.rs.getInt("Closed_NonCriticals_Within_SLA");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "select count(*) as open_criticals from gets_etc.gets_etc_eservices_feedback     where cust_name <> 'EMSAUser' and critical = '1' AND status!='CLOSED'";
       
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         openCriticals = this.rs.getInt("open_criticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "select count(*) as open_noncriticals from gets_etc.gets_etc_eservices_feedback     where cust_name <> 'EMSAUser' and critical = '0' AND status!='CLOSED'";
       
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         openNonCriticals = this.rs.getInt("open_noncriticals");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "select count(*) as createdUsers from gets_lms_service_employee where creation_date BETWEEN to_date('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "and to_date('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') and user_id is not null";
       
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         createdUsers = this.rs.getInt("createdUsers");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       query = "  Select count(*) as inserviced_locomotives from gets_lms_locomotive_all where in_service_date > to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS')" + "and in_service_date < to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS')";
       
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         inservicedLocomotives = this.rs.getInt("inserviced_locomotives");
       }
       this.prepStm.close();
       this.rs.close();
       
 
       this.buf.append("********* Regular details **********\n");
       this.buf.append("Received Criticals: " + receivedCriticals + "\n");
       this.buf.append("Closed Criticals: " + closedCriticals + "\n");
       this.buf.append("Last Years Criticals: " + lastYearCriticals + "\n");
       this.buf.append("Last Years Non Criticals: " + lastYearNonCriticals + "\n");
       this.buf.append("Criticals Closed SLA: " + slaCriticals + "\n");
       this.buf.append("Criticals SLA Compliance: " + slaCriticals * 100 / receivedCriticals + "%\n");
       this.buf.append("Received Non Criticals: " + receivedNonCriticals + "\n");
       this.buf.append("Closed Non Criticals: " + closedNonCriticals + "\n");
       this.buf.append("Non Criticals Closed SLA: " + slaNonCriticals + "\n");
       this.buf.append("Non Criticals SLA Compliance: " + slaNonCriticals * 100 / receivedNonCriticals + "%\n");
       this.buf.append("Open Criticals: " + openCriticals + "\n");
       this.buf.append("Open Non Criticals: " + openNonCriticals + "\n");
       this.buf.append("Total feedbacks: " + (openCriticals + openNonCriticals) + "\n");
       this.buf.append("Created users: " + createdUsers + "\n");
       this.buf.append("Inserviced locomotives: " + inservicedLocomotives + "\n");
       this.buf.append("\n********* Subsection details **********\n");
       
 
       query = "SELECT t.subsection, count(t.feedback_id) as amount from (select subsection, feedback_id from gets_etc_ESERVICES_feedback where    FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "    AND to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + "  and cust_name <> 'EMSAUser' " + " UNION ALL " + " select subsection, feedback_id from GETS_ETC_ARCHIVED_FEEDBACK where  " + "   FEEDBACK_DATE BETWEEN to_date ('" + this.txtFrom.getText() + " 00:00:00','mm/dd/yyyy HH24:MI:SS') " + "    AND to_date ('" + this.txtTo.getText() + " 23:59:59','mm/dd/yyyy HH24:MI:SS') " + " and cust_name <> 'EMSAUser') t " + "group by (t.subsection) order by t.subsection ";
       
 
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(query);
       this.rs = this.prepStm.executeQuery();
       while (this.rs.next()) {
         this.buf.append(this.rs.getString("subsection") + ": " + this.rs.getString("amount") + "\n");
       }
       this.prepStm.close();
       this.rs.close();
       
       this.areaLog.setText(this.buf.toString());
     }
     catch (Exception e) {
       javax.swing.JOptionPane.showMessageDialog(this, "Could not get feedback info, reason:\n" + e.getMessage(), "Error!", 0);
     }
     this.progressBar.setVisible(false);
   }
   
 
 
 
 
 
 
   private void initComponents()
   {
     this.jLabel1 = new javax.swing.JLabel();
     this.txtFrom = new JTextField();
     this.jLabel2 = new javax.swing.JLabel();
     this.txtTo = new JTextField();
     this.btnRun = new javax.swing.JButton();
     this.jScrollPane1 = new javax.swing.JScrollPane();
     this.areaLog = new javax.swing.JTextArea();
     this.progressBar = new javax.swing.JProgressBar();
     
     setDefaultCloseOperation(2);
     
     this.jLabel1.setText("From:");
     
     this.txtFrom.setText("mm/dd/yyyy");
     this.txtFrom.addFocusListener(new java.awt.event.FocusAdapter() {
       public void focusGained(java.awt.event.FocusEvent evt) {
         FeedbackCPTrackerUpdaterIF.this.txtFromFocusGained(evt);
       }
       
     });
     this.jLabel2.setText("To:");
     
     this.txtTo.setText("mm/dd/yyyy");
     this.txtTo.addFocusListener(new java.awt.event.FocusAdapter() {
       public void focusGained(java.awt.event.FocusEvent evt) {
         FeedbackCPTrackerUpdaterIF.this.txtToFocusGained(evt);
       }
       
     });
     this.btnRun.setText("Search!");
     this.btnRun.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(java.awt.event.ActionEvent evt) {
         FeedbackCPTrackerUpdaterIF.this.btnRunActionPerformed(evt);
       }
       
     });
     this.areaLog.setEditable(false);
     this.areaLog.setColumns(20);
     this.areaLog.setLineWrap(true);
     this.areaLog.setRows(5);
     this.areaLog.setWrapStyleWord(true);
     this.jScrollPane1.setViewportView(this.areaLog);
     
     javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFrom, -2, 106, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.txtTo, -2, 103, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnRun, -2, 104, -2).addGap(0, 57, 32767)).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.progressBar, -2, -1, -2))).addContainerGap()));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.txtFrom, -2, -1, -2).addComponent(this.jLabel2).addComponent(this.txtTo, -2, -1, -2).addComponent(this.btnRun)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 253, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.progressBar, -2, 27, -2).addContainerGap(-1, 32767)));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     pack();
   }
   
   private void btnRunActionPerformed(java.awt.event.ActionEvent evt) {
     loadList();
   }
   
   private void txtFromFocusGained(java.awt.event.FocusEvent evt) {
     this.txtFrom.selectAll();
   }
   
   private void txtToFocusGained(java.awt.event.FocusEvent evt) {
     this.txtTo.selectAll();
   }
 }


//GE Confidential