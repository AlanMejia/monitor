/*
  v0.13
   - Reconstructed as a Netbeans form.
   - Validated the entry of the days.
  v0.15
   - Centered the titles of the table headers
   - IT Comments will no longer appear as "null"
   - Made the Feedback ID a hyperlink, useful for last updates before a meeting.
*/

package feedback;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.CellStyle;
import util.feedback.FeedbackData;

public class AgedFeedbackIF extends JInternalFrame {

   private java.sql.Connection conn;
   private java.sql.PreparedStatement prepStm;
   private ResultSet rs;
   private SimpleDateFormat dateFormatter;
   private StringBuffer buf;
   private boolean done;
   private int days;
   private boolean resultsFound;
   private ArrayList<FeedbackData> fbs;   
   
    public AgedFeedbackIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearch);
     
     buf = new StringBuffer();
     progressBar.setIndeterminate(true);
     progressBar.setVisible(false);
     dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
     fbs = new ArrayList<>();
     done = false;
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { AgedFeedbackIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadList() {
     new Thread(new Runnable()
     {
       public void run() {
         searchAgedFeedbacks();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
             //progressBar.setValue((int)(Math.random() * 100.0D));
           }
         });
       }
     }).start();
   }
   
   private void searchAgedFeedbacks() {
     String agedFeedbacksQuery = "";
     StringBuffer buf = new StringBuffer();
     try
     {
       done = false;
       protectFields();
       
 
       conn = util.OracleConnectionManager.getConnection(0);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       agedFeedbacksQuery = "select fb.feedback_id, fb.feedback_date as fb_date, fb.user_fullname, fb.cust_location, fb.subsection, fb.suggestion, \n"
               + "       NVL(fb.it_comments, '-') as it_comments, NVL((select tag_value from gets_lms_feedback_tags where tag_id = fb.feedback_tags), 'Not Started') as current_status\n"
               + "    from gets_etc_eservices_feedback fb where fb.cust_name <> 'EMSAUser' and fb.feedback_date <= sysdate - " + days + " and fb.status<>'CLOSED' \n" + "   order by fb.feedback_id asc";
   
       prepStm = conn.prepareStatement(agedFeedbacksQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<HTML><TABLE border = 1>");
         buf.append("<TR bgcolor=\"#92CDDC\">"
                 + "<TD align=center><B>Feedback ID</B></TD>"
                 + "<TD align=center><B>Arrival Date</B></TD>"
                 + "<TD align=center><B>Status</B></TD>"
                 + "<TD align=center><B>Raised by</B></TD>"
                 + "<TD align=center><B>Customer Location</B></TD>"
                 + "<TD align=center><B>Subsection</B></TD>"
                 + "<TD align=center><B>Suggestion</B></TD>"
                 + "<TD align=center><B>Support Comments</B></TD>");         
         do
         {
           buf.append("<TR>"
                   + "<TD align=\"center\" ><A HREF=\"http:/eservices.getransportation.com/eservices/efeedback/login.jsp?row=" + rs.getString("feedback_id") + "\"><B>" + rs.getString("feedback_id") + "</B></A></TD>" 
                   + "<TD align=\"center\">" + dateFormatter.format(rs.getDate("fb_date")) + "</TD>" 
                   + "<TD align=\"center\">" + rs.getString("current_status") + "</TD>" 
                   + "<TD align=\"center\">" + rs.getString("user_fullname") + "</TD>" 
                   + "<TD align=\"center\">" + rs.getString("cust_location") + "</TD>" 
                   + "<TD align=\"center\">" + rs.getString("subsection") + "</TD>" 
                   + "<TD >" + rs.getString("suggestion") + "</TD>" 
                   + "<TD >" + rs.getString("it_comments") + "</TD>" 
                   + "</TR>");
           fbs.add(new FeedbackData(rs.getString("feedback_id"),
                    rs.getDate("fb_date"), 
                    rs.getString("current_status"),
                    rs.getString("user_fullname"),
                    rs.getString("cust_location"),
                    rs.getString("subsection"),
                    rs.getString("suggestion"),
                    rs.getString("it_comments")));           
         }
         while (rs.next());
         resultsFound = true;
       } else {
         editorResults.setText("<HTML><Font color=BLACK><H3>No old feedbacks more than " + days + " days old.</H3></FONT></HTML>");
         resultsFound = false;
       }
       
       editorResults.setText(buf.toString());
       
       prepStm.close();
       rs.close();
       releaseFields();
       done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtDays: " + txtDays.getText() + "\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: AgedFeedbackIF, Method: searchAgedFeedbacks", agedFeedbacksQuery, buf.toString());
       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();        
     }
   }
   
   private void protectFields()
   {
     btnSearch.setEnabled(false);
     btnSaveToFile.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     btnSaveToFile.setEnabled(true);     
     progressBar.setVisible(false);
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtDays = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();
        btnSaveToFile = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        editorResults.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                editorResultsHyperlinkUpdate(evt);
            }
        });
        jScrollPane1.setViewportView(editorResults);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Pull feedbacks older than");

        txtDays.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDays.setText("10");
        txtDays.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDaysFocusGained(evt);
            }
        });

        jLabel2.setText("days");

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        btnSaveToFile.setText("Save to File");
        btnSaveToFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveToFileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDays, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSaveToFile, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(btnSearch)
                    .addComponent(btnSaveToFile)))
        );

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 557, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDaysFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDaysFocusGained
        txtDays.selectAll();
    }//GEN-LAST:event_txtDaysFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        //We're starting, validate input. Is it empty?
        if(txtDays.getText().isEmpty()){
            editorResults.setText("<HTML><H3>Please enter the number of days.</H3></HTML>");
        }        
        //Did they input a number?
        try {
            days = Integer.parseInt(txtDays.getText());
            //Yes, we survived
            if(days > 0){
                //all clear, go ahead
                loadList();
            }
            else {
                editorResults.setText("<HTML><H3>Please enter more than 0 days.</H3></HTML>");                                
            }
        }catch(Exception e){
            editorResults.setText("<HTML><H3>Please enter the number of days.</H3></HTML>");            
        }         
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnSaveToFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveToFileActionPerformed
        if(resultsFound){
            saveToFile();
        }
    }//GEN-LAST:event_btnSaveToFileActionPerformed

    private void editorResultsHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {//GEN-FIRST:event_editorResultsHyperlinkUpdate
     if (evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
       try {
         java.awt.Desktop.getDesktop().browse(new java.net.URI(evt.getURL().toString()));
       } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(this, "Could not open browser, reason:\n" + e.getMessage(), "Error!", 0);
       }
     }
    }//GEN-LAST:event_editorResultsHyperlinkUpdate

    private void saveToFile(){
        try {
         POIFSFileSystem fs = new org.apache.poi.poifs.filesystem.POIFSFileSystem(new java.io.FileInputStream("aged_fb_template.xls"));
         HSSFWorkbook wb = new org.apache.poi.hssf.usermodel.HSSFWorkbook(fs);
         HSSFSheet sheet = wb.getSheetAt(0); 

         int numRow = 1;
         boolean blank = false;
         CellStyle style = sheet.getRow(0).getCell(8).getCellStyle();
         style.setBorderBottom((short)1);
         style.setBorderLeft((short)1);
         style.setBorderRight((short)1);    
         style.setBorderTop((short)1);
         
         for(FeedbackData f : fbs){
             HSSFRow row = sheet.createRow(numRow);
             row.createCell(0).setCellValue(f.getFeedbackId());
             row.getCell(0).setCellStyle(style);
             row.createCell(1).setCellValue(f.getFeedbackDate());
             row.getCell(1).setCellStyle(style);
             row.createCell(2).setCellValue(f.getStatus());
             row.getCell(2).setCellStyle(style);
             row.createCell(3).setCellValue(f.getUserName());
             row.getCell(3).setCellStyle(style);
             row.createCell(4).setCellValue(f.getCustomerLocation());
             row.getCell(4).setCellStyle(style);
             row.createCell(5).setCellValue(f.getSubsection());
             row.getCell(5).setCellStyle(style);
             row.createCell(6).setCellValue(f.getSuggestion());
             row.getCell(6).setCellStyle(style);
             row.createCell(7).setCellValue(f.getItComments());
             row.getCell(7).setCellStyle(style);
             numRow++;
           }         
        }catch (Exception e){
            
        }
        
         try {
            JFileChooser fc = new JFileChooser(); 
            fc.setFileFilter(new util.FolderFilter());
            fc.setFileSelectionMode(1);

            int returnVal = fc.showOpenDialog(this);             
            org.apache.commons.io.FileUtils.write(new File(fc.getSelectedFile().getAbsolutePath() + "\\\\AgedFeedbacks.xls"), this.editorResults.getText());
            javax.swing.JOptionPane.showMessageDialog(null, "Operation Successful!", "File saved!", -1);
          } catch (Exception e) {
            System.out.println(e.getMessage()); 
          }  
 
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSaveToFile;
    private javax.swing.JButton btnSearch;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtDays;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential