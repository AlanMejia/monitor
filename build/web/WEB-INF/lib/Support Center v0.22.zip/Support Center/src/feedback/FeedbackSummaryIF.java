/*
  v 0.16
  - Form would not release the fields when there was a connection failure, this has been corrected.  
  v 0.18
  - Corrected a small bug when there is no database connection, the progress bar would linger endlessly.
  v 0.20
  - Implemented Search functionality.
*/

package feedback;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JEditorPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.ToolTipManager;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import util.feedback.FeedbackData;


public class FeedbackSummaryIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private SimpleDateFormat dateFormatter;
    private SimpleDateFormat timeFormatter;
    private ArrayList<FeedbackData> fbArray;
    private StringBuffer buf;
    private boolean done;  
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;        
    
    public FeedbackSummaryIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     buf = new StringBuffer();
     progressBar.setIndeterminate(true);
     dateFormatter = new SimpleDateFormat("EEE, MM-dd-yyyy, ");
     timeFormatter = new SimpleDateFormat("HH:mm z");
     done = false;
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
      
     
     loadList();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FeedbackSummaryIF.this.cleanClose(); }        
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     //Set up a custom EditorPane
//     editorResults = new JEditorPane() {
//
//        @Override
//        public String getToolTipText(MouseEvent evt) {
//            String text = null;
//            int pos = viewToModel(evt.getPoint());
//            if (pos >= 0) {
//                HTMLDocument hdoc = (HTMLDocument) getDocument();
//                javax.swing.text.Element e = hdoc.getCharacterElement(pos);
//                AttributeSet a = e.getAttributes();
//
//                SimpleAttributeSet value = (SimpleAttributeSet) a.getAttribute(HTML.Tag.A);
//                if (value != null) {
//                    String href = (String) value.getAttribute(HTML.Attribute.TITLE);
//                    if (href != null) {
//                        text = href;
//                    }
//                }
//            }
//            return text;
//        }
//    };     
//    editorResults.setEditable(false);
//    editorResults.setContentType("text/html");
//    ToolTipManager.sharedInstance().registerComponent(editorResults);
    
    //((JPanel)scrollResults.getViewport().getView()).add(editorResults); 
    //(JPanel)scrollResults.getViewport().getView().add(editorResults);
    
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/   
   }//constructor
   
    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
      
    
   private void cleanClose()
   {
     dispose();
   }
       
   private void protectFields(){
      btnSearch.setEnabled(false);
   }
   
   private void releaseFields(){
      btnSearch.setEnabled(true);
      progressBar.setVisible(false);
   }
    
   private void loadList() { new Thread(new Runnable() {
       public void run() {
         progressBar.setVisible(true);
         populateFeedbackSummary();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {
             progressBar.setValue((int)(Math.random() * 100.0D));
           }
         });
       }
     }).start(); 
   }
   
   private void populateFeedbackSummary()
   {
     String fbQuery = "";
     protectFields();
     try
     {
       lblNumberOpen.setText("<HTML><B>Fetching feedback list, please wait...</B></HTML>");
       
       editorResults.setText("");
       buf = new StringBuffer();
       
       conn = util.OracleConnectionManager.getConnection(0);
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }       
       
       fbQuery = " SELECT * FROM (\n" +
            " SELECT feedback_id, feedback_date, critical, cust_location, user_id, user_fullname, subsection, suggestion, "
               + "NVL(road_number, '-') as road_number, NVL(it_comments, '-') as it_comments, \n" +
            " NVL((select tag_value from gets_lms_feedback_tags where tag_id = fb.feedback_tags), 'No Tag') as current_status," +
            " cust_name, NVL(response_msg, '-') as response \n" +
            " FROM gets_etc.gets_etc_ESERVICES_feedback fb WHERE \n" +
            " fb.STATUS <> 'CLOSED' AND fb.cust_name <> 'EMSAUser' \n" +
            " ) ORDER BY current_status ASC "; 
       
       prepStm = conn.prepareStatement(fbQuery);
       
       rs = prepStm.executeQuery();
       
       fbArray = new ArrayList<>();
               
       while (rs.next()) {
         fbArray.add(new FeedbackData(rs.getString("feedback_id"), 
                 rs.getDate("feedback_date"), 
                 rs.getString("critical"), 
                 rs.getString("cust_location"), 
                 rs.getString("user_id"), 
                 rs.getString("subsection"), 
                 rs.getString("user_fullname"), 
                 rs.getString("suggestion"), 
                 rs.getString("road_number"), 
                 rs.getString("it_comments"), 
                 rs.getString("current_status"),
                 rs.getString("cust_name"),
                 rs.getString("response")));
       }
       
       //Now sort the array by tag
       ArrayList<FeedbackData> sortedFBs = new ArrayList<>();
       
       //First add all of the FBs that have "No Tag" or "Not Started"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("no tag") || f.getCurrentStatus().toLowerCase().trim().equals("not started")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now any other tag that is not "Pending on Analyst" / "Pending on User Input" / "Pending on Third Party"
       //or "Need User Confirm to Close" or "Script Sent"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(!f.getCurrentStatus().toLowerCase().trim().equals("pending on analyst") && 
               !f.getCurrentStatus().toLowerCase().trim().equals("pending on third party") &&
               !f.getCurrentStatus().toLowerCase().trim().equals("pending on user input") &&
               !f.getCurrentStatus().toLowerCase().trim().equals("script sent") &&                   
               !f.getCurrentStatus().toLowerCase().trim().equals("need user confirm to close")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now all the "Pending on User Input"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("pending on user input")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now all the "Pending on Analyst"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("pending on analyst")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now all the "Pending on Third Party"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("pending on third party")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now all the "Need user confirm to close"
       if(!fbArray.isEmpty()){
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("need user confirm to close")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now all the "Script Sent"
       if(!fbArray.isEmpty()){       
        for(FeedbackData f : fbArray){
            if(f.getCurrentStatus().toLowerCase().trim().equals("script sent")){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted
            }//if tag condition               
           }//for
       }//if the original array is empty
       
       //Now anything that I may have missed
       if(!fbArray.isEmpty()){
           for(FeedbackData f : fbArray){
                if(!f.isSorted()){                    
                    f.setSorted(true);
                    fbArray.set(fbArray.indexOf(f), f);
                    sortedFBs.add(f);
                } //if Sorted             
           }//for
       }//if the original array is empty
           
       //Display the sorted list
       buf.append("<HTML><BODY link=\"black\" vlink=\"black\" alink=\"black\"><TABLE border=1 >");
       buf.append("<TR bgcolor = #92CDDC>"
               + "<TD align=CENTER><B>Current Status</B></TD>"
               + "<TD align=CENTER><B>FB #</B></TD>"
               + "<TD align=CENTER><B>Subsection</B></TD>"
               + "<TD align=CENTER><B>Customer Location</B></TD>"
               + "<TD align=CENTER><B>Road #</B></TD>"               
               + "<TD align=CENTER><B>Suggestion</B></TD>"
               + "<TD align=CENTER><B>Response</B></TD>"
               + "<TD align=CENTER><B>IT Comments</B></TD>"
               + "</TR>");
       
       for (FeedbackData f : sortedFBs) {
           buf.append("<TR>"
                   + "<TD align = CENTER> <FONT color=" + ((f.getCurrentStatus().toLowerCase().trim().equals("not started")) ||
                           (f.getCurrentStatus().toLowerCase().trim().equals("no tag")) ? " RED >" : " BLACK >")
                   + f.getCurrentStatus() + "</FONT></TD>"
                   + "<TD align = CENTER bgcolor= " + (f.getCritical().equals("1") ? "#FF3333" : "#9999FF") + " title=\"" + dateFormatter.format(f.getFeedbackDate()) + "\"><B>" + f.getFeedbackId() + "</B></TD>"
                   + "<TD align = center><A HREF=\"http:/eservices.getransportation.com/eservices/efeedback/login.jsp?row=" + f.getFeedbackId() + "\">" + f.getSubsection() + "</A></TD>"
                   + "<TD align = center title = \"" + f.getUserName() + " ( " + f.getUserId() + " )\"><FONT size=-1>" + f.getCustomer() + " (" + f.getCustomerLocation() + ")</FONT></TD>"
                   + "<TD align=CENTER>" + f.getRoadNumber() + "</TD>"
                   + "<TD><FONT size=-1>" + f.getSuggestion() + "</FONT></TD>"
                   + "<TD " + (f.getResponse().equals("-") ? " bgcolor = RED" : "" ) + "><FONT size=-1>" + f.getResponse() + "</FONT></TD>"
                   + "<TD " + (f.getItComments().equals("-") ? "align=center" : "") + "><FONT size=-1>" + f.getItComments() + "</FONT></TD>");
         
           //buf.append("<FONT face=\"Courier\"><table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\"><tr>  <td width=\"16%\" align=\"center\" bgcolor=\"" + (f.getCritical().equals("1") ? "#FF3333" : "#9999FF") + "\">&nbsp;&nbsp;<font color=\"white\" " + "size=\"4\"><b>" + f.getStatus() + "</b></font>&nbsp;&nbsp;</td>" + "  <td colspan=\"2\" >&nbsp;<big><b>Feedback# " + f.getFeedbackId() + "</b></big><FONT size=6 " + ((f.getCurrentStatus().toLowerCase().trim().equals("not started")) || (f.getCurrentStatus().toLowerCase().trim().equals("no tag")) ? " color=RED " : "") + "> (" + f.getCurrentStatus() + ") </FONT>" + "</td>" + "  <td width=\"10%\" align=\"right\" nowrap><B>Date :</B>&nbsp;</td>" + "  <td width=\"10%\" nowrap>" + dateFormatter.format(f.getFeedbackDate()) + " " + timeFormatter.format(f.getFeedbackTime()) + "</td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Section:</b></td>" + "<td width=\"32%\" nowrap>" + f.getSubsection() + "</td>" + "<td width=\"32%\"></td>" + "<td align=\"right\" nowrap><b>Customer:</b></td>" + "<td>" + f.getCustomer() + "</td>" + "</tr>" + "<tr>" + " <td align=\"right\"  nowrap><b>Contact Name:</b></td>" + " <td nowrap>" + (f.getContactEmail() == null ? f.getUserName() : new StringBuilder().append("<a href=\"mailto:").append(f.getContactEmail()).append("\"><u>").append(f.getUserName()).append("</u></a>").toString()) + " (" + f.getUserId() + ")</td>" + " <td></td>" + " <td align=\"right\" nowrap><B>Shop:</B></td>" + " <td> " + (f.getCustomerLocation() == null ? "None" : f.getCustomerLocation()) + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Phone Number:</b></td>" + "<td colspan=\"2\" ><a>" + (null == f.getPhoneNumber() ? "None Available" : f.getPhoneNumber()) + "</a></td>" + "<td align=\"left\" nowrap><b>Last response by:</b></TD><TD>" + (f.getResponseBy() == null ? "-" : f.getResponseBy()) + "</td></tr>" + "<tr valign=\"top\">" + " <td align=\"right\"  nowrap><b>Suggestion:</b></td>" + " <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getSuggestion() + "</p>" + " </td>" + "</tr>" + "<tr>" + "<td align=\"right\" nowrap><b>Road Number:</b></TD><TD>" + (f.getRoadNumber() == null ? "None" : f.getRoadNumber()) + " </td></tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>Response:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + (f.getResponse() == null ? "<H2><FONT COLOR=\"RED\"> NO RESPONSE MESSAGE, PLEASE ANSWER THIS FEEDBACK</FONT></H2>" : f.getResponse()) + "</p>" + "</td>" + " </tr>" + " <tr valign=\"top\">" + "  <td align=\"right\"  nowrap><b>IT Comments:</b></td>" + "  <td colspan=\"4\" >" + "  <p align=\"justify\">" + f.getItComments() + "</p>" + "</td>" + " </tr>" + " <tr>" + "  <td colspan=\"5\" align=\"center\"><H2><A HREF=\"http:/eservices.getransportation.com/eservices/" + "efeedback/login.jsp?row=" + f.getFeedbackId() + "\">CLICK HERE TO RESPOND FEEDBACK </A></H2>" + " </td>" + "</tr>" + " </table> </FONT><HR>");
       }
       
       editorResults.setText(buf.toString());
       int openNonCrits;
       int openCrits = openNonCrits = 0;
       
       prepStm = conn.prepareStatement("select count(*) as open_criticals from gets_etc.gets_etc_eservices_feedback where cust_name <> 'EMSAUser' and critical = '1' AND status!='CLOSED'");
       
       rs = prepStm.executeQuery();
       while (rs.next()) {
         openCrits = rs.getInt("open_criticals");
       }
       
       prepStm = conn.prepareStatement("select count(*) as open_non_criticals from gets_etc.gets_etc_eservices_feedback where cust_name <> 'EMSAUser' and critical = '0' AND status!='CLOSED'");
       
       rs = prepStm.executeQuery();
       while (rs.next()) {
         openNonCrits = rs.getInt("open_non_criticals");
       }
       
       lblNumberOpen.setText("<HTML><B>Currently there are: <FONT COLOR = RED>" + openCrits + " Critical </FONT> and <FONT COLOR = BLUE>" + openNonCrits + " Non-Critical </FONT> open feedbacks </B></HTML>");
 
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: FeedbackSummaryIF, Method: populateFeedbackSummary", fbQuery, buf.toString());
       editorResults.setText("An error ocurred, please check the logs.");
       releaseFields();
     }
       
     editorResults.setCaretPosition(0);
     done = true;
     progressBar.setVisible(false);
     releaseFields();
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnSearch = new javax.swing.JButton();
        lblNumberOpen = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        scrollResults = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnSearch.setText("Refresh");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        lblNumberOpen.setText("Feedback open count");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblNumberOpen, javax.swing.GroupLayout.DEFAULT_SIZE, 805, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSearch)
                        .addComponent(lblNumberOpen)))
                .addContainerGap())
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        editorResults.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                editorResultsHyperlinkUpdate(evt);
            }
        });
        scrollResults.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(scrollResults)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(scrollResults, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        loadList();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void editorResultsHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {//GEN-FIRST:event_editorResultsHyperlinkUpdate
     if (evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
       try {
         java.awt.Desktop.getDesktop().browse(new java.net.URI(evt.getURL().toString()));
       } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(this, "Could not open browser, reason:\n" + e.getMessage(), "Error!", 0);
       }
     }
    }//GEN-LAST:event_editorResultsHyperlinkUpdate


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblNumberOpen;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JScrollPane scrollResults;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential