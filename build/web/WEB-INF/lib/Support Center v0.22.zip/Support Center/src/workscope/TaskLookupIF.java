/* v.12
   - Reconstructed as Netbeans Form.
   - Enh: Trimmed the task name entry. It will also ignore cases.
*/

package workscope;

import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import util.JErrorLog;
import util.OracleConnectionManager;

public class TaskLookupIF extends JInternalFrame {

   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   
    public TaskLookupIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearch);

     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { TaskLookupIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void getTaskInfo() {
     new Thread(new Runnable()
     {
       public void run() {
         fetchTaskInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void protectFields()
   {
     btnSearch.setEnabled(false);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
   }
   
   private void fetchTaskInfo() {
     String taskQuery = "";
     String lovQuery = "";
     StringBuffer buf = new StringBuffer();
     try
     {
       done = false;
       protectFields();
       
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       taskQuery = "select qc.char_id, qc.name as task_number, qc.char_type_code, qc.mandatory_flag, \n"
               + "NVL(qc.target_value, '-') as target_value,  NVL(qc.upper_spec_limit, '-') as upper_spec_limit,"
               + "NVL(qc.lower_spec_limit, '-') as lower_spec_limit, NVL(attribute3, '-') as lovTask, "
               + " (select char_id from gets_lms_qa_chars where name = qc.attribute3) as lovTaskId ,"
               + "qc.data_entry_hint \n"
               + "from gets_lms_qa_chars qc\nwhere upper(qc.name) like '" + txtTaskNumber.getText().trim().toUpperCase() + "'";
      
       prepStm = conn.prepareStatement(taskQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<HTML>");
         do {
           buf.append("<TABLE border = 1 width=100%>"
                   + "<TR>"
                   + "<TD bgcolor=\"#92CDDC\" align=\"center\"><B>Task Name</B></TD>"
                   + "<TD colspan=2>" + rs.getString("task_number") + " (<B>ID:</B> " + rs.getString("char_id") + ")</TD>" + 
                   "</TR>" + 
                   "<TR>" + 
                   "<TD bgcolor=\"#92CDDC\" align=\"center\"><B>Task Text</B></TD>" + 
                   "<TD colspan=2>" + rs.getString("data_entry_hint") + "</TD>" + 
                   "</TR>" + 
                   "<TR>" + 
                   "<TD align=\"center\"><B>Type: </B> " + rs.getString("char_type_code") + "</TD>" + 
                   "<TD align=\"center\"><B>Mandatory Flag: </B> " + rs.getString("mandatory_flag") + " </TD>" + 
                   "<TD align=\"center\"><B>LOV Task: </B> " + rs.getString("lovTask") + ( null == rs.getString("lovTaskId") ? "" : " (<B>ID:</B> " + rs.getString("lovTaskId") + ")" ) + " </TD>" + "</TR>" + 
                   "<TR>" + 
                   "<TD align=\"center\" width=33% bgcolor=\"#92CDDC\"><B>Lower Spec Limit</B></TD>" + 
                   "<TD align=\"center\" width=33% bgcolor=\"#92CDDC\"><B>Target</B></TD>" + 
                   "<TD align=\"center\" width=33% bgcolor=\"#92CDDC\"><B>Upper Spec Limit</B></TD>" + 
                   "</TR>" + 
                   "<TR>" + 
                   "<TD align=\"center\" width=33%>" + rs.getString("lower_spec_limit") + "</TD>" + 
                   "<TD align=\"center\" width=33%>" + rs.getString("target_value") + "</TD>" + 
                   "<TD align=\"center\" width=33%>" + rs.getString("upper_spec_limit") + "</TD>" + 
                   "</TR>");

           if (!rs.getString("lovTask").equals("-")) {
             lovQuery = "select cust.customer_name_phonetic, qcv.lookup_type, qcv.lookup_type_id, qcv.primary_description, qcv.value, \n   qcv.defect_flag, qcv.sort_sequence \n from gets_lms_qa_char_values qcv, ar_customers cust where \n  qcv.customer_id = cust.customer_id AND\n  qcv.char_id = (select char_id from gets_lms_qa_chars where name = '" + rs.getString("lovTask") + "')\n" + "  order by cust.customer_name asc, qcv.sort_sequence asc";
   
             PreparedStatement prepStm2 = conn.prepareStatement(lovQuery);
             ResultSet rs2 = prepStm2.executeQuery();
             String currCust = "";
             int row = 0;
             
             if (rs2.next())
             {
               buf.append("<TR>"
                       + "<TD colspan=3>"
                       + "<TABLE border=1 width=100%>"
                       + "<TR>"
                       + "<TD colspan=6 align=\"center\" bgcolor=\"#92CDDC\"><B>LOV INFORMATION</B></TD></TR>"
                       + "<TR><TD align=\"center\" bgcolor=\"#92CDDC\"><B>Cust.</B></TD>"
                       + "<TD align=\"center\" bgcolor=\"#92CDDC\"><B>Lookup Type / ID</B></TD>"
                       + "<TD align=\"center\" bgcolor=\"#92CDDC\"><B>Seq.</B></TD>"
                       + "<TD align=\"center\" bgcolor=\"#92CDDC\"><B>Description</B></TD>"
                       + "<TD align=\"center\" bgcolor=\"#92CDDC\"><B>Value</B></TD>"
                       + "<TD align=\"center\" bgcolor=\"#92CDDC\"><B>Add Def?</B></TD>"
                       + "</TR>");

               currCust = rs2.getString("customer_name_phonetic");
               do
               {
                 if (!currCust.equals(rs2.getString("customer_name_phonetic"))) {
                   currCust = rs2.getString("customer_name_phonetic");
                   row++;
                 }
                 
                 buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=\"#DDDDDD\"") + ">" + "<TD align=\"center\">" + rs2.getString("customer_name_phonetic") + "</TD>" + 
                         "<TD align=\"center\">" + rs2.getString("lookup_type") + " / " + rs2.getString("lookup_type_id") + "</TD>" + 
                         "<TD align=\"center\">" + rs2.getString("sort_sequence") + "</TD>" + 
                         "<TD align=\"center\">" + rs2.getString("primary_description") + "</TD>" + 
                         "<TD align=\"center\">" + rs2.getString("value") + "</TD>" + 
                         "<TD align=\"center\">" + rs2.getString("defect_flag") + "</TD>" + 
                         "</TR>"); 
               }
               while (rs2.next());
               buf.append("</TABLE></TD></TR>");
             }
           }
           
           buf.append("</TABLE><BR>");
         } while (rs.next());
       } else {
         editorResults.setText("<HTML><H3>No Task found with that criteria.</H3></HTML>");
         prepStm.close();
         rs.close();
         releaseFields();
         return;
       }
       
       prepStm.close();
       rs.close();
       
       releaseFields();
       done = true;
       editorResults.setText(buf.toString());
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtTaskNumber: " + txtTaskNumber.getText() + "\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: TaskLookupIF, Method: fetchTaskInfo", taskQuery, buf.toString());
       
 
       releaseFields();
       editorResults.setText("<HTML><H3>An error occurred, please check the logs.<H3></HTML>");
     }
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }   
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtTaskNumber = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Task Number:");

        txtTaskNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTaskNumberFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTaskNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 266, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtTaskNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if (txtTaskNumber.getText().trim().isEmpty()) {
       editorResults.setText("<HTML><H3>Please enter the task name. Use %% for wildcard search.");
       return;
     }
     getTaskInfo();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtTaskNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTaskNumberFocusGained
        txtTaskNumber.selectAll();
    }//GEN-LAST:event_txtTaskNumberFocusGained



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtTaskNumber;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential