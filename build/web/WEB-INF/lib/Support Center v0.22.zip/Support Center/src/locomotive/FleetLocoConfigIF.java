/*
 v 0.15
  - Restored as a Netbeans form
  - Added LNG comboBox as per new config type added on May 19th 2015.
  - Removed the locomotive id to clean up the table.
 V 0.19
  - editorScript was set up as an HTML type textEditor, this has been corrected. 
    The SQL output should no longer come out as an HTML file.
 v 0.20
  - Added "Save Fleet Details" button to save the details of the fleet to an XLS file for easy sharing. Well, its actualy an HTML file, 
    but Excel is smart enough and we leave the formatting as an exercise for the reader.
 v 0.22
  - Added find functionality
  - Added "Locomotive Model" and "Inverter Type" for the new CBTA entries added on July 2015.
*/

package locomotive;

import static com.sun.java.accessibility.util.SwingEventMonitor.addInternalFrameListener;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.locomotive.CBTAEntry;
import util.locomotive.LocomotiveData;

public class FleetLocoConfigIF extends JInternalFrame {

   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private ArrayList<LocomotiveData> locomotives;
   private ArrayList<CBTAEntry> hpfpList;
   private ArrayList<CBTAEntry> airDryerList;
   private ArrayList<CBTAEntry> tractionMotorList;
   private ArrayList<CBTAEntry> aessList;
   private ArrayList<CBTAEntry> locoTypeList;
   private ArrayList<CBTAEntry> airBrakeList;
   private ArrayList<CBTAEntry> engineHPList;
   private ArrayList<CBTAEntry> videoSystemList;
   private ArrayList<CBTAEntry> truckTypeList;
   private ArrayList<CBTAEntry> blasterTypeList;
   private ArrayList<CBTAEntry> numberOfAxlesList;
   private ArrayList<CBTAEntry> lngList;   
   private ArrayList<CBTAEntry> locoModelList;   
   private ArrayList<CBTAEntry> inverterTypeList;   
   private DefaultComboBoxModel hpfpModel;
   private DefaultComboBoxModel airDryerModel;
   private DefaultComboBoxModel tractionMotorModel;
   private DefaultComboBoxModel aessModel;
   private DefaultComboBoxModel locoTypeModel;
   private DefaultComboBoxModel airBrakeModel;
   private DefaultComboBoxModel engineHPModel;
   private DefaultComboBoxModel videoSystemModel;
   private DefaultComboBoxModel truckTypeModel;
   private DefaultComboBoxModel blasterTypeModel;
   private DefaultComboBoxModel numberOfAxlesModel;
   private DefaultComboBoxModel lngModel;
   private DefaultComboBoxModel locoModelModel;
   private DefaultComboBoxModel inverterTypeModel;
   
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;   
    
    public FleetLocoConfigIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearch);
     
     locomotives = new ArrayList();
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FleetLocoConfigIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
    
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorFleetResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorFleetResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorFleetResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorFleetResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorFleetResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorFleetResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
     
     
   }
   
    private void findTextInResults(){
        Document document = editorFleetResults.getDocument();
        editorFleetResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorFleetResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorFleetResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }         
    
   private void cleanClose() { 
       dispose(); 
   }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtFleetName = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        comboHPFP = new javax.swing.JComboBox();
        comboAirDryer = new javax.swing.JComboBox();
        comboTractionMotor = new javax.swing.JComboBox();
        comboAESS = new javax.swing.JComboBox();
        comboLocoType = new javax.swing.JComboBox();
        comboAirBrake = new javax.swing.JComboBox();
        comboEngineHP = new javax.swing.JComboBox();
        comboVideoSystem = new javax.swing.JComboBox();
        comboTruckType = new javax.swing.JComboBox();
        comboBlasterType = new javax.swing.JComboBox();
        comboNumberAxles = new javax.swing.JComboBox();
        comboLNG = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btnGenerate = new javax.swing.JButton();
        btnSaveScriptToFile = new javax.swing.JButton();
        btnSaveFleetDetails = new javax.swing.JButton();
        comboLocoModel = new javax.swing.JComboBox();
        comboInverterType = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorFleetResults = new javax.swing.JEditorPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        editorScript = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Fleet Name:");

        txtFleetName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFleetNameFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        comboHPFP.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboHPFP.setEnabled(false);

        comboAirDryer.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboAirDryer.setEnabled(false);

        comboTractionMotor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboTractionMotor.setEnabled(false);

        comboAESS.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboAESS.setEnabled(false);

        comboLocoType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboLocoType.setEnabled(false);

        comboAirBrake.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboAirBrake.setEnabled(false);

        comboEngineHP.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboEngineHP.setEnabled(false);

        comboVideoSystem.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboVideoSystem.setEnabled(false);

        comboTruckType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboTruckType.setEnabled(false);

        comboBlasterType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboBlasterType.setEnabled(false);

        comboNumberAxles.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboNumberAxles.setEnabled(false);

        comboLNG.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboLNG.setEnabled(false);

        jLabel2.setText("HPFP");

        jLabel3.setText("Air Dryer");

        jLabel4.setText("Traction Motor");

        jLabel5.setText("AESS");

        jLabel6.setText("Loco Type");

        jLabel7.setText("Air Brake");

        jLabel8.setText("Engine HP");

        jLabel9.setText("Video System");

        jLabel10.setText("Truck Type");

        jLabel11.setText("Blaster System");

        jLabel12.setText("Number of Axles");

        jLabel13.setText("LNG");

        btnGenerate.setText("Generate");
        btnGenerate.setEnabled(false);
        btnGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerateActionPerformed(evt);
            }
        });

        btnSaveScriptToFile.setText("Save Script To File");
        btnSaveScriptToFile.setEnabled(false);
        btnSaveScriptToFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveScriptToFileActionPerformed(evt);
            }
        });

        btnSaveFleetDetails.setText("Save Fleet Details");
        btnSaveFleetDetails.setEnabled(false);
        btnSaveFleetDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveFleetDetailsActionPerformed(evt);
            }
        });

        comboLocoModel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboLocoModel.setEnabled(false);

        comboInverterType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--" }));
        comboInverterType.setEnabled(false);

        jLabel14.setText("Loco Model");

        jLabel15.setText("Inverter Type");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btnSaveScriptToFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(comboHPFP, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboAirDryer, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboTractionMotor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboAESS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboLocoType, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboAirBrake, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboEngineHP, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboVideoSystem, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboTruckType, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboBlasterType, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboNumberAxles, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboLNG, javax.swing.GroupLayout.Alignment.TRAILING, 0, 213, Short.MAX_VALUE)))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(btnGenerate, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnSaveFleetDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(comboInverterType, javax.swing.GroupLayout.Alignment.TRAILING, 0, 213, Short.MAX_VALUE)
                            .addComponent(comboLocoModel, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboHPFP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboAirDryer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboTractionMotor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboAESS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboLocoType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboAirBrake, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboEngineHP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboVideoSystem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboTruckType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBlasterType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboNumberAxles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboLNG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboLocoModel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboInverterType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGenerate)
                    .addComponent(btnSaveFleetDetails))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSaveScriptToFile)
                .addContainerGap())
        );

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFleetName, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(txtFleetName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSearch))
                    .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editorFleetResults.setEditable(false);
        editorFleetResults.setContentType("text/html"); // NOI18N
        editorFleetResults.setEnabled(false);
        jScrollPane1.setViewportView(editorFleetResults);

        editorScript.setEditable(false);
        editorScript.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        editorScript.setEnabled(false);
        jScrollPane2.setViewportView(editorScript);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 814, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
         fetchFleetDetails();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateActionPerformed
         generateCBTAScript();
    }//GEN-LAST:event_btnGenerateActionPerformed

    private void btnSaveScriptToFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveScriptToFileActionPerformed
     JFileChooser fc = new JFileChooser();
     fc.setFileFilter(new util.FolderFilter());
     fc.setFileSelectionMode(1);
     
     int returnVal = fc.showOpenDialog(this);
     
     if (returnVal == 0) {
       DateFormat dateFormat = new java.text.SimpleDateFormat("MMM-dd-yyyy");
       Date date = new Date();
       try {
         org.apache.commons.io.FileUtils.write(new File(fc.getSelectedFile().getAbsolutePath() + "\\\\MissingCBTA-" + txtFleetName.getText().trim().toUpperCase() + "_" + dateFormat.format(date) + ".sql"), editorScript.getText());
         javax.swing.JOptionPane.showMessageDialog(null, "Operation Successful!", "File saved!", -1);
       } catch (Exception e) {
         System.out.println(e.getMessage());
       }
     } 
    }//GEN-LAST:event_btnSaveScriptToFileActionPerformed

    private void txtFleetNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFleetNameFocusGained
        txtFleetName.selectAll();
    }//GEN-LAST:event_txtFleetNameFocusGained

    private void btnSaveFleetDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveFleetDetailsActionPerformed
     JFileChooser fc = new JFileChooser();
     fc.setFileFilter(new util.FolderFilter());
     fc.setFileSelectionMode(1);
     
     int returnVal = fc.showOpenDialog(this);
     
     if (returnVal == 0)
       try {
         org.apache.commons.io.FileUtils.write(new File(fc.getSelectedFile().getAbsolutePath() + "\\\\CBTA_Fleet_Details-" + txtFleetName.getText().trim().toUpperCase() + ".xls"), editorFleetResults.getText());
         javax.swing.JOptionPane.showMessageDialog(null, "Operation Successful!", "File saved!", -1);
       } catch (Exception e) {
         System.out.println(e.getMessage()); }
    }//GEN-LAST:event_btnSaveFleetDetailsActionPerformed

   private void fetchFleetDetails() { new Thread(new Runnable() {
       public void run() {
         getFleetListing();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable() {
           public void run() {}
         });
       }
     }).start(); }
   
   
   private void protectFields() {
     btnSearch.setEnabled(false);
     btnGenerate.setEnabled(false);
     btnSaveScriptToFile.setEnabled(false);
     comboAESS.setEnabled(false);
     comboAirBrake.setEnabled(false);
     comboAirDryer.setEnabled(false);
     comboBlasterType.setEnabled(false);
     comboEngineHP.setEnabled(false);
     comboHPFP.setEnabled(false);
     comboLocoType.setEnabled(false);
     comboNumberAxles.setEnabled(false);
     comboTractionMotor.setEnabled(false);
     comboTruckType.setEnabled(false);
     comboVideoSystem.setEnabled(false);
     comboLNG.setEnabled(false);
     comboLocoModel.setEnabled(false);
     comboInverterType.setEnabled(false);
     editorFleetResults.setEnabled(false);
     editorScript.setEnabled(false);
     btnSaveFleetDetails.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     btnGenerate.setEnabled(true);
     comboAESS.setEnabled(true);
     comboAirBrake.setEnabled(true);
     comboAirDryer.setEnabled(true);
     comboBlasterType.setEnabled(true);
     comboEngineHP.setEnabled(true);
     comboHPFP.setEnabled(true);
     comboLocoType.setEnabled(true);
     comboNumberAxles.setEnabled(true);
     comboTractionMotor.setEnabled(true);
     comboTruckType.setEnabled(true);
     comboVideoSystem.setEnabled(true);
     comboLNG.setEnabled(true);
     comboLocoModel.setEnabled(true);
     comboInverterType.setEnabled(true);     
     editorFleetResults.setEnabled(true);
     editorScript.setEnabled(true);
     progressBar.setVisible(false);
   }
   
   private void getFleetListing() {
     String fleetCBTADetails = "";
     
     try
     {
       protectFields();
       conn = util.OracleConnectionManager.getConnection(0);
       
       if (conn == null) {
         editorFleetResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       buf = new StringBuffer();
       locomotives = new ArrayList();
       editorFleetResults.setText("");
       editorScript.setText("");
       
       fleetCBTADetails = "select al.aar_road, al.road_number, al.locomotive_id, "
               + "(select fleet_name from gets_lms_fleet where fleet_id = al.fleet_id) as fleet,\n"
               + "al.locomotive_status_code, \n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1001 and locomotive_id = al.locomotive_id ), '-') as HPFP,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1002 and locomotive_id = al.locomotive_id ), '-') as Air_dryer,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1003 and locomotive_id = al.locomotive_id ), '-') as Traction_motor,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1004 and locomotive_id = al.locomotive_id ), '-') as AESS,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1005 and locomotive_id = al.locomotive_id ), '-') as Loco_Type,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1006 and locomotive_id = al.locomotive_id ), '-') as Air_Brake,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1007 and locomotive_id = al.locomotive_id ), '-') as Engine_HP,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1008 and locomotive_id = al.locomotive_id ), '-') as Video_System,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1010 and locomotive_id = al.locomotive_id ), '-') as Truck_Type,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1011 and locomotive_id = al.locomotive_id ), '-') as Blaster_Type,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1012 and locomotive_id = al.locomotive_id ), '-') as NumberOfAxles,\n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1013 and locomotive_id = al.locomotive_id ), '-') as LNG, \n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1014 and locomotive_id = al.locomotive_id ), '-') as Loco_Model, \n"
               + "NVL((select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1015 and locomotive_id = al.locomotive_id ), '-') as Inverter_Type \n"
               + "from gets_lms_locomotive_all al\n"
               + "where \n"
               + "al.fleet_id in (select fleet_id from gets_lms_fleet where upper(fleet_name) = '" + txtFleetName.getText().toUpperCase().trim() + "') "
               + "and al.locomotive_status_code in ('ACTIVE', 'DESIGN/BUILD') "
               + "order by road_number asc";
 
       prepStm = conn.prepareStatement(fleetCBTADetails);
       rs = prepStm.executeQuery();
       
       if (rs.next())
       {
         buf.append("<HTML><TABLE width=100% border=1>");
         buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\"><B><FONT size=3>Locomotive</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>HPFP</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Air dryer</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Traction motor</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>AESS</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Loco Type</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Air Brake</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Engine HP</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Video System</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Truck Type</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Blaster System</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3># Axles</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>LNG</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Loco Model</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Inverter Type</FONT></B></TD>"
                 + "</TR>");
         do
         {       
             locomotives.add(new LocomotiveData(rs.getString("locomotive_id"), rs.getString("aar_road"), 
                     rs.getString("road_number"), rs.getString("HPFP"), rs.getString("Air_dryer"), 
                     rs.getString("Traction_motor"), rs.getString("AESS"), rs.getString("Loco_Type"), 
                     rs.getString("Air_Brake"), rs.getString("Engine_HP"), rs.getString("Video_System"), 
                     rs.getString("Truck_Type"), rs.getString("Blaster_Type"), rs.getString("NumberOfAxles"),
                     rs.getString("lng"), rs.getString("Loco_Model"), rs.getString("Inverter_Type")));

             //Gray out if the unit is in DESIGN/BUILD.
             buf.append("<TR " + (rs.getString("locomotive_status_code").equals("DESIGN/BUILD") ? "bgcolor=#DDDDDD" : "") + ">"
                     + "<TD align=\"center\"><FONT size=3>" + rs.getString("aar_road") + "-" + rs.getString("road_number") + "</FONT></TD>" + // " (" + rs.getString("locomotive_id") + ")
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("HPFP") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Air_dryer") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Traction_motor") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("AESS") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Loco_Type") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Air_Brake") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Engine_HP") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Video_System") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Truck_Type") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Blaster_Type") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("NumberOfAxles") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("lng") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Loco_Model") + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + rs.getString("Inverter_Type") + "</FONT></TD>" + 
                     "</TR>");

         }
         while (rs.next());
       }
       else
       {
         editorFleetResults.setText("<HTML><H3>No units found for fleet " + txtFleetName.getText() + "</H3></HTML>");
         editorScript.setText("");
         releaseFields();
         done = true;
         return;
       }
       
       editorFleetResults.setText(buf.toString());
       prepStm.close();
       rs.close();
       
 
       String configValues = "select config_value_id, asset_param_id, config_value_description from GETS_CCS_PARAM_CONFIG order by asset_param_id asc, config_value_description asc";
       hpfpList = new ArrayList();
       hpfpList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       airDryerList = new ArrayList();
       airDryerList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       tractionMotorList = new ArrayList();
       tractionMotorList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       aessList = new ArrayList();
       aessList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       locoTypeList = new ArrayList();
       locoTypeList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       airBrakeList = new ArrayList();
       airBrakeList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       engineHPList = new ArrayList();
       engineHPList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       videoSystemList = new ArrayList();
       videoSystemList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       truckTypeList = new ArrayList();
       truckTypeList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       blasterTypeList = new ArrayList();
       blasterTypeList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       numberOfAxlesList = new ArrayList();
       numberOfAxlesList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       lngList = new ArrayList();
       lngList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       locoModelList = new ArrayList();
       locoModelList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));
       inverterTypeList = new ArrayList();
       inverterTypeList.add(new CBTAEntry("0", "-- Ignore Value --", "0"));       
       
       prepStm = conn.prepareStatement(configValues);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         do {
           switch (rs.getInt("asset_param_id")) {
           case 1001: 
             hpfpList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1002: 
             airDryerList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1003: 
             tractionMotorList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1004: 
             aessList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1005: 
             locoTypeList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1006: 
             airBrakeList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1007: 
             engineHPList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1008: 
             videoSystemList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1010: 
             truckTypeList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1011: 
             blasterTypeList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));              
             break;
               
           case 1012: 
             numberOfAxlesList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));
             break;  
           
           case 1013: 
             lngList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));
             break;  

           case 1014: 
             locoModelList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));
             break;  

           case 1015: 
             inverterTypeList.add(new CBTAEntry(rs.getString("config_value_id"), rs.getString("config_value_description"), rs.getString("asset_param_id")));
             break;                 
           }
           
         } while (rs.next());
       }
       
       hpfpModel = new DefaultComboBoxModel(hpfpList.toArray());
       comboHPFP.setModel(hpfpModel);
       airDryerModel = new DefaultComboBoxModel(airDryerList.toArray());
       comboAirDryer.setModel(airDryerModel);
       tractionMotorModel = new DefaultComboBoxModel(tractionMotorList.toArray());
       comboTractionMotor.setModel(tractionMotorModel);
       aessModel = new DefaultComboBoxModel(aessList.toArray());
       comboAESS.setModel(aessModel);
       locoTypeModel = new DefaultComboBoxModel(locoTypeList.toArray());
       comboLocoType.setModel(locoTypeModel);
       airBrakeModel = new DefaultComboBoxModel(airBrakeList.toArray());
       comboAirBrake.setModel(airBrakeModel);
       engineHPModel = new DefaultComboBoxModel(engineHPList.toArray());
       comboEngineHP.setModel(engineHPModel);
       videoSystemModel = new DefaultComboBoxModel(videoSystemList.toArray());
       comboVideoSystem.setModel(videoSystemModel);
       truckTypeModel = new DefaultComboBoxModel(truckTypeList.toArray());
       comboTruckType.setModel(truckTypeModel);
       blasterTypeModel = new DefaultComboBoxModel(blasterTypeList.toArray());
       comboBlasterType.setModel(blasterTypeModel);
       numberOfAxlesModel = new DefaultComboBoxModel(numberOfAxlesList.toArray());
       comboNumberAxles.setModel(numberOfAxlesModel);
       lngModel = new DefaultComboBoxModel(lngList.toArray());
       comboLNG.setModel(lngModel);       
       locoModelModel = new DefaultComboBoxModel(locoModelList.toArray());
       comboLocoModel.setModel(locoModelModel); 
       inverterTypeModel = new DefaultComboBoxModel(inverterTypeList.toArray());
       comboInverterType.setModel(inverterTypeModel);        
 
       LocomotiveData bestGuess = findBestGuess();
       
       comboHPFP.setSelectedIndex(hpfpList.indexOf(new CBTAEntry("0", bestGuess.getHpfp(), "0")) == -1 ? 0 : hpfpList.indexOf(new CBTAEntry("0", bestGuess.getHpfp(), "0")));
       comboAirDryer.setSelectedIndex(airDryerList.indexOf(new CBTAEntry("0", bestGuess.getAirDryer(), "0")) == -1 ? 0 : airDryerList.indexOf(new CBTAEntry("0", bestGuess.getAirDryer(), "0")));
       comboTractionMotor.setSelectedIndex(tractionMotorList.indexOf(new CBTAEntry("0", bestGuess.getTractionMotor(), "0")) == -1 ? 0 : tractionMotorList.indexOf(new CBTAEntry("0", bestGuess.getTractionMotor(), "0")));
       comboAESS.setSelectedIndex(aessList.indexOf(new CBTAEntry("0", bestGuess.getAess(), "0")) == -1 ? 0 : aessList.indexOf(new CBTAEntry("0", bestGuess.getAess(), "0")));
       comboLocoType.setSelectedIndex(locoTypeList.indexOf(new CBTAEntry("0", bestGuess.getLocoType(), "0")) == -1 ? 0 : locoTypeList.indexOf(new CBTAEntry("0", bestGuess.getLocoType(), "0")));
       comboAirBrake.setSelectedIndex(airBrakeList.indexOf(new CBTAEntry("0", bestGuess.getAirBrake(), "0")) == -1 ? 0 : airBrakeList.indexOf(new CBTAEntry("0", bestGuess.getAirBrake(), "0")));
       comboEngineHP.setSelectedIndex(engineHPList.indexOf(new CBTAEntry("0", bestGuess.getEngineHP(), "0")) == -1 ? 0 : engineHPList.indexOf(new CBTAEntry("0", bestGuess.getEngineHP(), "0")));
       comboVideoSystem.setSelectedIndex(videoSystemList.indexOf(new CBTAEntry("0", bestGuess.getVideoSystem(), "0")) == -1 ? 0 : videoSystemList.indexOf(new CBTAEntry("0", bestGuess.getVideoSystem(), "0")));
       comboTruckType.setSelectedIndex(truckTypeList.indexOf(new CBTAEntry("0", bestGuess.getTruckType(), "0")) == -1 ? 0 : truckTypeList.indexOf(new CBTAEntry("0", bestGuess.getTruckType(), "0")));
       comboBlasterType.setSelectedIndex(blasterTypeList.indexOf(new CBTAEntry("0", bestGuess.getBlasterSystem(), "0")) == -1 ? 0 : blasterTypeList.indexOf(new CBTAEntry("0", bestGuess.getBlasterSystem(), "0")));
       comboNumberAxles.setSelectedIndex(numberOfAxlesList.indexOf(new CBTAEntry("0", bestGuess.getNumberOfAxles(), "0")) == -1 ? 0 : numberOfAxlesList.indexOf(new CBTAEntry("0", bestGuess.getNumberOfAxles(), "0")));
       comboLNG.setSelectedIndex(lngList.indexOf(new CBTAEntry("0", bestGuess.getLng(), "0")) == -1 ? 0 : lngList.indexOf(new CBTAEntry("0", bestGuess.getLng(), "0")));
       comboLocoModel.setSelectedIndex(locoModelList.indexOf(new CBTAEntry("0", bestGuess.getLocoModel(), "0")) == -1 ? 0 : locoModelList.indexOf(new CBTAEntry("0", bestGuess.getLocoModel(), "0")));
       comboInverterType.setSelectedIndex(inverterTypeList.indexOf(new CBTAEntry("0", bestGuess.getInverterType(), "0")) == -1 ? 0 : inverterTypeList.indexOf(new CBTAEntry("0", bestGuess.getInverterType(), "0")));
       
       
       releaseFields();       
       done = true;
       
       //Enable the fleet details button
       btnSaveFleetDetails.setEnabled(true);
     }
     catch (Exception e) {
       editorFleetResults.setText("<HTML><H3>An Error occurred, please check the logs.</H3></HTML>");
       releaseFields();
       
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtFleetName: \"" + txtFleetName.getText() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append(e.getMessage());
       util.JErrorLog.createErrorLog("Class: FleetLocoConfigIF, Method: getFleetListing", fleetCBTADetails + "\n\n", buf.toString());        
       return;
     }
   }
 
   private LocomotiveData findBestGuess() { return (LocomotiveData)locomotives.get(0); }
      
   private void generateCBTAScript() { StringBuffer cbtaBuf = new StringBuffer();
     cbtaBuf.append("BEGIN\n\n");
     
     boolean found = false;
     
     for (LocomotiveData l : locomotives)
     {
       found = false;
       
       if ((l.getHpfp().equals("-")) && (comboHPFP.getSelectedIndex() != 0)) {
         found = true;
         cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         
         CBTAEntry c = (CBTAEntry)comboHPFP.getSelectedItem();
         cbtaBuf.append("-- HPFP\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'HPFP','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getAirDryer().equals("-")) && (comboAirDryer.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         
         CBTAEntry c = (CBTAEntry)comboAirDryer.getSelectedItem();
         cbtaBuf.append("-- AIR DRYER\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Air Dryer','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getTractionMotor().equals("-")) && (comboTractionMotor.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         
         CBTAEntry c = (CBTAEntry)comboTractionMotor.getSelectedItem();
         cbtaBuf.append("-- TRACTION MOTOR\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Traction Motor','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getAess().equals("-")) && (comboAESS.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboAESS.getSelectedItem();
         cbtaBuf.append("-- AESS\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'AESS','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getLocoType().equals("-")) && (comboLocoType.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboLocoType.getSelectedItem();
         cbtaBuf.append("-- LOCO TYPE\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Loco Type','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getAirBrake().equals("-")) && (comboAirBrake.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboAirBrake.getSelectedItem();
         cbtaBuf.append("-- AIR BRAKE\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Air Brake','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getEngineHP().equals("-")) && (comboEngineHP.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboEngineHP.getSelectedItem();
         cbtaBuf.append("-- ENGINE HP\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Engine HP','N','" + c.getId() + "');\n\n");
       }
    
       if ((l.getVideoSystem().equals("-")) && (comboVideoSystem.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboVideoSystem.getSelectedItem();
         cbtaBuf.append("-- VIDEO SYSTEM\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Video System','N','" + c.getId() + "');\n\n");
       }
   
       if ((l.getTruckType().equals("-")) && (comboTruckType.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboTruckType.getSelectedItem();
         cbtaBuf.append("-- TRUCK TYPE\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'Truck Type','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getBlasterSystem().equals("-")) && (comboBlasterType.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboBlasterType.getSelectedItem();
         cbtaBuf.append("-- BLASTER SYSTEM\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'BLASTER SYSTEM','N','" + c.getId() + "');\n\n");
       }

       if ((l.getNumberOfAxles().equals("-")) && (comboNumberAxles.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboNumberAxles.getSelectedItem();
         cbtaBuf.append("-- NUMBER OF AXLES\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'NUMBEROFAXLES','N','" + c.getId() + "');\n\n");
       }
       
       if ((l.getLng().equals("-")) && (comboLNG.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboLNG.getSelectedItem();
         cbtaBuf.append("-- LNG\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'LNG','N','" + c.getId() + "');\n\n");
       }       

       if ((l.getLocoModel().equals("-")) && (comboLocoModel.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboLocoModel.getSelectedItem();
         cbtaBuf.append("-- Loco Model\n"); 
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'LOCOMODEL','N','" + c.getId() + "');\n\n");
       }  
       
       if ((l.getInverterType().equals("-")) && (comboInverterType.getSelectedIndex() != 0)) {
         if (!found) {
           found = true;
           cbtaBuf.append("/*************************** " + l.getAarRoad() + "-" + l.getRoadNumber() + " ***************************/\n");
         }
         CBTAEntry c = (CBTAEntry)comboInverterType.getSelectedItem();
         cbtaBuf.append("-- Inverter Type\n");
         cbtaBuf.append("INSERT INTO gets_ccs.gets_ccs_loco_config_all \n(LOCO_CONFIG_ID,CREATION_DATE, CREATED_BY,LAST_UPDATE_DATE,LAST_UPDATED_BY,LOCOMOTIVE_ID,SEQUENCE_NUMBER,PARENT_PART_NUMBER,PART_NUMBER,\nPART_DESCRIPTION,ITEM_LEVEL,ITEM_QUANTITY,ITEM_APPLICATION_DATE,ORG_ID,LOCO_CONFIG_TYPE,ASSET_PARAM_ID,ASSET_PARAM_VALUE,DUE_FLAG,CONFIG_VALUE_ID)\nVALUES \n(GETS_CCS_LOCO_CONFIG_S.Nextval,sysdate,'58901',sysdate,\n'58901'," + l.getId() + ",\n" + "(select max(SEQUENCE_NUMBER) + 1 from gets_ccs.gets_ccs_loco_config_all),'Not Available',\n" + "'" + c.getValue() + "','" + c.getValue() + "',\n" + "'1','1.000',Sysdate,103,'HARDWARE'," + c.getParamID() + ",\n" + "'INVERTER TYPE','N','" + c.getId() + "');\n\n");
       }         
     }

     
     
     cbtaBuf.append("COMMIT;\nEND;\n");
     editorScript.setText(cbtaBuf.toString());
     btnSaveScriptToFile.setEnabled(true);
   }
        
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerate;
    private javax.swing.JButton btnSaveFleetDetails;
    private javax.swing.JButton btnSaveScriptToFile;
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboAESS;
    private javax.swing.JComboBox comboAirBrake;
    private javax.swing.JComboBox comboAirDryer;
    private javax.swing.JComboBox comboBlasterType;
    private javax.swing.JComboBox comboEngineHP;
    private javax.swing.JComboBox comboHPFP;
    private javax.swing.JComboBox comboInverterType;
    private javax.swing.JComboBox comboLNG;
    private javax.swing.JComboBox comboLocoModel;
    private javax.swing.JComboBox comboLocoType;
    private javax.swing.JComboBox comboNumberAxles;
    private javax.swing.JComboBox comboTractionMotor;
    private javax.swing.JComboBox comboTruckType;
    private javax.swing.JComboBox comboVideoSystem;
    private javax.swing.JEditorPane editorFleetResults;
    private javax.swing.JEditorPane editorScript;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtFleetName;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential