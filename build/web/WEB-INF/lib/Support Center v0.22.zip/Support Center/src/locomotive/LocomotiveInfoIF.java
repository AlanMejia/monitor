/*
  v 0.12
  - Recreated as a Netbeans form. 
  - Added a dropdown of customers to the locomotive lookup form so that you can now search by customer. 
    Useful for Brazilian/KTZ units when you just have the Customer and Road number. 
    Added CustomerData(customerId, customerName) constructor for this case.
  v 0.15
  - Added the LNG attribute for the Loco Config entries in the lookup. LNG lookup was added on May 19th 2015.
  v 0.17
  - Added "Creation Date" and "Created by" on the locomotive details. Reordered the fields as well, it looked ugly as sin.
  v 0.20
  - Added a line separator between unit records for easier reading.
  v 0.21
  - Added a validation for when a unit does not have a fleet assigned. It will display "No Fleet Assigned" on bright red (thanks to FB 86100)
  v 0.22
  - Added the Loco Model and Inverter Type on the CBTA.
  - Implemented Find functionality.
*/

package locomotive;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;
import util.customerorgs.CustomerData;
import util.locomotive.LocomotiveData;

public class LocomotiveInfoIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private ArrayList<LocomotiveData> locos;
   private StringBuffer buf;
   private ArrayList<CustomerData> customers;
   private DefaultComboBoxModel customerModel;   
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;      
   
    public LocomotiveInfoIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { 
        
        super(title, resizable, closable, maximizable, iconifiable);
     initComponents();

     this.getRootPane().setDefaultButton(btnSearch);
     
     locos = new ArrayList();
     customers = new ArrayList();
     
     buf = new StringBuffer();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { LocomotiveInfoIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action);  
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
     
     loadCustomers();         
          
    }
   
    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }         
    
   private void cleanClose() { 
       dispose(); 
   }
   
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        jPanel2 = new javax.swing.JPanel();
        txtAARRoad = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtRoadNumber = new javax.swing.JTextField();
        comboCustomer = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        txtLocomotiveId = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        txtAARRoad.setText("AAR Road");
        txtAARRoad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAARRoadFocusGained(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Customer:");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("-");

        txtRoadNumber.setText("Road #");
        txtRoadNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRoadNumberFocusGained(evt);
            }
        });

        comboCustomer.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Loading customer list --" }));

        jLabel3.setText("or");

        txtLocomotiveId.setText("Locomotive ID");
        txtLocomotiveId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLocomotiveIdFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAARRoad, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                    .addComponent(comboCustomer, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAARRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));
        comboEnvironment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboEnvironmentActionPerformed(evt);
            }
        });

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtAARRoadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAARRoadFocusGained
        txtAARRoad.selectAll();
    }//GEN-LAST:event_txtAARRoadFocusGained

    private void txtRoadNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRoadNumberFocusGained
        txtRoadNumber.selectAll();
    }//GEN-LAST:event_txtRoadNumberFocusGained

    private void txtLocomotiveIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLocomotiveIdFocusGained
        txtLocomotiveId.selectAll();
    }//GEN-LAST:event_txtLocomotiveIdFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if ((txtRoadNumber.getText().isEmpty()) && (txtAARRoad.getText().isEmpty()) && (txtLocomotiveId.getText().isEmpty()) && (comboCustomer.getSelectedIndex() == 0) ) {
       editorResults.setText("Please fill at least one field.");
     } else 
     if (txtRoadNumber.getText().equals("Road #") && txtAARRoad.getText().equals("AAR Road") && txtLocomotiveId.getText().equals("Locomotive ID") && (comboCustomer.getSelectedIndex() == 0)){
       editorResults.setText("Please fill at least one field.");  
     } else {
        loadList();
     }
     
    }//GEN-LAST:event_btnSearchActionPerformed

    private void comboEnvironmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboEnvironmentActionPerformed
        loadCustomers();
    }//GEN-LAST:event_comboEnvironmentActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ESCAPE)
         {
             this.cleanClose();
         }
    }//GEN-LAST:event_formKeyPressed

   private void protectFields()
   {
     btnSearch.setEnabled(false);
     txtRoadNumber.setEditable(false);
     txtAARRoad.setEditable(false);
     txtLocomotiveId.setEditable(false);
     comboEnvironment.setEnabled(false);
     comboCustomer.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     txtRoadNumber.setEditable(true);
     txtAARRoad.setEditable(true);
     txtLocomotiveId.setEditable(true);
     comboEnvironment.setEnabled(true);
     comboCustomer.setEnabled(true);
     progressBar.setVisible(false);
   }
   
   private void loadCustomers() {
     new Thread(new Runnable() {
       public void run() {
         fetchCustomerList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }   
   
   private void fetchCustomerList(){
       String customerQuery = "";
       try {
            done = false;
            protectFields();
            editorResults.setText("<HTML><H3>Populating customer dropdown...</H3></HTML>");     
            
           conn = util.OracleConnectionManager.getConnection(getComboConnection());
                        
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            customerQuery = "select cust.customer_id, cust.customer_name from ar_customers cust\n" +
                "where customer_id in (select customer_id from gets_lms_locomotive_all where asset_type = 'LOCO')\n" +
                "order by customer_name asc";
            customers = new ArrayList();
            customers.add(new CustomerData("0", "-- Please select Customer --"));
            prepStm = conn.prepareStatement(customerQuery);
            rs = prepStm.executeQuery();
            
            while(rs.next()){
                customers.add(new CustomerData(rs.getString("customer_id"), rs.getString("customer_name")));
            }
           
            customerModel = new DefaultComboBoxModel(customers.toArray());
            comboCustomer.setModel(customerModel);   
            
            prepStm.close();
            rs.close();
            releaseFields();
            editorResults.setText("");
            
       }catch(Exception e){
            buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
             buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
             buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");       
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Could not pull Customer details because: \n");
             buf.append(e.getMessage());
             util.JErrorLog.createErrorLog("Class: LocomotiveInfoIF, Method: fetchCustomerList", customerQuery + "\n\n", buf.toString());

             editorResults.setText("An Error occurred, please check the logs.");
             releaseFields();           
       }
   }
   
   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         fetchLocomotiveList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void fetchLocomotiveList()
   {
     String locoQuery = "";
     try {
       done = false;
       protectFields();
       editorResults.setText("");
       buf = new StringBuffer();
       locos.clear();
 
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       locoQuery = "select al.aar_road, al.road_number, al.locomotive_id, to_char(al.last_update_date, 'DD-Mon-yyyy HH24:MI:SS') as last_update_date,  "
               + " to_char(al.creation_date, 'DD-Mon-yyyy HH24:MI:SS') as creation_date,  "
               + " (select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = al.last_updated_by) as updated_by, \n"
               + " (select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = al.created_by) as created_by, \n"               
               + " (select customer_name from ar_customers where customer_id = al.customer_id) as customer,\n"
               + " NVL((select fleet_name from gets_lms_fleet where fleet_id = al.fleet_id), 'No Fleet Assigned') as fleet,\n"
               + " al.fleet_id, al.locomotive_model_code, al.locomotive_type_code, NVL(al.locomotive_status_code, '-') as locomotive_status_code, \n"
               + " al.engine_horsepower_code, al.airbrake_type_code, NVL(to_char(al.in_service_date, 'DD-Mon-yyyy HH24:MI:SS'), '-') as in_service_date, "
               + " al.asset_type, al.emission_tier_type,\n"
               + " al.part_number, al.parts_catalog_id,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1001 and locomotive_id = al.locomotive_id ) as HPFP,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1002 and locomotive_id = al.locomotive_id ) as Air_dryer,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1003 and locomotive_id = al.locomotive_id ) as Traction_motor,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1004 and locomotive_id = al.locomotive_id ) as AESS,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1005 and locomotive_id = al.locomotive_id ) as Loco_Type,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1006 and locomotive_id = al.locomotive_id ) as Air_Brake,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1007 and locomotive_id = al.locomotive_id ) as Engine_HP,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1008 and locomotive_id = al.locomotive_id ) as Video_System,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1010 and locomotive_id = al.locomotive_id ) as Truck_Type,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1011 and locomotive_id = al.locomotive_id ) as Blaster_Type,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1012 and locomotive_id = al.locomotive_id ) as NumberOfAxles,\n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1013 and locomotive_id = al.locomotive_id ) as LNG, \n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1014 and locomotive_id = al.locomotive_id ) as Loco_Model, \n"
               + " (select part_number from gets_ccs_loco_config_all where ASSET_PARAM_ID = 1015 and locomotive_id = al.locomotive_id ) as Inverter_Type \n"               
               + " from gets_lms_locomotive_all al where 1 = 1 " + 
               (comboCustomer.getSelectedIndex() != 0 ? " and customer_id = " + ((CustomerData)comboCustomer.getSelectedItem()).getCustomerId() : ""  ) +
               (txtRoadNumber.getText().trim().toLowerCase().isEmpty() || txtRoadNumber.getText().equals("Road #") ? "" : new StringBuilder().append("AND lower(al.road_number) like '%").append(txtRoadNumber.getText().trim().toLowerCase()).append("%'").toString()) + 
               (txtAARRoad.getText().trim().toLowerCase().isEmpty() || txtAARRoad.getText().equals("AAR Road") ? "" : new StringBuilder().append("AND lower(al.aar_road) like '%").append(txtAARRoad.getText().trim().toLowerCase()).append("%'").toString()) + 
               (txtLocomotiveId.getText().trim().toLowerCase().isEmpty() || txtLocomotiveId.getText().equals("Locomotive ID") ? "" : new StringBuilder().append("AND lower(al.locomotive_id) = '").append(txtLocomotiveId.getText().trim().toLowerCase()).append("'").toString()) + " " +
               " order by al.aar_road, al.road_number asc";
       
       prepStm = conn.prepareStatement(locoQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         do {
           locos.add(new LocomotiveData(rs.getString("locomotive_id"), 
                   rs.getString("aar_road"), 
                   rs.getString("road_number"), 
                   rs.getString("creation_date"),
                   rs.getString("created_by"),
                   rs.getString("last_update_date"), 
                   rs.getString("updated_by"), 
                   rs.getString("customer"), 
                   rs.getString("fleet"), 
                   rs.getString("fleet_id"), 
                   rs.getString("locomotive_model_code"), 
                   rs.getString("locomotive_type_code"), 
                   rs.getString("locomotive_status_code"), 
                   rs.getString("engine_horsepower_code"), 
                   rs.getString("airbrake_type_code"), 
                   rs.getString("in_service_date"), 
                   rs.getString("asset_type"), 
                   rs.getString("emission_tier_type"), 
                   rs.getString("part_number"), 
                   rs.getString("parts_catalog_id"), 
                   rs.getString("HPFP"), 
                   rs.getString("Air_dryer"), 
                   rs.getString("Traction_motor"), 
                   rs.getString("AESS"), 
                   rs.getString("Loco_Type"), 
                   rs.getString("Air_Brake"), 
                   rs.getString("Engine_HP"), 
                   rs.getString("Video_System"), 
                   rs.getString("Truck_Type"), 
                   rs.getString("Blaster_Type"), 
                   rs.getString("NumberOfAxles"),
                   rs.getString("lng"),
                   rs.getString("Loco_Model"),
                   rs.getString("Inverter_Type")));
         }
         while (rs.next());
       } else {
         editorResults.setText("No locomotives found with this criteria.");
         prepStm.close();
         rs.close();
         releaseFields();
         return;
       }
       
       prepStm.close();
       rs.close();
        
       buf.append("<HTML><BODY>");       
       for (LocomotiveData l : locos) {
                    
         buf.append("<TABLE border=0 width=100%><TR>\n"
                 + "   <TD align=center bgcolor=\"#92CDDC\"><B>" + l.toString() + "</B> (" + l.getCustomer() + ") </TD>\n" 
                 + "   <TD align=center bgcolor= " + l.htmlStatusColor() + "><B><FONT color=#FFFFFF>" + l.getStatus() + "</FONT></B></TD>"
                 + "   <TD align=center><B>ID: </B>" + l.getId() + "<B>, Fleet:</B> " + (l.getFleet().equals("No Fleet Assigned") ? "<FONT COLOR=RED><B>No Fleet Assigned</B>" : l.getFleet() + " (" + l.getFleetId() + ")" ) + "</TD>"
                 + "</TR>");
         buf.append("<TR>   "
                 + "<TD><B>Model: </B> " + l.getModel() + "<B>, Type: </B> " + l.getType() + "<B>, Tier: </B>" + l.getEmissionTier() + "</TD>\n" 
                 + "<TD colspan=2 align=center><B>LocoList: </B> " + l.getLocoList() + ", <B>PCId: </B> " + l.getPartsCatalogId() + ", <B>Asset Type: </B> " + l.getAssetType() + "</TD>\n"
                 + "</TR>");
         buf.append("<TR>"
                  + "<TD ><B>Created on: </B> " + l.getCreationDate() + ", <B>By: </B>" + l.getCreatedBy() +"</TD>" 
                  + "<TD colspan=2><B>Last Updated on: </B> " + l.getLastUpdateDate() + ", <B>By: </B>" + l.getLastUpdatedBy() +"</TD>" );
         buf.append("<TR>"
                  + "<TD ><B>Inservice Date: </B> " + l.getInserviceDate() + "</TD>" 
                  + "<TD colspan = 2 align=center><B>Engine HP: </B> " + l.getEngineHP() + ", <B>Brake Type: </B> " + l.getBrakeType() + "</TD>"          
                  + "</TR>");
         buf.append("</TABLE>");
         
         
         buf.append("<TABLE width=100% border = 0>");
         buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\" colspan=14><B>CBTA VALUES</B></TD></TR>"
                 + "<TR bgcolor=\"#92CDDC\">"
                 + "<TD align=\"center\"><B><FONT size=3>HPFP</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Air dryer</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Traction motor</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>AESS</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Loco Type</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Air Brake</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Engine HP</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Video System</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Truck Type</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Blaster System</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3># Axles</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>LNG</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Loco Model</FONT></B></TD>"
                 + "<TD align=\"center\"><B><FONT size=3>Inverter Type</FONT></B></TD>"
                 + "</TR>"); 
         buf.append("<TR>" +
                     "<TD align=\"center\"><FONT size=3>" + l.getHpfp() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getAirDryer() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getTractionMotor() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getAess() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getLocoType() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getAirBrake() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getEngineHP() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getVideoSystem() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getTruckType() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getBlasterSystem() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getNumberOfAxles() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getLng() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getLocoModel() + "</FONT></TD>" + 
                     "<TD align=\"center\"><FONT size=3>" + l.getInverterType() + "</FONT></TD>" + 
                    "</TR></TABLE><BR><HR><BR>");         
       }
       
 
       buf.append("</BODY></HTML>");
       editorResults.setText(buf.toString());
       releaseFields();
       done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
       buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
       buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");       
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Could not pull Locomotive details because: \n");
       buf.append(e.getMessage());
       util.JErrorLog.createErrorLog("Class: LocomotiveInfoIF, Method: fetchLocomotiveList", locoQuery + "\n\n", buf.toString());

       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();
     }
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }       


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboCustomer;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtAARRoad;
    private javax.swing.JTextField txtLocomotiveId;
    private javax.swing.JTextField txtRoadNumber;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential