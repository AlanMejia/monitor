/*
  v 0.12
   - Restored to a netbeans form.
  v 0.18
   - Finally cleaned up the fields a bit, attempted to make it more readable and in tune with the general format of the application.
  v 0.20
   - Implemented search functionality.
  v 0.21
   - If the account has a "To Date" that is not null it will highlight it in red. FB 85797 would have been much easier if this existed before.
*/

package user;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;
import util.user.RespData;
import util.user.UserData;

public class UserInformationIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private ArrayList<UserData> users;
   private StringBuffer buf = new StringBuffer();
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;    
   
    public UserInformationIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     initComponents();

        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
     
     
     this.getRootPane().setDefaultButton(btnSearch);
     
     users = new ArrayList();
     progressBar.setVisible(false);
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { UserInformationIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {} }); 
    
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
    }
   
   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
    
     private void cleanClose() { 
         dispose(); 
     }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txteServicesAccount = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtDBUserID = new javax.swing.JTextField();
        txtLastName = new javax.swing.JTextField();
        comboEnvironment = new javax.swing.JComboBox();
        btnSearch = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("eServices Account:");

        jLabel2.setText("DB User ID:");

        txteServicesAccount.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txteServicesAccountFocusGained(evt);
            }
        });

        jLabel3.setText("First Name:");

        txtFirstName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFirstNameFocusGained(evt);
            }
        });

        jLabel4.setText("Last Name:");

        txtDBUserID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDBUserIDFocusGained(evt);
            }
        });

        txtLastName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLastNameFocusGained(evt);
            }
        });

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtDBUserID, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                    .addComponent(txteServicesAccount))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtFirstName)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(comboEnvironment, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txteServicesAccount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDBUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        progressBar.setIndeterminate(true);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 145, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if ((txtFirstName.getText().isEmpty()) && 
             (txtLastName.getText().isEmpty()) && 
             (txteServicesAccount.getText().isEmpty()) && 
             (txtDBUserID.getText().isEmpty()))
     {
       editorResults.setText("Please fill at least one field.");
     } else {
       loadList();
     }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txteServicesAccountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txteServicesAccountFocusGained
        txteServicesAccount.selectAll();
    }//GEN-LAST:event_txteServicesAccountFocusGained

    private void txtDBUserIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDBUserIDFocusGained
        txtDBUserID.selectAll();
    }//GEN-LAST:event_txtDBUserIDFocusGained

    private void txtFirstNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFirstNameFocusGained
        txtFirstName.selectAll();
    }//GEN-LAST:event_txtFirstNameFocusGained

    private void txtLastNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLastNameFocusGained
        txtLastName.selectAll();
    }//GEN-LAST:event_txtLastNameFocusGained

   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         fetchUserList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void protectFields()
   {
     btnSearch.setEnabled(false);
     txtFirstName.setEditable(false);
     txtLastName.setEditable(false);
     txteServicesAccount.setEditable(false);
     txtDBUserID.setEditable(false);
     comboEnvironment.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     txtFirstName.setEditable(true);
     txtLastName.setEditable(true);
     txteServicesAccount.setEditable(true);
     txtDBUserID.setEditable(true);
     comboEnvironment.setEnabled(true);
     progressBar.setVisible(false);
   }
   
   private void fetchUserList() {
     String userQuery = "";
     try {
       done = false;
       protectFields();
       editorResults.setText("");
       buf = new StringBuffer();
       users.clear();
       
 
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       userQuery = " Select se.employee_firstname, se.employee_lastname, NVL(se.user_name,'-') as user_name, se.active_flag, org.name, "
               + " to_char(se.creation_date,'DD-Mon-yyyy HH24:MI:SS') as creation_date, "
               + " to_char(se.last_update_date,'DD-Mon-yyyy HH24:MI:SS') as last_update_date, "
               + "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = se.created_by),'-') as created_by_user, "
               + "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = se.last_updated_by),'-') as last_updated_by, "               
               + "to_char(se.effective_to_date,'DD-Mon-yyyy HH24:MI:SS')  as effective_to, "
               + "to_char(se.effective_from_date,'DD-Mon-yyyy HH24:MI:SS') as effective_from, "
               + "se.user_id, NVL(se.eserv2_language_code, '-') as eserv2_language_code, NVL(se.language_code, '-') as language_code, se.skill_class, se.employee_class, "
               + "NVL(se.employee_email,'-') as employee_email, to_char(last_logon_date,'DD-Mon-yyyy HH24:MI:SS') as last_logon ,"
               + "NVL((select responsibility_name from gets_lms.GETS_LMS_RESPONSIBILITY_TL tl where responsibility_id = se.current_responsibility and language = 'US'),'-') as current_resp, "
               + "access_level from gets_lms_service_employee se, gets_lms_customer_orgs_v org "
               + "WHERE "
               + "se.service_organization_id = org.service_organization_id " + 
               (txtFirstName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(se.employee_firstname) like '%").append(txtFirstName.getText().trim().toLowerCase()).append("%'").toString()) + 
               (txtLastName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(se.employee_lastname) like '%").append(txtLastName.getText().trim().toLowerCase()).append("%'").toString()) + 
               (txteServicesAccount.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(se.user_name) like '%").append(txteServicesAccount.getText().trim().toLowerCase()).append("%'").toString()) + 
               (txtDBUserID.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(se.user_id) = '").append(txtDBUserID.getText().trim().toLowerCase()).append("'").toString()) + " ";
    
       prepStm = conn.prepareStatement(userQuery);
       rs = prepStm.executeQuery();
       
 
       if (rs.next()) {
         do {
           users.add(new UserData(rs.getString("employee_firstname"), 
                   rs.getString("employee_lastname"), 
                   rs.getString("user_name"), 
                   rs.getString("active_flag"), 
                   rs.getString("name"), 
                   rs.getString("creation_date"), 
                   rs.getString("created_by_user"), 
                   rs.getString("last_update_date"), 
                   rs.getString("last_updated_by"),                   
                   rs.getString("effective_from"), 
                   rs.getString("effective_to"), 
                   rs.getString("user_id"), 
                   rs.getString("eserv2_language_code"), 
                   rs.getString("language_code"), 
                   rs.getString("skill_class"), 
                   rs.getString("employee_class"), 
                   rs.getString("employee_email"), 
                   rs.getString("last_logon"), 
                   rs.getString("current_resp"), 
                   rs.getString("access_level")));
         }
         while (rs.next());
       } else {
         editorResults.setText("No users found with this criteria.");
         
         releaseFields();
         return;
       }
       
       prepStm.close();
       rs.close();
       
       for (UserData u : users) {
         prepStm = conn.prepareStatement("select distinct tl.responsibility_id, tl.responsibility_name, "
                 + "to_char(gr.end_date,'mm/dd/yyyy') as end_date from gets_lms.GETS_LMS_USER_RESP_GROUPS gr, gets_lms.GETS_LMS_RESPONSIBILITY_TL tl where gr.responsibility_id = tl.responsibility_id "
                 + "and user_id = " + u.getUserId() + " order by tl.responsibility_name asc");
     
         rs = prepStm.executeQuery();
         if (rs.next()) {
           do {
             u.addResponsibility(rs.getString("responsibility_id"), rs.getString("responsibility_name"), rs.getString("end_date") == "null" ? "-" : rs.getString("end_date"));
           }
           while (rs.next());
         } else {
           u.addResponsibility("0", "No Responsibilities", "-");
         }
         
         prepStm.close();
         rs.close();
       }
       
       buf.append("<html> <body>");
       for (UserData u : users) {
         buf.append(" <table width=100%> "
                 + "<tr>  "
                 + "<td align=center width=33% bgcolor=\"#92CDDC\" ><FONT size=+1><B>" + u.getLastName() + ", " + u.getFirstName() + " (" + u.getUserName() + ") <B></FONT></td>" 
                 + "<td align=center width=33%><B>Located in </B> <BR>" + u.getOrgName() + "</td>" 
                 + "<td align=center width=33% bgcolor= " + u.htmlStatusColor() + "><B><FONT color=#FFFFFF>" + ( u.getActiveFlag().equals("YES") ? "ACTIVE" : "INACTIVE" ) + " </FONT></B></td>"
                 + "</tr> " 
                 + "<tr> " 
                 + "<td colspan=\"2\"><B>Created on </B> " + u.getCreationDate() + " <B>by</B> " + u.getCreatedByUser() + "</td>" 
                 + "<td align=center><B>Languages</B> <BR>" + u.getLanguage1() + " (1.0), " + u.getLanguage2() + " (2.0)</td>"                  
                 + "</tr> " 
                 + "<tr> " 
                 + "<td colspan=\"3\"><B>Last Updated on </B> " + u.getLastUpdateDate() + " <B>by</B> " + u.getLastUpdatedBy() + "</td>" 
                 + "</tr> "                  
                 + "<tr> " 
                 + "<td colspan=2><B>Effective from </B>" + u.getEffectiveFrom() + " <B>to </B>" + (u.getEffectiveTo().equals("-") ? u.getEffectiveTo() : "<FONT color=red><B>" + u.getEffectiveTo() + "</B></FONT>" ) + "</td>"                                   
                 + "</tr> " 
                 + "<tr> " 
                 + "  <td><B>User ID:</B> " + u.getUserId() + ", <B>Access Level: </B>" + u.getAccessLevel() + " </td>" 
                 + "  <td align=center><B>Skill Class</B><BR> " + u.getSkillClass() + " <BR>(" + u.getEmployeeClass() + ")</td>" 
                 + "  <td align=center><B>Email</B><BR> " + u.getEmail() + "</td>" 
                 + "</tr> " 
                 + "<tr> " 
                 + "  <td  align=center><B>Last log on date </B><BR>" + u.getLastLogon() + "</td>" 
                 + "  <td colspan=\"2\"><B>Current Responsibility: </B>" + u.getCurrentResp() + "</td>" 
                 + "</tr>" + "</table>");
    
         buf.append("<table width=100%>"
                 + "<tr>"
                 + "<TD bgcolor=\"#92CDDC\" align=CENTER colspan=3><B>RESPONSIBILITIES</B></TD>"
                 + "</tr>"
                 + "<tr>"
                 + "<td bgcolor=\"#92CDDC\" align=CENTER><B>ID</B></td>"
                 + "<td bgcolor=\"#92CDDC\" align=CENTER><B>Responsibility Name</B></td>"
                 + "<td bgcolor=\"#92CDDC\" align=CENTER><B>Expired on</B></td>"
                 + "</tr> ");
         
         for (RespData r : u.getRespList()) {
           buf.append("<tr>"
                   + "<td align=center>" + r.getId() + "</td>" 
                   + "<td >" + r.getName() + "</td>" 
                   + "<td align=center>" + r.getToDate() + "</td>" 
                   + "</tr>");
         }
        
         buf.append("</table><BR><BR><HR>");
       }
       buf.append("</body></html>");
       
       editorResults.setText(buf.toString());
       releaseFields();
       done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txteServicesAccount: \"" + txteServicesAccount.getText() + "\"\n");
       buf.append("txtDBUserID: \"" + txtDBUserID.getText() + "\"\n");
       buf.append("txtFirstName: \"" + txtFirstName.getText() + "\"\n");
       buf.append("txtLastName: \"" + txtLastName.getText() + "\"\n");
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: UserInformationIF, Method: fetchUserList ", userQuery, buf.toString());       
       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();
     }
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtDBUserID;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txteServicesAccount;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential