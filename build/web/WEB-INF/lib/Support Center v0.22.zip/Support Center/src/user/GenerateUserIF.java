/*
  v 0.14
  - Corrected a bug that made it impossible to create accounts in Aktobe (the first shop from A-Z). 
*/

package user;
 
 import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
 import java.awt.event.MouseEvent;
 import java.io.File;
 import java.sql.Connection;
 import java.sql.PreparedStatement;
 import java.sql.ResultSet;
 import java.util.ArrayList;
 import javax.swing.DefaultComboBoxModel;
 import javax.swing.DefaultListModel;
 import javax.swing.GroupLayout;
 import javax.swing.GroupLayout.Alignment;
 import javax.swing.GroupLayout.ParallelGroup;
 import javax.swing.GroupLayout.SequentialGroup;
 import javax.swing.JButton;
 import javax.swing.JComboBox;
 import javax.swing.JEditorPane;
 import javax.swing.JFileChooser;
 import javax.swing.JInternalFrame;
 import javax.swing.JLabel;
 import javax.swing.JList;
 import javax.swing.JPanel;
 import javax.swing.JProgressBar;
 import javax.swing.JScrollPane;
 import javax.swing.JTextField;
 import javax.swing.*;
 import javax.swing.LayoutStyle.ComponentPlacement;
 import javax.swing.ListModel;
 import javax.swing.SwingUtilities;
 import javax.swing.event.InternalFrameEvent;
 import util.JErrorLog;
 import util.OracleConnectionManager;
 import util.customerorgs.ServiceOrgData;
 import util.user.RespData;
 
 public class GenerateUserIF extends JInternalFrame
 {
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private boolean done2 = false;
   private StringBuffer buf;
   private ArrayList<ServiceOrgData> orgs;
   private ArrayList<RespData> availableResps;
   private DefaultListModel availableRespModel;
   private ArrayList<RespData> requestedResps;
   private DefaultListModel requestedRespModel;
   private DefaultListModel tempModel;
   private JButton btnAdd;
   private JButton btnAddAll;
   private JButton btnCopyClipboard;
   private JButton btnGenerateScript;
   private JButton btnRemove;
   private JButton btnRemoveAll;
   
   public GenerateUserIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     
     this.orgs = new ArrayList();
     this.availableResps = new ArrayList();
     
     this.availableRespModel = new DefaultListModel();
     this.availableRespModel.addElement("Fetching responsibilities...");
     
     this.requestedRespModel = new DefaultListModel();
     
     initComponents();
     
     this.listAvailableResps.setModel(this.availableRespModel);
     this.listAvailableResps.setSelectionMode(2);
     this.listAvailableResps.setLayoutOrientation(0);
     
     this.listRequestedResps.setModel(this.requestedRespModel);
     this.listRequestedResps.setSelectionMode(2);
     this.listRequestedResps.setLayoutOrientation(0);
     
 
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { GenerateUserIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     fetchOrgData();
     fetchRespList();
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose()
   {
     dispose();
   }
   
   private void fetchOrgData() {
     new Thread(new Runnable() {
       public void run() {
         GenerateUserIF.this.fillOrgData();
         while (!GenerateUserIF.this.done2) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void fillOrgData()
   {
     String orgDataQuery = "";
     try
     {
       this.conn = OracleConnectionManager.getConnection(getComboConnection());
       
       if (this.conn == null) {
         this.editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       protectFields();
       orgDataQuery = "select customer_id, service_organization_id, organization_code, name from gets_lms_customer_orgs_v order by name asc";
       
       this.prepStm = this.conn.prepareStatement(orgDataQuery);
       this.rs = this.prepStm.executeQuery();
              
       if (this.rs.next()) {
         orgs.clear();
         orgs.add(new ServiceOrgData("0", "0", "0", "-- Select a Service Org --" ));
         do {
           this.orgs.add(new ServiceOrgData(this.rs.getString("customer_id"), this.rs.getString("service_organization_id"), this.rs.getString("organization_code"), this.rs.getString("name")));
 
 
         }
         while (this.rs.next());
       }
       
       this.prepStm.close();
       this.rs.close();
       
 
       DefaultComboBoxModel model = new DefaultComboBoxModel(this.orgs.toArray());
       this.comboOrgs.setModel(model);
       
       this.done2 = true;
       releaseFields();
     }
     catch (Exception e) {
       this.buf = new StringBuffer("");
       this.buf.append("-- Fields --\n");
       this.buf.append("No fields.\n");
       this.buf.append("Environment: " + getComboConnection() + "\"\n");
       this.buf.append("-- Exception --\n");
       this.buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: GenerateUserIF, Method: fillOrgData", orgDataQuery, this.buf.toString());
       
 
 
       this.editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   
   private void fetchRespList()
   {
     new Thread(new Runnable() {
       public void run() {
         GenerateUserIF.this.fetchRespListing();
         while (!GenerateUserIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void fetchRespListing()
   {
     String respListQuery = "";
     try {
       this.done = false;
       protectFields();
       this.availableRespModel.clear();
       this.tempModel = new DefaultListModel();
       this.buf = new StringBuffer();
       this.availableResps.clear();
       
 
       this.conn = OracleConnectionManager.getConnection(getComboConnection());
       
       if (this.conn == null) {
         this.editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
 
       respListQuery = "select distinct application_id, responsibility_id, responsibility_name from gets_lms.GETS_LMS_RESPONSIBILITY_TL \n order by responsibility_name asc";
       
 
       PreparedStatement prepStm2 = this.conn.prepareStatement(respListQuery);
       ResultSet rs2 = prepStm2.executeQuery();
       
       if (rs2.next()) {
         do {
           this.availableResps.add(new RespData(rs2.getString("responsibility_id"), rs2.getString("responsibility_name"), rs2.getInt("application_id")));
           
           this.tempModel.addElement(new RespData(rs2.getString("responsibility_id"), rs2.getString("responsibility_name"), rs2.getInt("application_id")));
         }
         while (rs2.next());
       } else {
         this.tempModel.addElement("No available responsibilities.");
       }
       
 
       prepStm2.close();
       rs2.close();
       this.listAvailableResps.setModel(this.tempModel);
       releaseFields();
       this.done = true;
     }
     catch (Exception e)
     {
       this.buf = new StringBuffer("");
       this.buf.append("-- Fields --\n");
       this.buf.append("No fields.\n");
       this.buf.append("-- Exception --\n");
       this.buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: GenerateUserIF, Method: fetchRespListing", respListQuery, this.buf.toString());
     } }
   
   private JButton btnValidateUsername;
   private JComboBox comboAccessLvl;
   private JComboBox comboEmpClass;
   
   private void validateUserName() { new Thread(new Runnable() {
       public void run() {
         GenerateUserIF.this.performUsernameValidation();
         while (!GenerateUserIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable() { public void run() {}
         });
       } }).start(); }
   
   private JComboBox comboEnvironment;
   private JComboBox comboOrgs;
   private JComboBox comboRole;
   private JComboBox comboSkillClass;
   private JEditorPane editorResults;
   
   private void performUsernameValidation() { String valUsernameQuery = "";
     try {
       this.done = false;
       protectFields();
       
 
       this.conn = OracleConnectionManager.getConnection(getComboConnection());
       
       valUsernameQuery = "select user_name, employee_id from gets_lms_service_employee where user_name = '" + this.txtUsername.getText() + "' or employee_id = '" + this.txtUsername.getText() + "'";
       
 
 
       PreparedStatement prepStm2 = this.conn.prepareStatement(valUsernameQuery);
       ResultSet rs2 = prepStm2.executeQuery();
       
       if (rs2.next()) {
         this.lblValUsername.setText("<HTML><Font color=RED><B>Not Available</B></FONT></HTML>");
         do {
           if (rs2.getString("user_name").equals("txtUsername")) {
             this.lblValUsername.setToolTipText("Username is taken.");
           } else
             this.lblValUsername.setToolTipText("Duplicated Employee ID.");
         } while (rs2.next());
       } else {
         this.lblValUsername.setText("<HTML><Font color=GREEN><B>Available</B></FONT></HTML>");
       }
       
 
       prepStm2.close();
       rs2.close();
       releaseFields();
       this.done = true;
     }
     catch (Exception e)
     {
       this.buf = new StringBuffer("");
       this.buf.append("-- Fields --\n");
       this.buf.append("txtUsername: " + this.txtUsername.getText() + "\n");
       this.buf.append("-- Exception --\n");
       this.buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: GenerateUserIF, Method: performUsernameValidation", valUsernameQuery, this.buf.toString());
     } }
   
   private JLabel jLabel11;
   private JLabel jLabel12;
   private JLabel jLabel13;
   
   private void protectFields() { this.comboEnvironment.setEnabled(false);
     this.txtUsername.setEnabled(false);
     this.txtFirstName.setEnabled(false);
     this.txtLastName.setEnabled(false);
     this.comboOrgs.setEnabled(false);
     this.txtUserEmail.setEnabled(false);
     this.comboSkillClass.setEnabled(false);
     this.comboRole.setEnabled(false);
     this.txtMgrFirstName.setEnabled(false);
     this.txtMgrLastName.setEnabled(false);
     this.txtMgrEmail.setEnabled(false);
     this.txtComments.setEnabled(false);
     this.comboEmpClass.setEnabled(false);
     this.comboAccessLvl.setEnabled(false);
     this.listAvailableResps.setEnabled(false);
     this.btnAdd.setEnabled(false);
     this.btnRemove.setEnabled(false);
     this.btnAddAll.setEnabled(false);
     this.btnRemoveAll.setEnabled(false);
     this.listRequestedResps.setEnabled(false);
     this.btnGenerateScript.setEnabled(false);
     this.btnCopyClipboard.setEnabled(false);
     this.editorResults.setEnabled(false);
     this.btnValidateUsername.setEnabled(false);
   }
   
   private void releaseFields() {
     this.comboEnvironment.setEnabled(true);
     this.txtUsername.setEnabled(true);
     this.txtFirstName.setEnabled(true);
     this.txtLastName.setEnabled(true);
     this.comboOrgs.setEnabled(true);
     this.txtUserEmail.setEnabled(true);
     this.comboSkillClass.setEnabled(true);
     this.comboRole.setEnabled(true);
     this.txtMgrFirstName.setEnabled(true);
     this.txtMgrLastName.setEnabled(true);
     this.txtMgrEmail.setEnabled(true);
     this.txtComments.setEnabled(true);
     this.comboEmpClass.setEnabled(true);
     this.comboAccessLvl.setEnabled(true);
     this.listAvailableResps.setEnabled(true);
     this.btnAdd.setEnabled(true);
     this.btnRemove.setEnabled(true);
     this.btnAddAll.setEnabled(true);
     this.btnRemoveAll.setEnabled(true);
     this.listRequestedResps.setEnabled(true);
     this.btnGenerateScript.setEnabled(true);
     this.btnCopyClipboard.setEnabled(true);
     this.editorResults.setEnabled(true);
     this.btnValidateUsername.setEnabled(true);
   }
   
   private int getComboConnection() {
     switch (this.comboEnvironment.getSelectedIndex()) {
     case 0: 
       return 0;
     case 1: 
       return 1;
     case 2: 
       return 2;
     case 3: 
       return 3;
     }
     return 0; }
   
   private JLabel jLabel14;
   private JLabel jLabel15;
   private JLabel jLabel16;
   private JLabel jLabel17;
   private JLabel jLabel2;
   private JLabel jLabel3;
   private JLabel jLabel4;
   private JLabel jLabel5;
   private JLabel jLabel6;
   private JLabel jLabel7;
   private JLabel jLabel8;
   
   private void initComponents() { this.comboEnvironment = new JComboBox();
     this.jLabel11 = new JLabel();
     this.jPanel3 = new JPanel();
     this.jLabel9 = new JLabel();
     this.txtUsername = new JTextField();
     this.btnValidateUsername = new JButton();
     this.lblValUsername = new JLabel();
     this.jLabel2 = new JLabel();
     this.txtFirstName = new JTextField();
     this.jLabel3 = new JLabel();
     this.txtLastName = new JTextField();
     this.jLabel5 = new JLabel();
     this.comboOrgs = new JComboBox();
     this.jLabel15 = new JLabel();
     this.txtUserEmail = new JTextField();
     this.jPanel4 = new JPanel();
     this.jLabel4 = new JLabel();
     this.comboSkillClass = new JComboBox();
     this.jLabel12 = new JLabel();
     this.comboRole = new JComboBox();
     this.jLabel6 = new JLabel();
     this.txtMgrFirstName = new JTextField();
     this.jLabel7 = new JLabel();
     this.txtMgrLastName = new JTextField();
     this.jLabel16 = new JLabel();
     this.txtMgrEmail = new JTextField();
     this.jLabel8 = new JLabel();
     this.txtComments = new JTextField();
     this.jLabel13 = new JLabel();
     this.comboEmpClass = new JComboBox();
     this.jLabel14 = new JLabel();
     this.comboAccessLvl = new JComboBox();
     this.jPanel2 = new JPanel();
     this.jScrollPane1 = new JScrollPane();
     this.listAvailableResps = new JList();
     this.btnAdd = new JButton();
     this.btnRemove = new JButton();
     this.btnAddAll = new JButton();
     this.btnRemoveAll = new JButton();
     this.jScrollPane2 = new JScrollPane();
     this.listRequestedResps = new JList();
     this.btnGenerateScript = new JButton();
     this.btnCopyClipboard = new JButton();
     this.jLabel17 = new JLabel();
     this.jScrollPane3 = new JScrollPane();
     this.editorResults = new JEditorPane();
     this.jProgressBar1 = new JProgressBar();
     
     setDefaultCloseOperation(2);
     
     this.comboEnvironment.setModel(new DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));
     this.comboEnvironment.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.comboEnvironmentActionPerformed(evt);
       }
       
     });
     this.jLabel11.setText("Please fill the form, all fields are mandatory:");
     
     this.jLabel9.setText("User Name:");
     
     this.btnValidateUsername.setText("Validate");
     this.btnValidateUsername.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnValidateUsernameActionPerformed(evt);
       }
       
     });
     this.jLabel2.setText("First Name:"); 
     this.jLabel3.setText("Last Name");
     this.jLabel5.setText("Service Org:"); 
     this.comboOrgs.setModel(new DefaultComboBoxModel(new String[] { "Populating service organizations..." }));    
     this.jLabel15.setText("User Email:");    
     this.jLabel4.setText("Skill Classif:");    
     this.comboSkillClass.setModel(new DefaultComboBoxModel(new String[] { "-- Select Skill Class --", "APPRENTICE", "AUTHOR", "BOILER_MAKER", "CARMAN", "CRAFTSPERSON", "CWC_PARTS_CATALOG", "ELECTRICIAN", "HDM", "HELPER", "INSPECTOR", "LABORER", "LABORERs", "MACHINIST", "PAINTER", "PIPE_FITTER", "PROGRAM_ADMINISTRATOR", "PROGRAM_FIELD_USER", "PROGRAM_IMPLEMENTATION", "SMW", "STOCK_KEEPER", "TECHNICAL DIRECTOR", "UNKNOWN" }));   
     this.jLabel12.setText("Role:");     
     this.comboRole.setModel(new DefaultComboBoxModel(new String[] { "--", "TD", "CR" }));    
     this.jLabel6.setText("Mgr F. Name:");  
     this.jLabel7.setText("Last Name:");
     this.jLabel16.setText("Mgr. Email:");
     this.jLabel8.setText("Comments:"); 
     this.jLabel13.setText("Emp. Class:");
     this.comboEmpClass.setModel(new DefaultComboBoxModel(new String[] { "--", "RR NPA", "RR PA", "GE NPA", "GE PA", "GE HPA", "SYSTEM" }));   
     this.jLabel14.setText("Access Lvl:");   
     this.comboAccessLvl.setModel(new DefaultComboBoxModel(new String[] { "--", "NAR", "SONR" }));    
     GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
     this.jPanel4.setLayout(jPanel4Layout);
     jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtMgrFirstName, -2, 107, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel7).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtMgrLastName, -2, 109, -2)).addGroup(jPanel4Layout.createSequentialGroup().addContainerGap().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel16).addComponent(this.jLabel8)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(this.txtMgrEmail, -2, 303, -2).addComponent(this.txtComments, -2, 303, -2))).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel4).addGap(4, 4, 4).addComponent(this.comboSkillClass, -2, 167, -2).addGap(15, 15, 15).addComponent(this.jLabel12).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.comboRole, -2, 93, -2)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel13).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.comboEmpClass, -2, 74, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel14).addGap(2, 2, 2).addComponent(this.comboAccessLvl, -2, 74, -2))))).addContainerGap(24, 32767)));
     jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.comboSkillClass, -2, -1, -2).addComponent(this.jLabel4).addComponent(this.jLabel12).addComponent(this.comboRole, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6).addComponent(this.txtMgrFirstName, -2, -1, -2).addComponent(this.jLabel7).addComponent(this.txtMgrLastName, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtMgrEmail, -2, -1, -2).addComponent(this.jLabel16)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8).addComponent(this.txtComments, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel13).addComponent(this.comboEmpClass, -2, -1, -2).addComponent(this.jLabel14).addComponent(this.comboAccessLvl, -2, -1, -2)).addContainerGap(30, 32767)));
     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
     this.jPanel3.setLayout(jPanel3Layout);
     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup().addContainerGap(14, 32767).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.lblValUsername, -2, 139, -2).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel4, GroupLayout.Alignment.TRAILING, -2, -1, -2).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addGroup(GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.jLabel15).addGap(3, 3, 3).addComponent(this.txtUserEmail)).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.CENTER, jPanel3Layout.createSequentialGroup().addComponent(this.jLabel5).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.comboOrgs, -2, 304, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel9).addGap(10, 10, 10).addComponent(this.txtUsername, -2, 114, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnValidateUsername)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel2).addGap(10, 10, 10).addComponent(this.txtFirstName, -2, 114, -2).addGap(18, 18, 18).addComponent(this.jLabel3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtLastName, -2, 114, -2))))))));
     
     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblValUsername, -2, 21, -2).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel9).addComponent(this.txtUsername, -2, -1, -2).addComponent(this.btnValidateUsername))).addGap(9, 9, 9).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel2).addComponent(this.txtFirstName, -2, -1, -2).addComponent(this.jLabel3).addComponent(this.txtLastName, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.comboOrgs, -2, -1, -2).addComponent(this.jLabel5)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtUserEmail, -2, -1, -2).addComponent(this.jLabel15)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel4, -2, -1, -2).addContainerGap()));
 
     this.listAvailableResps.setModel(new javax.swing.AbstractListModel() {
       String[] strings = { "Please wait while we populate the responsibilities..." };
       public int getSize() { return this.strings.length; }
       public Object getElementAt(int i) { return this.strings[i]; }
     });
     this.listAvailableResps.addMouseListener(new java.awt.event.MouseAdapter() {
       public void mouseClicked(MouseEvent evt) {
         GenerateUserIF.this.listAvailableRespsMouseClicked(evt);
       }
     });
     this.jScrollPane1.setViewportView(this.listAvailableResps);
     
     this.btnAdd.setText("Add");
     this.btnAdd.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnAddActionPerformed(evt);
       }
       
     });
     this.btnRemove.setText("Remove");
     this.btnRemove.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnRemoveActionPerformed(evt);
       }
       
     });
     this.btnAddAll.setText("Add All");
     this.btnAddAll.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnAddAllActionPerformed(evt);
       }
       
     });
     this.btnRemoveAll.setText("Reset");
     this.btnRemoveAll.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnRemoveAllActionPerformed(evt);
       }
       
     });
     this.listRequestedResps.addMouseListener(new java.awt.event.MouseAdapter() {
       public void mouseClicked(MouseEvent evt) {
         GenerateUserIF.this.listRequestedRespsMouseClicked(evt);
       }
     });
     this.jScrollPane2.setViewportView(this.listRequestedResps);
     
     this.btnGenerateScript.setText("Create account script");
     this.btnGenerateScript.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnGenerateScriptActionPerformed(evt);
       }
       
     });
     this.btnCopyClipboard.setText("Save to File");
     this.btnCopyClipboard.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         GenerateUserIF.this.btnCopyClipboardActionPerformed(evt);
       }
       
     });
     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
     this.jPanel2.setLayout(jPanel2Layout);
     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.btnAdd).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnRemove).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.btnAddAll).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.btnRemoveAll)).addComponent(this.jScrollPane2).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.btnGenerateScript, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.btnCopyClipboard, -2, 145, -2))).addContainerGap()));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 91, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.btnAddAll).addComponent(this.btnAdd).addComponent(this.btnRemove).addComponent(this.btnRemoveAll)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jScrollPane2, -2, 98, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.btnCopyClipboard).addComponent(this.btnGenerateScript)).addGap(0, 11, 32767)));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     this.jLabel17.setText("Available Responsibilities:");
     
     this.editorResults.setEditable(false);
     this.editorResults.setFont(new java.awt.Font("Courier New", 0, 12));
     this.jScrollPane3.setViewportView(this.editorResults);
     
     GroupLayout layout = new GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane3, -2, 0, 32767).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jProgressBar1, -2, 181, -2))).addContainerGap()).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.comboEnvironment, -2, 74, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel11)).addComponent(this.jPanel3, -2, -1, -2)).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(16, 16, 16).addComponent(this.jLabel17).addGap(0, 269, 32767)).addGroup(layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel2, -1, -1, 32767)))))));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.comboEnvironment, -2, -1, -2).addComponent(this.jLabel11).addComponent(this.jLabel17)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel3, -2, -1, -2).addComponent(this.jPanel2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane3, -2, 192, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jProgressBar1, -1, -1, 32767).addContainerGap()));
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     pack(); }
   
   private JLabel jLabel9;
   
   private void btnValidateUsernameActionPerformed(ActionEvent evt) { if (this.txtUsername.getText().isEmpty()) {
       this.lblValUsername.setText("<HTML><Font color=BLACK><B>Enter Username.</B></FONT></HTML>");
     }
     else
       validateUserName();
   }
   
   private JPanel jPanel2;
   
   private void btnAddActionPerformed(ActionEvent evt) { addSelectedResponsibilities(); }
   
   private JPanel jPanel3;
   
   private void listAvailableRespsMouseClicked(MouseEvent evt) { if (evt.getClickCount() == 2)
       addSelectedResponsibilities();
   }
   
   private JPanel jPanel4;
   private JProgressBar jProgressBar1;
   private void btnRemoveActionPerformed(ActionEvent evt) { removeSelectedResponsibilities(); }
   
   private void listRequestedRespsMouseClicked(MouseEvent evt)
   {
     if (evt.getClickCount() == 2) {
       removeSelectedResponsibilities();
     }
   }
   
   private void btnAddAllActionPerformed(ActionEvent evt) {
     addAllResponsibilities();
   }
   
   private void btnRemoveAllActionPerformed(ActionEvent evt) {
     removeAllResponsibilities();
   }
   
   private void btnGenerateScriptActionPerformed(ActionEvent evt) {
     if ((this.txtComments.getText().trim().isEmpty()) || (this.txtFirstName.getText().trim().isEmpty()) || (this.txtLastName.getText().trim().isEmpty()) || (this.txtMgrEmail.getText().trim().isEmpty()) || (this.txtMgrFirstName.getText().trim().isEmpty()) || (this.txtMgrLastName.getText().trim().isEmpty()) || (this.txtUserEmail.getText().trim().isEmpty()) || (this.txtUsername.getText().trim().isEmpty()) || (this.comboOrgs.getSelectedIndex() == 0) || (this.comboSkillClass.getSelectedIndex() == 0) || (this.comboRole.getSelectedIndex() == 0) || (this.comboEmpClass.getSelectedIndex() == 0) || (this.comboAccessLvl.getSelectedIndex() == 0))
     {
 
 
 
 
 
 
 
 
 
 
 
       this.editorResults.setText("All fields are mandatory, please check the form.");
     }
     else if (this.listRequestedResps.getModel().getSize() == 0) {
       this.editorResults.setText("Please add at least one responsibility.");
     } else
       generateUserScript(); }
   private JScrollPane jScrollPane1;
   private JScrollPane jScrollPane2;
   private JScrollPane jScrollPane3;
   private JLabel lblValUsername;
   
   private void btnCopyClipboardActionPerformed(ActionEvent evt) { 
     JFileChooser fc = new JFileChooser();
     fc.setFileFilter(new util.FolderFilter());
     fc.setFileSelectionMode(1);
     
     int returnVal = fc.showOpenDialog(this);
     
     if (returnVal == 0)
       try {
         org.apache.commons.io.FileUtils.write(new File(fc.getSelectedFile().getAbsolutePath() + "\\\\AccountInsert-" + this.txtUsername.getText().trim().toUpperCase() + ".sql"), this.editorResults.getText());
         javax.swing.JOptionPane.showMessageDialog(null, "Operation Successful!", "File saved!", -1);
       } catch (Exception e) {
         System.out.println(e.getMessage()); } 
   }
   
   private JList listAvailableResps;
   private JList listRequestedResps;
   private JTextField txtComments;
   private JTextField txtFirstName;
   private JTextField txtLastName;
   
   private void comboEnvironmentActionPerformed(ActionEvent evt) { fetchOrgData();
     fetchRespList(); }
   
   private JTextField txtMgrEmail;
   private JTextField txtMgrFirstName;
   
   private void generateUserScript() { StringBuffer res = new StringBuffer();
     this.editorResults.setText("");
     
     res.append("DECLARE\n    v_employee_id NUMBER;\n    v_usrid NUMBER;\nBEGIN\n     \n      -- " + this.txtFirstName.getText() + " " + this.txtLastName.getText() + "\n" + "      select gets_lms.gets_lms_service_employee_s.NEXTVAL into v_employee_id from dual;\n" + "      select GET_LMS_SERV_EMP_UID_S.NEXTVAL into v_usrid from dual;\n" + "      Insert into GETS_LMS_SERVICE_EMPLOYEE (SERVICE_EMPLOYEE_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY,EMPLOYEE_ID,\n" + "      EMPLOYEE_LASTNAME,EMPLOYEE_FIRSTNAME,WORK_SHIFT,LAST_UPDATE_LOGIN,LABOR_RATE,SKILL_CLASS,SERVICE_ORGANIZATION_ID,EFFECTIVE_FROM_DATE,\n" + "      EFFECTIVE_TO_DATE,ATTRIBUTE_CATEGORY,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,\n" + "      ATTRIBUTE10,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15,USER_ID,USER_PASSWORD,JOB_CODE,LANGUAGE_CODE,TOOLBOX_LEVEL,\n" + "      TIMEKEEPING_GROUP,REQUESTED_DATE,REQUESTED_BY_FIRSTNAME,REQUESTED_BY_LASTNAME,REQUESTOR_EMAIL,REQUESTOR_PHONE,REQUESTOR_COMMENTS,\n" + "      LAST_LOGON_DATE,ACTIVE_FLAG,INACTIVE_REASON,BAD_LOGON_ATTEMPTS,EMPLOYEE_EMAIL,USER_NAME,JOBCODE_ID,EMPLOYED_BY,USER_ROLE,\n" + "      PRE_SSO_USER_NAME,USERNAME_SSO_CONVERTED,CURRENT_RESPONSIBILITY,EMPLOYEE_CLASS,ACCESS_LEVEL)\n" + "      values (v_employee_id,sysdate,89281,sysdate,89281,\n" + "      '" + this.txtUsername.getText().trim() + "', -- SSO, employee_id\n" + "      '" + this.txtLastName.getText() + "', -- last name\n" + "      '" + this.txtFirstName.getText() + "', -- first name\n" + "      '1',null,0,'" + this.comboSkillClass.getSelectedItem().toString() + "',\n" + "      " + ((ServiceOrgData)this.comboOrgs.getSelectedItem()).getId() + ", -- service organization\n" + "      sysdate,\n" + "      null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,v_usrid,null,null,'ENG',\n" + "      '01',null,sysdate,\n" + "      '" + this.txtMgrFirstName.getText() + "', -- Manager First name\n" + "      '" + this.txtMgrLastName.getText() + "', -- Manager lastname\n" + "      '" + this.txtMgrEmail.getText() + "', --manager email\n" + "      null,\n" + "      '" + this.txtComments.getText() + "', -- request comments\n" + "      sysdate,'YES',null,0,\n" + "      '" + this.txtUserEmail.getText() + "', --users email\n" + "      '" + this.txtUsername.getText().trim() + "', -- username\n" + "      null,null,'" + this.comboRole.getSelectedItem() + "',null,null,\n" + "      null, -- selected responsibility\n" + "      '" + this.comboEmpClass.getSelectedItem() + "','" + this.comboAccessLvl.getSelectedItem() + "');\n" + "    \n");
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
     for (int i = 0; i < this.listRequestedResps.getModel().getSize(); i++) {
       res.append("      INSERT INTO gets_lms.gets_lms_user_resp_groups (user_id, responsibility_id, responsibility_application_id, security_group_id, start_date, end_date, description, created_by, creation_date, last_updated_by, last_update_date, last_update_login, landing_page) \n      VALUES (v_usrid, " + ((RespData)((DefaultListModel)this.listRequestedResps.getModel()).elementAt(i)).getId() + ", " + ((RespData)((DefaultListModel)this.listRequestedResps.getModel()).elementAt(i)).getApplicationId() + ", 0, sysdate, null, null, null, null, null, null, null, null); \n");
     }
     
 
 
     res.append("commit;\n END;");
     this.editorResults.setText(res.toString()); }
   
   private JTextField txtMgrLastName;
   
   private void addAllResponsibilities() { this.listAvailableResps.setModel(new DefaultListModel());
     this.listRequestedResps.setModel(this.tempModel);
   }
   
   private JTextField txtUserEmail;
   
   private void removeAllResponsibilities() { this.listRequestedResps.setModel(new DefaultListModel());
     this.listAvailableResps.setModel(this.tempModel);
   }
   
   private JTextField txtUsername;
   private void addSelectedResponsibilities() { int[] selectedIndexes = this.listAvailableResps.getSelectedIndices();
     for (int i = 0; i < selectedIndexes.length; i++) {
       Object r = this.listAvailableResps.getModel().getElementAt(selectedIndexes[i]);
       ((DefaultListModel)this.listRequestedResps.getModel()).addElement(r);
       ((DefaultListModel)this.listAvailableResps.getModel()).remove(selectedIndexes[i]);
     }
   }
   
   private void removeSelectedResponsibilities() {
     int[] selectedIndexes = this.listRequestedResps.getSelectedIndices();
     for (int i = 0; i < selectedIndexes.length; i++) {
       Object r = this.listRequestedResps.getModel().getElementAt(selectedIndexes[i]);
       ((DefaultListModel)this.listAvailableResps.getModel()).addElement(r);
       ((DefaultListModel)this.listRequestedResps.getModel()).remove(selectedIndexes[i]);
     }
   }
 }


//GE Confidential