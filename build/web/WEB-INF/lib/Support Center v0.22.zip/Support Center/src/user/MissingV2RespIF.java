 package user;
 
 import java.awt.Container;
 import java.awt.Font;
 import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
 import java.sql.Connection;
 import java.sql.PreparedStatement;
 import java.sql.ResultSet;
 import javax.swing.GroupLayout;
 import javax.swing.*;
 import javax.swing.GroupLayout.Alignment;
 import javax.swing.GroupLayout.ParallelGroup;
 import javax.swing.GroupLayout.SequentialGroup;
 import javax.swing.JButton;
 import javax.swing.JInternalFrame;
 import javax.swing.JScrollPane;
 import javax.swing.JTextArea;
 import javax.swing.event.InternalFrameEvent;
 
 public class MissingV2RespIF extends JInternalFrame
 {
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf = new StringBuffer();
   private JTextArea areaResults;
   
   public MissingV2RespIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     initComponents();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { MissingV2RespIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
 
 
   private JButton btnRun;
   
   private JScrollPane jScrollPane1;
   
   private void initComponents()
   {
     this.btnRun = new JButton();
     this.jScrollPane1 = new JScrollPane();
     this.areaResults = new JTextArea();
     
     setDefaultCloseOperation(2);
     
     this.btnRun.setText("Generate Script");
     this.btnRun.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent evt) {
         MissingV2RespIF.this.btnRunActionPerformed(evt);
       }
       
     });
     this.areaResults.setEditable(false);
     this.areaResults.setColumns(20);
     this.areaResults.setFont(new Font("Courier New", 0, 13));
     this.areaResults.setRows(5);
     this.jScrollPane1.setViewportView(this.areaResults);
     
     GroupLayout layout = new GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 670, 32767).addComponent(this.btnRun, -2, 186, -2)).addContainerGap()));
     
 
 
 
 
 
 
 
     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.btnRun).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 293, 32767).addContainerGap()));
     
 
 
 
 
 
 
 
 
     pack();
   }
   
   private void btnRunActionPerformed(ActionEvent evt) {
     loadList();
   }
   
   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         MissingV2RespIF.this.fetchMissing2Users();
         while (!MissingV2RespIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void fetchMissing2Users()
   {
     try {
       this.done = false;
       this.btnRun.setEnabled(false);
       this.areaResults.setText("");
       this.buf = new StringBuffer();
       
 
       this.conn = util.OracleConnectionManager.getConnection(0);
       
       if (this.conn == null) {
         this.areaResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       String insertQuery = "select user_name, employee_firstname, employee_lastname, creation_date, user_id, active_flag from gets_lms_service_employee where user_id in (\nSELECT distinct emp.user_id FROM gets_lms_service_employee emp, gets_lms.gets_lms_user_resp_groups grp \nWHERE emp.user_id = grp.user_id             \nAND emp.skill_class <> 'CWC_PARTS_CATALOG'\nAND emp.active_flag = 'YES'\nAND NOT EXISTS (SELECT * FROM GETS_LMS.GETS_LMS_USER_RESP_GROUPS where user_id = emp.user_id AND responsibility_id = 57798))  \nAND service_organization_id not in (select service_organization_id from gets_lms_customer_orgs_v where customer_id in (1011, 1258))  \norder by user_name asc ";
       
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(insertQuery);
       this.rs = this.prepStm.executeQuery();
       
       this.buf.append("BEGIN\n\n");
       this.buf.append("-- New Users missing 2.0 Craftsperson \n");
       if (this.rs.next()) {
         do {
           this.buf.append("INSERT INTO gets_lms.gets_lms_user_resp_groups (user_id, responsibility_id, responsibility_application_id, security_group_id, start_date, end_date, description, created_by, creation_date, last_updated_by, last_update_date, last_update_login, landing_page) VALUES (");
           this.buf.append(this.rs.getString("user_id"));
           this.buf.append(",57798,20008, 0, sysdate, null, null, 104390, sysdate, 104390, sysdate, null, null);\n");
         } while (this.rs.next());
       } else {
         this.buf.append("-- No new users found requiring insert.");
       }
       
       this.prepStm.close();
       this.rs.close();
       
       String updateQuery = "select user_name, employee_firstname, employee_lastname, creation_date, user_id from gets_lms_service_employee where user_id in (\nSELECT distinct emp.user_id FROM gets_lms_service_employee emp, gets_lms.gets_lms_user_resp_groups grp\nWHERE emp.user_id = grp.user_id\nAND emp.skill_class <> 'CWC_PARTS_CATALOG'\nAND emp.active_flag = 'YES'\nAND grp.responsibility_id = 57798 \nAND grp.end_date is not null)\n  AND service_organization_id not in (select service_organization_id from gets_lms_customer_orgs_v where customer_id = 1011) order by user_id asc \n";
       
 
 
 
 
 
 
 
 
       this.prepStm = this.conn.prepareStatement(updateQuery);
       this.rs = this.prepStm.executeQuery();
       
       this.buf.append("\n\n-- Existing users with expired 2.0 responsibilities.\n");
       if (this.rs.next()) {
         do {
           this.buf.append("UPDATE gets_lms.gets_lms_user_resp_groups SET end_date = null where responsibility_id = 57798 and user_id = ");
           this.buf.append(this.rs.getString("user_id"));
           this.buf.append(";\n");
         } while (this.rs.next());
       } else {
         this.buf.append("-- No users found requiring update.");
       }
       
       this.buf.append("\nCOMMIT;\nEND;\n");
       this.areaResults.setText(this.buf.toString());
       this.btnRun.setEnabled(true);
       this.done = true;
     }
     catch (Exception e) {
       e.printStackTrace();
     }
   }
 }


//GE Confidential