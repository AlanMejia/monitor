/*
  v0.14
  - Recreated as a netbeans form
  v 0.21
  - We have a bug that does not delete the tasks of a service sheet when its pended. 
    Added a check for it that will notify the service_sheet_id, the service_sheet_comments and the amount of tasks. 
  v 0.22
  - Added a check that will show which tasks were signed off by ANONYMOUS, probably the support team, for task research purposes.
*/

package servicesheet;

import eservicesmanager.SupportCenter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import util.JErrorLog;
import util.workorder.WorkorderData;


public class OpenTaskInfoHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private WorkorderData wo;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;
    
    public OpenTaskInfoHelperIF(final JDesktopPane desktop, SupportCenter parent, WorkorderData wo, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.wo = wo;
     this.environment = environment;
     
     initComponents();
     
     editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");          
     loadInformation();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { OpenTaskInfoHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchTaskInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchTaskInfo()
   {
     String taskQuery = "";
     
     try
     {
       conn = util.OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       buf = new StringBuffer();
       buf.append("<HTML><BODY>");
       buf.append("<H2>Task report for  " + wo.getNumber() + " (" + wo.getId() + ")</H2>");
       
       taskQuery = "select service_workorder_id, task_number, service_sheet_id, plan_description from gets_lms_qa_results qa, getS_lms_qa_chars cha where "
               + " qa.char_id = cha.char_id "
               + " AND qa.service_Workorder_id = " + wo.getId()  
               + " and qa.column_value is null "
               + " and qa.performed_flag = 'Y' "
               + " and (cha.char_type_code = 'VARIABLE' or cha.char_type_code = 'LOV') " + "order by plan_description asc";
       
       prepStm = conn.prepareStatement(taskQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<BR><H3>The following LOV/Variable tasks were found with a perfomed_flag of Y and no value:</H3>");
         buf.append("<TABLE border = 1 width=100%>"
                 + "<TR>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>SS ID</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Plan Description</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Task Number</B></TD>"
                 + "</TR>");         
         do
         {
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("service_sheet_id") + "</TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("plan_description") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("task_number") + "</TD>" 
                   + "</TR>");
         }
         while (rs.next());
         
         buf.append("</TABLE>");
       } else {
         buf.append("<HTML><H3>No open LOV/Variable tasks with a performed flag of Y and no value.</H3>");
       }
       
       prepStm.close();
       rs.close();
   
       /************** Check for tasks in Pended service sheets ******************/
       taskQuery = "select count(qa.service_sheet_id) as open_tasks, qa.service_sheet_id, ss.service_sheet_comments\n" +
            "from gets_lms_qa_results qa, gets_lms_service_sheet ss \n" +
            "where ss.service_sheet_id = qa.service_sheet_id \n" +
            "and qa.service_workorder_id = " + wo.getId() + " \n" +
            "and ss.service_sheet_status_code = 100\n" +
            "group by qa.service_sheet_id, ss.service_sheet_comments";
       
       prepStm = conn.prepareStatement(taskQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<BR><H3>The following tasks were found in PENDED service sheets:</H3>");
         buf.append("<TABLE border = 1 width=100%>"
                 + "<TR>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>SS ID</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Service Sheet Comments</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Task Count</B></TD>"
                 + "</TR>");         
         do
         {
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("service_sheet_id") + "</TD>"
                   + "   <TD >" + rs.getString("service_sheet_comments") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("open_tasks") + "</TD>" 
                   + "</TR>");
         }
         while (rs.next());
         
         buf.append("</TABLE>");
       } else {
         buf.append("<HTML><H3>No tasks were found in PENDED service sheets.</H3>");
       }
       
       prepStm.close();
       rs.close();
       /************** Check for tasks in Pended service sheets ******************/
     
       /************** Check for tasks that were signed off by the support team ******************/
       taskQuery = "select qa.task_number, qa.plan_description, \n" +
                    "NVL((select service_item from ESV_WRKSCPE.ESV_SERVICE_ITEM where service_item_id = qa.service_item_id), 'No Service Item') as service_item,\n" +
                    "qa.column_value, qa.service_sheet_id from gets_lms_qa_results qa where \n" +
                    "qa.performed_flag = 'Y'\n" +
                    "and qa.last_updated_by = -1\n" +
                    "and qa.service_workorder_id =" + wo.getId() +
                    " order by service_item_id ";
       
       prepStm = conn.prepareStatement(taskQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<BR><H3>Tasks signed off by ANONYMOUS (probably Support team):</H3>");
         buf.append("<TABLE border = 1 width=100%>"
                 + "<TR>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Task Number</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Plan Description</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Service Item</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Signed off Value</B></TD>"
                 + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Service Sheet ID</B></TD>"
                 + "</TR>");         
         do
         {
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("task_number") + "</TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("plan_description") + "</TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("service_item") + "</TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("column_value") + "</TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("service_sheet_id") + "</TD>"
                   + "</TR>");
         }
         while (rs.next());
         
         buf.append("</TABLE>");
       } else {
        buf.append("<HTML><H3>No tasks signed off by ANONYMOUS.</H3>");
       }
       
       prepStm.close();
       rs.close();
       /************** Check for tasks that were signed off by the support team ******************/
       
       /************** Check for Open Tasks ******************/
//       ResultSet rsetServSheetTask = null;
//       ResultSet rsetFmiTask = null;
//       ResultSet rsetRXTask = null;
//       
//       String ssOpenTasks = "    select qar.char_id CHAR_ID,"
//               + "       qar.task_number TASK_NUMBER,"
//               + "       qar.performed_flag PERFORMED_FLAG,"
//               + "       decode('ENG','SPN',nvl(qar.task_description_spn, qar.task_description),"
//               + "              'FRN',nvl(qar.task_description_frn, qar.task_description),qar.task_description) TASK_DESCRIPTION,"
//               + "qar.qa_result_id QA_RESULT_ID,decode(qar.task_type,'REFERENCE INFO','N','ATTRIBUTE','N','ATTRIBUTE-CHAR','N',"
//               + "'ATTRIBUTE-KQC','N','LOV','Y','VARIABLE','Y','VARIABLE-CHAR','Y','Y') COLUMN_VALUE_REQUIRED,"
//               + "       qar.column_value COLUMN_VALUE,"
//               + "       qp.plan_id   PLAN_ID,"
//               + "       qp.name PLAN_NAME,"
//               + "       gls.service_sheet_id SERVICE_SHEET_ID,"
//               + "       gls.service_sheet_comments SERVICE_SHEET_COMMENT,"
//               + "       qar.COND_TASK_ID COND_TASK_ID,"
//               + "       qar.COND_BLOCK_ID COND_BLOCK_ID,"
//               + "       qar.service_workorder_id as qar_wo_id,"
//               + "       gls.service_workorder_id as ss_wo_id,"
//               + "       qar.COND_TASK_VALUE COND_TASK_VALUE"
//               + "  from GETS_LMS_QA_RESULTS             qar,"
//               + "       qa_plans                     qp,"
//               + "       gets_lms_service_sheet gls"
//               + " where qar.plan_id = qp.plan_id and"
//               + "       gls.service_sheet_id = qar.service_sheet_id and"
//               + "       qar.service_workorder_id = " + wo.getId() + " and qar.mandatory_flag = '1' and" 
//               + "       (( (qar.COND_BLOCK_ID is null) and ((qar.performed_flag = 'N')" 
//               + "       OR\n" 
//               + "       (decode(qar.task_type,\n" 
//               + "                   'LOV',\n" 
//               + "                   'Y',\n" 
//               + "                   'VARIABLE',\n" 
//               + "                   'Y',\n" 
//               + "                   'VARIABLE-CHAR',\n" 
//               + "                   'Y',\n" 
//               + "                   'N') = 'Y' AND qar.column_value is null)))\n" 
//               + "                   OR\n" 
//               + "       (qar.COND_BLOCK_ID is not null))\n" 
//               + " and qar.performed_flag <> 'Y' " 
//               + "         order by qar.service_sheet_id ";
//       
//       prepStm = conn.prepareStatement(ssOpenTasks);
//       
//       rsetServSheetTask = prepStm.executeQuery();
//       if (rsetServSheetTask.next()) {
//         buf.append("<BR><H3>Open Service Sheet tasks (<FONT COLOR=RED>RED SS ID</FONT> means a mismatch between SS WO_ID and Task WO_ID):</H3>");
//         buf.append("<TABLE border = 1 width=100%>\n<TR>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>SS ID</B></TD>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Plan Description</B></TD>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Task Number</B></TD"
//                 + "n</TR>");
//         
//         do
//         {
//           buf.append("<TR>"
//                   + "   <TD ALIGN=\"CENTER\" ><FONT COLOR=" + (rsetServSheetTask.getString("qar_wo_id").equals(rsetServSheetTask.getString("ss_wo_id")) 
//                           ? "BLUE" : "RED") + ">" + rsetServSheetTask.getString("SERVICE_SHEET_ID") + "</FONT></TD>" 
//                   + "   <TD ALIGN=\"CENTER\" >" + rsetServSheetTask.getString("PLAN_NAME") + "</TD>" 
//                   + "   <TD ALIGN=\"CENTER\" >" + rsetServSheetTask.getString("TASK_NUMBER") + "</TD>" 
//                   + "</TR>");
//         }
//         while (rsetServSheetTask.next());
//         
//         buf.append("</TABLE>");
//       }
//       
//       prepStm.close();
//       rsetServSheetTask.close();
//        
//       String fmiOpenTasks = "  select   h.fmi_id FMI_ID,"
//               + "            h.fmi_number FMI_NUMBER,"
//               + "            h.fmi_title FMI_TITLE,"
//               + "            a.qa_result_id QA_RESULT_ID,"
//               + "            b.task_description TASK_DESCRIPTION,"
//               + "            c.service_sheet_id, a.result_column_number     from gets_fmi_qa_results a,"
//               + "          gets_fmi_tasks b,"
//               + "          gets_lms_service_sheet c,"
//               + "          RA_HCUSTOMERS d,"
//               + "          gets_fmi_profile_task e,"
//               + "          gets_fmi_loco_assign f,"
//               + "          gets_fmi_entries h"
//               + "     where a.service_sheet_id = c.service_sheet_id"
//               + "     and c.customer_id = d.customer_id"
//               + "     and c.service_sheet_id = a.service_sheet_id"
//               + "     and f.locomotive_id = c.locomotive_id"
//               + "     and f.fmi_id = c.fmi_id"
//               + "     and e.profile_id = f.profile_id"
//               + "     and e.task_id = b.task_id"
//               + "     and a.task_id = e.task_id"
//               + "     and a.performed_flag='N'"
//               + "     and a.mandatory_flag='Y'"
//               + "     and c.service_workorder_id= " + wo.getId() 
//               + "     and c.fmi_flag is not null" 
//               + "     and h.fmi_id=c.fmi_id" 
//               + "     order by fmi_id ";
//       
//       prepStm = conn.prepareStatement(fmiOpenTasks);
//       rsetFmiTask = prepStm.executeQuery();
//       if (rsetFmiTask.next()) {
//         buf.append("<BR><H3>Open FMI tasks:</H3>");
//         buf.append("<TABLE border = 1 width=100%>"
//                 + "<TR>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>SS ID</B></TD>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>FMI Info</B></TD>"
//                 + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Task Number</B></TD>"
//                 + "</TR>");         
//         do
//         {
//           buf.append("<TR>"
//                   + "   <TD ALIGN=\"CENTER\" >" + rsetFmiTask.getString("SERVICE_SHEET_ID") + "</TD>" 
//                   + "   <TD ALIGN=\"CENTER\" >" + rsetFmiTask.getString("FMI_NUMBER") + " ( " + rsetFmiTask.getString("FMI_ID") + "): " + rsetFmiTask.getString("FMI_TITLE") + "</TD>" 
//                   + "   <TD ALIGN=\"CENTER\" >" + rsetFmiTask.getString("result_column_number") + "</TD>"
//                   + "</TR>");
// 
//         }
//         while (rsetFmiTask.next());
//         
//         buf.append("</TABLE>");
//       }
//       
//       rsetFmiTask.close();
//       prepStm.close();
       /************** Check for Open Tasks ******************/
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("Workorder id: " + wo.getId() + "\n");
       buf.append("Environment: " + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: OpenTaskInfoHelperIF, Method: fetchTaskInfo", taskQuery, buf.toString());
       
       editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential