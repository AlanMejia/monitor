/*
  v 0.13
  - Recreated as a netbeans form.
  - Changed the query to find the service item to use the new ESV_WRKSCPE.ESV_SERVICE_ITEM table.
  - Corrected a typo on the log output.
  v 0.16
  - Null service sheet comments appeared as "null", they will now show as "-".
  - Corrected an issue that would not inform that a service sheet was not found and it would print out the service status info.
  v 0.19
  - Formatted the dates to a more comfortable standard.
*/

package servicesheet;

import static com.sun.java.accessibility.util.SwingEventMonitor.addInternalFrameListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import util.OracleConnectionManager;

public class ServiceSheetInfoIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private SimpleDateFormat dateFormatter;
   private SimpleDateFormat timeFormatter;
   private StringBuffer buf;
   private boolean done;
   
    public ServiceSheetInfoIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearch);
     
     buf = new StringBuffer();
     
     dateFormatter = new SimpleDateFormat("EEE, MM-dd-yyyy, ");
     timeFormatter = new SimpleDateFormat("HH:mm z");
     done = false;
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { ServiceSheetInfoIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }

   private void cleanClose() {
     dispose();
   }
   
   private void getSSInfo() {
     new Thread(new Runnable()
     {
       public void run() {
         searchServiceSheetInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void searchServiceSheetInfo()
   {
     String serviceSheetQuery = "";
     StringBuffer buf = new StringBuffer();
     try
     {
       done = false;
       protectFields();
       
 
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       serviceSheetQuery = "select ss.service_sheet_id, NVL(ss.service_sheet_comments, '-') as service_sheet_comments,"
               + " NVL(ss.fmi_flag, 'N') as fmi_flag, ss.service_sheet_status_code,\n"
               + " ss.service_type_code, NVL(ss.due_flag, '-') as due_flag,\n"
               + " (select fmi_number from gets_fmi_entries where fmi_id = ss.fmi_id) as fmi_number,\n"
               + " (select fmi_title from gets_fmi_entries where fmi_id = ss.fmi_id) as fmi_title,\n"
               + " (select profile_name from gets_fmi_profile where profile_id = ss.profile_id) as profile_name,\n"
               + " to_char(ss.last_update_date, 'DD-Mon-yyyy HH24:MI:SS') as last_update_date, ss.fmi_id, ss.profile_id, "
               + "NVL((select service_item from ESV_WRKSCPE.ESV_SERVICE_ITEM where service_item_id = ss.service_item_id), '-') as service_item, \n"
               + " NVL(ss.service_item_id, 0) as service_item_id ,  NVL(ss.service_program_id, 0) as service_program_id ,  "
               + "NVL((select program_name from gets_lms_service_program where service_program_id = ss.service_program_id), '-') as service_program ,  "
               + "(select employee_firstname || ' ' || employee_lastname from gets_lms_service_employee where user_id = ss.last_updated_by) as last_updated_by_user,\n"
               + " NVL((select workorder_number from gets_lms_service_workorder where service_workorder_id = ss.service_workorder_id), 'No WO assigned') as workorder_number,\n"
               + " NVL((select workorder_status_code from gets_lms_service_workorder where service_workorder_id = ss.service_workorder_id), 0) as workorder_status_code,\n"
               + " NVL(ss.service_workorder_id, 0) as service_workorder_id,\n ss.locomotive_id ,\n"
               + " (select aar_road || '-' || road_number from gets_lms_locomotive_all where locomotive_id = ss.locomotive_id) as assigned_loco ,\n"
               + " (select count(*) from gets_lms_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'N') as open_tasks,\n"
               + " (select count(*) from gets_lms_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'Y') as signed_off_tasks,\n"
               + " (select count(*) from gets_lms_sr_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'N') as open_rx_tasks,\n"
               + " (select count(*) from gets_lms_sr_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'Y') as signed_off_rx_tasks,\n"
               + " (select count(*) from gets_fmi_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'N') as open_fmi_tasks,\n"
               + " (select count(*) from gets_fmi_qa_results where service_sheet_id = ss.service_sheet_id and performed_flag = 'Y') as signed_off_fmi_tasks \n"
               + " from gets_lms_service_sheet ss\n where service_sheet_id = " + txtSSId.getText();
       
       prepStm = conn.prepareStatement(serviceSheetQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<HTML><TABLE border = 1 width=100%>");
         do {
           buf.append("<TR>"
                   + "<TD bgcolor=\"#92CDDC\"><B>Comments</B></TD>"
                   + "<TD colspan=5>" + rs.getString("service_sheet_comments") + "</TD>" 
                   + "</TR>" 
                   + "<TR>" 
                   + "<TD><B>Status:</B> " + util.servicesheet.ServiceSheetUtil.translateSSStatus(rs.getString("service_sheet_status_code")) + "</TD>" + "<TD><B>Type Code:<B/> " + rs.getString("service_type_code") + " </TD>" 
                   + "<TD><B>Due?: </B> " + rs.getString("due_flag") + "</TD>" + "<TD><B>WO: </B> " + rs.getString("workorder_number") + "</TD>" 
                   + "<TD><B>Status: </B>" + util.workorder.WorkorderUtil.translateWOStatus(rs.getString("workorder_status_code")) + " </TD>" 
                   + "<TD><B>ID: </B>" + rs.getString("service_workorder_id") + " </TD>" 
                   + "</TR>" 
                   + "<TR>" 
                   + "<TD colspan=3><B>Last Upd by: </B> " + rs.getString("last_updated_by_user") + " <B>on</B> " + rs.getString("last_update_date") + " </TD>" 
                   + "<TD colspan=3><B>Service Item: </B> " + rs.getString("service_item") + (rs.getString("service_item_id").equals("0") ? "" : new StringBuilder().append(" (").append(rs.getString("service_item_id")).append(")").toString()) + "</TD>" 
                   + "</TR>" 
                   + "<TR>"
                   + "<TD colspan=3><B>Service Program: </B> " + rs.getString("service_program") + (rs.getString("service_program_id").equals("0") ? "" : new StringBuilder().append(" (").append(rs.getString("service_program_id")).append(")").toString()) + "</TD>" 
                   + "<TD colspan=3><B>Assigned to: </B>" + rs.getString("assigned_loco") + " (" + rs.getString("locomotive_id") + ")</TD>" 
                   + "</TR>" 
                   + (rs.getString("fmi_flag").equals("Y") ? "<TR><TD colspan = 6 bgcolor=\"#92CDDC\"><B>FMI Information</B></TD></TR><TR><TD colspan = 6><B>" + rs.getString("fmi_number") + " </B>, <B>ID: </B> " + rs.getString("fmi_id") + "<B>. Title: </B>" + rs.getString("fmi_title") + " </TD>" 
                           + "</TR>"
                           + "<TR>" 
                           + "<TD colspan = 6><B>Profile ID: </B> " + rs.getString("profile_id") + ", <B>Name: </B> " + rs.getString("profile_name") + " </TD>" 
                           + "</TR>" : "") 
                   + "</TR>");
         }
         while (rs.next());
       } else {
         editorResults.setText("<HTML><Font color=BLACK><H3>No Service Sheet found with that ID.</H3></FONT></HTML>");
         releaseFields();
         return;
       }
       
       prepStm.close();
       rs.close();
        
       String serviceStatusQuery = "select ss.status_sequence, ss.status_code, to_char(ss.status_date,'DD-Mon-yyyy HH24:MI:SS') as status_date, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = ss.last_updated_by) as status_by, \n"
               + "wo_ss_id from gets_lms_service_status ss where ss.wo_ss_id = " + txtSSId.getText() + "and ss.status_type_code = 'ServiceSheet' order by ss.status_sequence asc ";
       
       prepStm = conn.prepareStatement(serviceStatusQuery);
       rs = prepStm.executeQuery();
       
 
       buf.append("<BR></TABLE><TABLE width=100% border=1>"
               + "<TR>   "
               + "<TD colspan=4 bgcolor=\"#92CDDC\"><B>Service Status Information</B></TD>"
               + "</TR>");      
       buf.append("<TR>"
               + "   <TD align=\"center\"><B>Seq</B></TD>"
               + "   <TD align=\"center\"><B>Code</B></TD>"
               + "   <TD align=\"center\"><B>Status Date</B></TD>"
               + "   <TD align=\"center\"><B>Status By</B></TD>"
               + "</TR>");
       
       if (rs.next()) {
         do {
           buf.append("<TR>"
                   + "   <TD align=\"center\">" + rs.getString("status_sequence") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("status_code") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("status_date") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("status_by") + "</TD>" 
                   + "</TR>");
         }
         while (rs.next());
       } else {
         buf.append("No Service Status for this workorder, something is wrong.");
       }
       buf.append("</TABLE>");
       
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
       
       releaseFields();
       done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("Service Sheet ID: " + txtSSId.getText() + "\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: ServiceSheetInfoIF, Method: searchServiceSheetInfo", serviceSheetQuery, buf.toString());
        
       releaseFields();
       editorResults.setText("<HTML><H3>An error occurred, please check the logs.<H3></HTML>");
     }
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }  
   
   private void protectFields()
   {
     btnSearch.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     progressBar.setVisible(false);
   }
       
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtSSId = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Service Sheet ID:");

        txtSSId.setText("##########");
        txtSSId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSSIdFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtSSId, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtSSId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if (txtSSId.getText().trim().isEmpty()) {
       editorResults.setText("<HTML><H3>Please input the Service Sheet ID.<H3></HTML>");
       return;
     }
     try
     {
       Integer.parseInt(txtSSId.getText());
       getSSInfo();
       return;
     }
     catch (NumberFormatException e) {
       editorResults.setText("<HTML><H3>Please enter a numeric value.<H3></HTML>");
     }    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtSSIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSSIdFocusGained
        txtSSId.selectAll();
    }//GEN-LAST:event_txtSSIdFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtSSId;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential