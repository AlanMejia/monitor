 /*
  v 0.12  
    - Corrected an error that would not load any FMI data when "orphan" fmi service sheets would appear. Now the tool will 
    correctly display information of the service sheet and mention that it does not appear in the gets_fmi_loco_assign 
    table. 
  v 0.13
    - Recreated as a netbeans form
    - Added the "Pulling records..." message to inform the user that something is happening.
*/

package servicesheet;

import eservicesmanager.SupportCenter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import util.fmi.FMIUtil;
import util.servicesheet.ServiceSheetUtil;
import util.workorder.WorkorderData;


public class FMIInfoHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private WorkorderData wo;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;
   
    public FMIInfoHelperIF(final JDesktopPane desktop, SupportCenter parent, WorkorderData wo, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {

     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.wo = wo;
     this.environment = environment;
     
     initComponents();
     
     editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");      
     loadInformation();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { FMIInfoHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchFMIInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchFMIInfo()
   {
     String fmiDetailsQuery = "";
     String orphanFMIQuery = "";
     
     try
     {
       conn = util.OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       buf = new StringBuffer();
       orphanFMIQuery = " select distinct ss.service_sheet_comments, ss.service_sheet_id, ss.service_sheet_status_code, ss.fmi_id, fmi.fmi_number, \n"
               + " ss.profile_id, pro.profile_name, pro.profile_approve_status, fmi.fmi_title, fmi.description, fmi.current_status_code "
               + "from gets_lms_service_sheet ss, gets_fmi_entries fmi, gets_fmi_profile pro"
               + " where \n"
               + "   ss.fmi_id = fmi.fmi_id\n"
               + "   and ss.profile_id = pro.profile_id\n"
               + "   and ss.fmi_flag = 'Y'\n"
               + "   and not exists (select fmi_id from gets_fmi_loco_assign where fmi_id = ss.fmi_id and locomotive_id = ss.locomotive_id)\n"
               + "   and ss.service_workorder_id = " + wo.getId();
 
       prepStm = conn.prepareStatement(orphanFMIQuery);
       rs = prepStm.executeQuery();
       
       buf.append("<HTML><BODY>");
       if (rs.next()) {
         buf.append("<H3>The following FMI Service Sheets were found without an entry in GETS_FMI_LOCO_ASSIGN: </H3>");           
         buf.append("<TABLE border = 1>\n");
         do {
           buf.append("<TR>\n"
                   + "   <TD><B>SS Info:</B></TD>\n"
                   + "   <TD>" + rs.getString("service_sheet_comments") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("service_sheet_id") + ", <B>Status: </B> " + ServiceSheetUtil.translateSSStatus(rs.getString("service_sheet_status_code")) + "</TD>\n" 
                   + "</TR>\n" 
                   + "<TR>\n" 
                   + "   <TD><B>FMI Info:</B></TD>\n"
                   + "   <TD><B>" + rs.getString("fmi_number") + "</B>: " + rs.getString("fmi_title") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("fmi_id") + ", <B>Status: </B> " + FMIUtil.translateFMIStatus(rs.getString("current_status_code")) + "</TD>\n" 
                   + "</TR>\n"
                   + "<TR>\n" 
                   + "   <TD><B>SS Profile:</B></TD>\n" 
                   + "   <TD>" + rs.getString("profile_name") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("profile_id") + ", <B>Status: </B> " + FMIUtil.translateProfileStatus(rs.getString("profile_approve_status")) + "</TD>\n" 
                   + "</TR>\n");

         }
         while (rs.next());
         
         buf.append("</TABLE><BR>");
       }
        
       prepStm.close();
       rs.close();
       
       conn = util.OracleConnectionManager.getConnection(environment);
       fmiDetailsQuery = "select ss.service_sheet_id, ss.last_update_date, ss.last_updated_by, ss.service_sheet_comments, ss.service_sheet_status_code, ss.service_program_id, \n"
               + "ss.profile_id as ss_profile_id, pross.profile_name as ss_profile_name, pross.profile_approve_status as ss_profile_status,\n"
               + "prolas.profile_id as las_profile_id, prolas.profile_name as las_profile_name, prolas.profile_approve_status as las_profile_status,\n"
               + "fmi.fmi_title, fmi.description, fmi.current_status_code, las.assignment_status, las.completion_date, fmi.fmi_number, "
               + "fmi.fmi_id from "
               + "gets_lms_service_sheet ss, gets_fmi_entries fmi, gets_fmi_loco_assign las, gets_fmi_profile pross, gets_fmi_profile prolas\n"
               + "WHERE\n"
               + "ss.fmi_id = fmi.fmi_id\n"
               + "AND las.fmi_id = ss.fmi_id\n"
               + "AND las.locomotive_id = ss.locomotive_id \n"
               + "AND ss.profile_id = pross.profile_id\n"
               + "AND las.profile_id = prolas.profile_id\n"
               + "AND ss.service_workorder_id =  " + wo.getId();
       
       prepStm = conn.prepareStatement(fmiDetailsQuery);
       rs = prepStm.executeQuery();       
       if (rs.next()) {
         buf.append("<TABLE border = 1>\n");           
         do {
           buf.append("<TR>\n"
                   + "   <TD><B>SS Info:</B></TD>\n"
                   + "   <TD>" + rs.getString("service_sheet_comments") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("service_sheet_id") + ", <B>Status: </B> " + ServiceSheetUtil.translateSSStatus(rs.getString("service_sheet_status_code")) + "</TD>\n" 
                   + "</TR>\n" 
                   + "<TR>\n" 
                   + "   <TD><B>FMI Info:</B></TD>\n" 
                   + "   <TD><B>" + rs.getString("fmi_number") + "</B>: " + rs.getString("fmi_title") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("fmi_id") + ", <B>Status: </B> " + FMIUtil.translateFMIStatus(rs.getString("current_status_code")) + "</TD>\n" 
                   + "</TR>\n" 
                   + "<TR>\n" 
                   + "   <TD><B>SS Profile:</B></TD>\n" 
                   + "   <TD>" + rs.getString("ss_profile_name") + "</TD>\n" 
                   + "   <TD><B>ID: </B> " + rs.getString("ss_profile_id") + ", <B>Status: </B> " + FMIUtil.translateProfileStatus(rs.getString("ss_profile_status")) + "</TD>\n" 
                   + "</TR>\n" 
                   + "<TR>\n" 
                   + "   <TD><B>Loco A. Info:</B></TD>\n" 
                   + "   <TD>" + (rs.getString("ss_profile_id").equals(rs.getString("las_profile_id")) ?
                           "<FONT color=green><B>MATCHING PROFILES</B></TD>\n" : 
                           new StringBuilder().append("<FONT color=RED><B>PROFILE MISMATCH.</B> Loco Assign Profile: ").append(rs.getString("las_profile_name")).append(" (Status: ").append(FMIUtil.translateProfileStatus(rs.getString("las_profile_status"))).append(", ID: ").append(rs.getString("las_profile_id")).append(")</TD>\n").toString()) 
                   + "   <TD><B>Status: </B> " + ServiceSheetUtil.translateSSStatus(rs.getString("assignment_status")) + (!rs.getString("assignment_status").equals(rs.getString("service_sheet_status_code")) ? "<FONT color=RED><B> (STATUS MISMATCH)</B></FONT>" : "") 
                   + "</TD>\n" 
                   + "</TR>\n");           
           buf.append("<TR></TR>");
         } while (rs.next());
         
         buf.append("</TABLE></BODY></HTML>\n");
       } else {
           buf.append("<BR><H2>No more FMI data.</h2>");
       }
       
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: \"" + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: FMIInfoHelperIF, Method: fetchFMIInfo", fmiDetailsQuery, buf.toString());
       
       editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 770, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential