
/* Change notes:

  v 0.17
  - Added
  v 0.19
  - Implemented "Find" (CTRL+F), "Find Next" (F3) and "Find Previous" (SHIFT+F3) functionality to easily search service sheets.
  - Added the status to the locomotive listing.
  - Added a friendly "pulling records" message to note that something is happening. The progress bar messes up all the layouts. Because Swing.
*/

package servicesheet;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.net.URI;
import java.sql.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
import javax.swing.text.Document;
import servicesheet.DefectInfoHelperIF;
import servicesheet.FMIInfoHelperIF;
import servicesheet.MaterialInfoHelperIF;
import servicesheet.OpenTaskInfoHelperIF;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.locomotive.LocomotiveData;
import util.servicesheet.ServiceSheetUtil;
import util.workorder.WorkorderData;
import util.workorder.WorkorderUtil;
import workorder.*;

public class ServiceSheetHistoryIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;    
    private boolean done = false;    
    private SimpleDateFormat dateFormatter;    
    private StringBuffer buf;
    private ArrayList<LocomotiveData> locomotives;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private DefaultListModel model;
    private int selIndexLoco;
    private LocomotiveData selectedLoco;
    private String findText;
    
    /**
     * Creates new form WorkorderIF
     */
    public ServiceSheetHistoryIF() {
        initComponents();
    }

    public ServiceSheetHistoryIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){

        super(title, resizable, closable, maximizable, iconifiable);        
        model = new DefaultListModel();
        model.addElement("Click Go Button");
        initComponents();
        
        this.getRootPane().setDefaultButton(btnFetchLocoList);

        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
        
        this.getRootPane().setDefaultButton(btnFetchLocoList);
        
        listLocos.setModel(model);
        //listWO = new JList(model);
        listLocos.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        listLocos.setLayoutOrientation(JList.VERTICAL);                                    
        locomotives = new ArrayList<>();
        selectedLoco = new LocomotiveData();
        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm z");
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { ServiceSheetHistoryIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );           
          
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/    
    
    }
    
    private void cleanClose() {
      dispose();
    }       
    
    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        scrollWOList = new javax.swing.JScrollPane();
        listLocos = new javax.swing.JList();
        jPanel3 = new javax.swing.JPanel();
        btnFetchLocoList = new javax.swing.JButton();
        chkBoxAllData = new javax.swing.JCheckBox();
        txtRoadNumber = new javax.swing.JTextField();
        txtLocomotiveId = new javax.swing.JTextField();
        txtAARRoad = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        listLocos.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        listLocos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listLocos.setLayoutOrientation(javax.swing.JList.VERTICAL_WRAP);
        listLocos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listLocosMouseClicked(evt);
            }
        });
        scrollWOList.setViewportView(listLocos);

        btnFetchLocoList.setText("Go");
        btnFetchLocoList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFetchLocoListActionPerformed(evt);
            }
        });

        chkBoxAllData.setText("All");
        chkBoxAllData.setToolTipText("Check for wildcard comparison");

        txtRoadNumber.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtRoadNumber.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtRoadNumber.setText("RN");
        txtRoadNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRoadNumberFocusGained(evt);
            }
        });

        txtLocomotiveId.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtLocomotiveId.setText("Locomotive ID");
        txtLocomotiveId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLocomotiveIdFocusGained(evt);
            }
        });

        txtAARRoad.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtAARRoad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAARRoad.setText("AAR Road");
        txtAARRoad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAARRoadFocusGained(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkBoxAllData, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(2, 2, 2))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(txtAARRoad, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFetchLocoList))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFetchLocoList)
                    .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAARRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkBoxAllData)
                    .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollWOList)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(10, 10, 10))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(scrollWOList, javax.swing.GroupLayout.DEFAULT_SIZE, 409, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 485, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFetchLocoListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFetchLocoListActionPerformed
       if(txtRoadNumber.getText().isEmpty() && txtAARRoad.getText().isEmpty() && txtLocomotiveId.getText().isEmpty()){
          editorResults.setText("Please fill at least one field.");  
       } else if(txtRoadNumber.getText().equals("RN") && txtAARRoad.getText().equals("AAR Road") && txtLocomotiveId.getText().equals("Locomotive ID")){
          editorResults.setText("Please fill at least one field.");  
       } else {
          editorResults.setText("");
          fetchLocoList();        
       }
    }//GEN-LAST:event_btnFetchLocoListActionPerformed

    private void txtAARRoadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAARRoadFocusGained
        txtAARRoad.selectAll();
    }//GEN-LAST:event_txtAARRoadFocusGained

    private void txtRoadNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRoadNumberFocusGained
        txtRoadNumber.selectAll();
    }//GEN-LAST:event_txtRoadNumberFocusGained

    private void listLocosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listLocosMouseClicked
     if (evt.getClickCount() == 2) {
       selIndexLoco = listLocos.locationToIndex(evt.getPoint());
       protectFields();
       fetchServiceSheetDetails(((LocomotiveData)locomotives.get(selIndexLoco)).getId());
     }
    }//GEN-LAST:event_listLocosMouseClicked

    private void txtLocomotiveIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLocomotiveIdFocusGained
        txtLocomotiveId.selectAll();
    }//GEN-LAST:event_txtLocomotiveIdFocusGained

    private void fetchLocoList(){
        new Thread(new Runnable() {
          public void run() {        
            fetchLocoListing();
            while (!done)
              try {
                Thread.sleep(100L);
              }
              catch (InterruptedException ie) {
              }
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                //progressBar.setValue((int)(Math.random() * 100.0D));
              }
            });
          }
        }).start();        
    }   

   private void fetchServiceSheetDetails(final String locomotiveId)
   {
     new Thread(new Runnable() {
       public void run() {
         fetchServiceSheetHistory(locomotiveId);
         while (!ServiceSheetHistoryIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }    
    
   private void protectFields()
   {
     btnFetchLocoList.setEnabled(false);
     listLocos.setEnabled(false);
     txtLocomotiveId.setEditable(false);
     txtAARRoad.setEditable(false);
     txtRoadNumber.setEditable(false);
     chkBoxAllData.setEnabled(false);
     comboEnvironment.setEnabled(false);
     
   }
   
   private void releaseFields() {
     btnFetchLocoList.setEnabled(true);
     listLocos.setEnabled(true);
     txtLocomotiveId.setEditable(true);
     txtAARRoad.setEditable(true);
     txtRoadNumber.setEditable(true);
     chkBoxAllData.setEnabled(true);
     comboEnvironment.setEnabled(true);
     
   }
    
   private void fetchServiceSheetHistory(String locomotiveId) {
     String serviceSheetQuery = "";
     
     try
     {
       conn = OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }                   
       
       buf = new StringBuffer();
       editorResults.setText("<HTML><H2>Pulling Service Sheet History...</H2></HTML>");
       protectFields();
       
       serviceSheetQuery = " select ss.service_sheet_id, to_char(ss.last_update_date, 'DD-Mon-yyyy HH24:MI:SS') as last_update_date,\n" +
            " NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = ss.last_updated_by), '-') as last_updated_by, ss.service_type_code, ss.service_sheet_comments,\n" +
            " NVL((select workorder_number from gets_lms_service_workorder where service_workorder_id = ss.service_workorder_id), '-') as workorder_number,\n" +
            " ss.service_sheet_status_code, NVL(ss.fmi_flag, 'N') as fmi_flag, NVL(ss.due_flag, 'N') as due_flag, \n" +
            " NVL((select service_item from ESV_WRKSCPE.ESV_SERVICE_ITEM where service_item_id = ss.service_item_id), '-') as service_item,\n" +
            " NVL((select program_name from gets_lms_service_program where service_program_id = ss.service_program_id), '-') as service_program\n" +
            " from gets_lms_service_sheet  ss\n" +
            " where ss.locomotive_id = " + locomotiveId + " \n" +
            (chkBoxAllData.isSelected() ? "" : " and ss.service_sheet_status_code <> 900 \n" )+
            " order by ss.last_update_date desc, ss.service_sheet_status_code asc";

       prepStm = conn.prepareStatement(serviceSheetQuery);
       rs = prepStm.executeQuery();
       int row = 0;
       if (rs.next()) {
           
       buf.append("<TABLE width=100%>"
                 + "<TR><TD ALIGN=CENTER bgcolor=\"#92CDDC\" colspan=11><B>SERVICE SHEET HISTORY</B></TD></TR>"
                 + "<TR>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Service Sheet Comments</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Code</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Status</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Service Item</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Service Program</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Due?</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>FMI?</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Workorder Number</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Last Update Date</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Last Updated By</B</TD>"               
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>ID</B</TD>"               
                 + "</TR>");
       
           do{
               buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("service_sheet_comments") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("service_type_code") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + ServiceSheetUtil.translateSSStatus(rs.getString("service_sheet_status_code")) + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("service_item") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("service_program") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("due_flag") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("fmi_flag") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("workorder_number") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("last_update_date") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("last_updated_by") + "</FONT></TD>\n" 
                   + "   <TD align=CENTER><FONT size=-1>" + rs.getString("service_sheet_id") + "</FONT></FONT></TD>\n"                        
                   + "</TR>");
               row++;
           }while(rs.next());         
           buf.append("</TABLE></HTML>");
       }
       else {
         editorResults.setText("No service sheets found for this unit.");
         releaseFields();              
         return;
       }

       prepStm.close();
       rs.close();
       releaseFields();
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
       buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
       buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");
       buf.append("chkBoxWildCard checked?: " + chkBoxAllData.isSelected() + "\"\n");
       buf.append("Selected Loco: " + selectedLoco.toString() + "\"\n");
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: ServiceSheetHistoryIF, Method: fetchServiceSheet History", serviceSheetQuery, buf.toString());
       
       editorResults.setText("<HTML><H3>An error occurred, please check the logs.</H3></HTML>");
       releaseFields();
     }
   }
   
    private void fetchLocoListing(){
        String locoListQuery = "";
        try {
            done = false;            
            protectFields();
            model.clear();
            DefaultListModel tempModel = new DefaultListModel(); //Bug with refresh and concurrency, needed to show the listing            
            buf = new StringBuffer();
            locomotives.clear();            
            
            //Fetch the wo list Information first
            conn = OracleConnectionManager.getConnection(getComboConnection());
            
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            locoListQuery = "select la.road_number, la.aar_road, la.locomotive_id, la.locomotive_status_code from gets_lms_locomotive_all la " +
                "WHERE 1 = 1 " +
                (txtAARRoad.getText().trim().toLowerCase().isEmpty() || txtAARRoad.getText().trim().toLowerCase().equals("aar road") ? 
                   "" : " and lower(la.aar_road) like '" + txtAARRoad.getText().trim().toLowerCase() + "'") + 
                (txtRoadNumber.getText().trim().toLowerCase().isEmpty() || txtRoadNumber.getText().trim().toLowerCase().equals("rn") ? 
                   "" : " and lower(la.road_Number) like '" + txtRoadNumber.getText().trim().toLowerCase() + "'") + 
                (txtLocomotiveId.getText().trim().toLowerCase().isEmpty() || txtLocomotiveId.getText().trim().toLowerCase().equals("locomotive id") ? 
                   "" : " and lower(la.locomotive_id) = '" + txtLocomotiveId.getText().trim().toLowerCase() +  "'") + 
                    " order by la.aar_road asc, la.road_number asc"; 
                        
            prepStm = conn.prepareStatement(locoListQuery);
            rs = prepStm.executeQuery();
                                    
            if(rs.next()){
                do {
                    LocomotiveData l = new LocomotiveData(rs.getString("locomotive_id"), rs.getString("aar_road"), rs.getString("road_number"), rs.getString("locomotive_status_code"));
                    locomotives.add(l);
                    tempModel.addElement(l);
                } while(rs.next());
            } else  {                                
                tempModel.addElement(new LocomotiveData("-1","", "", ""));
                listLocos.setModel(tempModel);              
            }
                                    
            prepStm.close();
            rs.close();
            listLocos.setModel(tempModel);            
            releaseFields();
            done = true;
            
        }catch(Exception e){
             //------- Logging begins ----------------
             buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
             buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
             buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");
             buf.append("chkBoxAllData checked?: " + chkBoxAllData.isSelected() + "\"\n");
             buf.append("Selected Loco: " + selectedLoco.toString() + "\"\n");
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Exception info:" + e.getMessage());
             JErrorLog.createErrorLog("Class: WorkorderIF, Method: fetchWOListing",
                 locoListQuery, buf.toString());
             //------- Logging ends ----------------             
             editorResults.setText("<HTML><H3>An error occurred, please check the logs.</H3></HTML>");
             releaseFields();
        }           
    }
        
    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            default:
                return OracleConnectionManager.PROD;
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFetchLocoList;
    private javax.swing.JCheckBox chkBoxAllData;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listLocos;
    private javax.swing.JScrollPane scrollWOList;
    private javax.swing.JTextField txtAARRoad;
    private javax.swing.JTextField txtLocomotiveId;
    private javax.swing.JTextField txtRoadNumber;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential