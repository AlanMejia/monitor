/*
  v 0.13
  - Recreated using a Netbeans form
  - Added the "Pulling records..." message to inform the user that something is happening.
  - The complete details, although useful, are cumbersome when you're just looking for materials at a glance; hence added a 
    "Material Summary" listing in the beginning very similar to the one eServices has;
    the detailed descriptions are still present after this summary.
  v 0.14
  - Added NVLs to the horrible "nulls" that come up when a material was picked through Oracle. Tried to make it smarter, 
    it will now show the material_usage quantity in the "picked" quantity.
  - Changed "Status" in the summary for "Shp Cart Status".
  v 0.15
  - Ordered the summary by picked part alphabetically in ascending order.
  - Added Service Sheet ID and Fail Reason to the summary.
  v 0.16
  - Added a filter that removes the duplicates when a part is Requested in the material summary.
  - null Defect comments will now appear as "-" across the board.
  v 0.20
  - Separated the "Returned" and "Reversed" fields. "Returned" is from the SC Details table, "Reversed" comes from the material_usage table.
  - Added alternating colors to the material summary for better readability. The red background color is still preserved for those materials missing Fail Reason and SS_ID.
  - Added the "Shopping_cart_id" field to the material summary for completeness.
  v 0.21
  - Validated the shopping cart details id to defend itself against the null values.
  - Changed the color of the Oracle parts to bright orange for better reading.
  v 0.22
  - Added a check to highlight in red when a part has 0 qty requested.
  - Implemented find functionality.
*/

package servicesheet;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.workorder.WorkorderData;

public class MaterialInfoHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private WorkorderData wo;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;    
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;      
   
    public MaterialInfoHelperIF(final JDesktopPane desktop, SupportCenter parent, WorkorderData wo, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.wo = wo;
     this.environment = environment;
     
     initComponents();
     
     editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");     
     loadInformation();
     
     addInternalFrameListener(new InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { MaterialInfoHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
     
   }
   
   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }         
    
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchMatInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchMatInfo()
   {
     String matQuery = "";
     String pendMatQuery = "";
     String orphanMatQuery = "";
     String matSummary = "";
     try
     {
       conn = OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       buf = new StringBuffer();
       
       matSummary = "select distinct * from (select * from (select spd.shopping_cart_detail_id, "
               + " NVL(spd.shopping_cart_status, '-') as shopping_cart_status, \n" +
        "               spd.requested_quantity, spd.picked_quantity, \n" +
        "               spd.deleted_quantity, spd.returned_quantity, \n" +
        "                NVL(spd.item_number_picked, 'Oracle Pick') as item_number_picked, \n" +
        "                NVL(mat.quantity, 0) as quantity, mat.service_sheet_id, \n" +
        "               (select distinct segment1 from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = mat.inventory_item_id and rownum = 1) as picked_material, \n" +
        "               (select distinct description from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = mat.inventory_item_id and rownum = 1) as picked_material_description, \n" +
        "                NVL(mat.reverse_quantity, 0) as reverse_quantity, mat.fail_reason \n" +
        "                from gets_lms_material_usage mat, gets_pc_shopping_cart_details spd\n" +
        "               WHERE\n" +
        "                 mat.shopping_cart_detail_id = spd.shopping_cart_detail_id(+)\n" +
        "                AND mat.service_workorder_id = " + wo.getId() + " \n" +
        "             --   order by picked_material asc \n" +
        "union\n" +
        "   select det.shopping_cart_detail_id, det.SHOPPING_CART_STATUS, det.REQUESTED_QUANTITY, det.picked_quantity, det.deleted_quantity, det.returned_quantity,\n" +
        "   det.item_number_picked, 0 as quantity, 0 as service_sheet_id, '-' as picked_material, \n" +
        "   (select distinct description from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = det.item_id_picked and rownum = 1) as picked_material_description, \n" +
        "   0 as reverse_quantity, '-' as fail_reason \n" +
        "   from gets_pc_shopping_cart_details det where \n" +
        "     det.shopping_cart_header_id = (select shopping_cart_header_id from gets_pc_shopping_cart_header where service_workorder_id = " + wo.getId() + ")\n" +
        "    and (shopping_cart_status = 'Cancelled' or shopping_cart_status = 'Pending Request')      )\n" +
        "order by shopping_cart_status ) order by picked_material asc ";              
       
       prepStm = conn.prepareStatement(matSummary);
       rs = prepStm.executeQuery();       
       
       buf.append("<HTML><BODY>");
       
       if (rs.next()) {
         int row = 0;
         buf.append("<HR><H2>Material Summary</H2><HR><BR>");
         buf.append("<TABLE border = 1 width=100%>\n");
         buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Requested Part</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Picked Part</B></TD>"                   
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shopping Cart ID</B></TD>"                 
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Picked Part Description</B></TD>"                                    
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Req</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Pick</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Del</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Ret</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Rev</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shp Cart Status</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>SS?</B></TD>"                 
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>FR?</B></TD>"                                  
                   + "</TR>");         
         do
         {                   
           buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                   + "   <TD ALIGN=\"CENTER\" " + (rs.getString("item_number_picked").equals("Oracle Pick") ? 
                     " bgcolor = #FF9900>" : ">" ) + rs.getString("item_number_picked") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_material") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("shopping_cart_detail_id") ? "-" : rs.getString("shopping_cart_detail_id") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_material_description") + "</TD>"                    
                   + "   <TD ALIGN=\"CENTER\" " + (rs.getString("requested_quantity").equals("0") ? " BGCOLOR = RED " : "") + ">" + (null == rs.getString("requested_quantity") ? "-" : rs.getString("requested_quantity") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("picked_quantity") ? rs.getString("quantity") : rs.getString("picked_quantity") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("deleted_quantity") ? "-" : rs.getString("deleted_quantity") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("returned_quantity") ? "0" : rs.getString("returned_quantity") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("reverse_quantity") ? "0" : rs.getString("reverse_quantity") ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_status") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" " + (null == rs.getString("service_sheet_id") ? " bgcolor = RED>N" : ">Y" ) + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" " + (null == rs.getString("fail_reason") ? " bgcolor = RED>N" : ">Y" ) + "</TD>"                    
                   + "</TR>");
           row++;
         } while (rs.next());
         
         buf.append("</TABLE><BR><HR>");
       }
       
       prepStm.close();
       rs.close();
       
       
       pendMatQuery = "SELECT spd.shopping_cart_detail_id, spd.shopping_cart_status, \n"
               + "spd.parts_catalog_item_id, spd.item_id_picked, spd.requested_quantity, spd.picked_quantity,\n"
               + "spd.deleted_quantity, spd.returned_quantity, spd.ux_item_flag,\n"
               + "spd.ux_quantity_due, spd.dmr_quantity_due, spd.shortage_flag, \n"
               + "spd.parts_catalog_item_number, spd.item_number_picked,\n"
               + "NVL((select defect_comments from gets_lms_defect_sheets where defect_id = spd.defect_id ), '-') as defect_comments, \n"
               + "spd.defect_id, (select distinct description from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = spd.parts_catalog_item_id and rownum = 1) as req_material_description \n"
               + "FROM gets_pc_shopping_Cart_header head, gets_pc_shopping_Cart_details spd\nWHERE head.shopping_cart_header_id = spd.shopping_cart_header_id \n "
               + "and head.service_workorder_id = " + wo.getId() + "\n" 
               + "and spd.shopping_cart_status = 'Pending Request' "
               + "\n" + "order by spd.parts_catalog_item_number asc";
       
       prepStm = conn.prepareStatement(pendMatQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<H2>The following Materials are in PENDING REQUEST status</H2><HR><BR>");
         buf.append("<TABLE border = 1 width=100%>\n");
         do
         {
           buf.append("<TR>"
                   + "   <TD ALIGN=\"LEFT\" bgcolor=\"#92CDDC\" colspan = 11><B>" + rs.getString("parts_catalog_item_number") + " (" + rs.getString("req_material_description") + ")</B></TD>" 
                   + "</TR>");           
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Requested Part</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Picked Part</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart. ID</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Req</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Pick</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Del</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Ret</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>UX/Qty Due</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Status</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Defect Comments</B></TD>"
                   + "</TR>");
           
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Info</B></TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("parts_catalog_item_number") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("item_number_picked") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_detail_id") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("requested_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("deleted_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("returned_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("ux_item_flag") + " / " + rs.getString("ux_quantity_due") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_status") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("defect_comments") + " ( " + rs.getString("defect_id") + " )</TD>" 
                   + "</TR>");           
           buf.append("<TR></TR>");
         } while (rs.next());
         
         buf.append("</TABLE><BR><HR>");
       }
       
       prepStm.close();
       rs.close();
        
       orphanMatQuery = " SELECT spd.shopping_cart_detail_id, spd.shopping_cart_status, "
               + "                spd.parts_catalog_item_id, spd.item_id_picked, spd.requested_quantity, spd.picked_quantity,"
               + "                spd.deleted_quantity, spd.returned_quantity, spd.ux_item_flag,"
               + "                spd.ux_quantity_due, spd.dmr_quantity_due, spd.shortage_flag, "
               + "                spd.parts_catalog_item_number, spd.item_number_picked,"
               + "                NVL((select defect_comments from gets_lms_defect_sheets where defect_id = spd.defect_id ), '-') as defect_comments, "
               + "                spd.defect_id, (select distinct description from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = spd.parts_catalog_item_id and rownum = 1) as req_material_description                    "
               + "                FROM gets_pc_shopping_Cart_header head, gets_pc_shopping_Cart_details spd"
               + "                WHERE head.shopping_cart_header_id = spd.shopping_cart_header_id"
               + "                and head.service_workorder_id = " + wo.getId() 
               + "                and not exists (select * from gets_lms_material_usage where service_workorder_id = " + wo.getId() + " and shopping_cart_detail_id = spd.shopping_cart_detail_id)" 
               + "                and spd.shopping_cart_status <> 'Pending Request' " 
               + "                order by spd.parts_catalog_item_number asc";
       
       prepStm = conn.prepareStatement(orphanMatQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         buf.append("<H2>The following Materials do NOT exist in GETS_LMS_MATERIAL_USAGE. Look for any non-Cancelled materials. </H2><HR><BR>");
         buf.append("<TABLE border = 1 width=100%>");
         
         do
         {
           buf.append("<TR>"
                   + "   <TD ALIGN=\"LEFT\" bgcolor=\"#92CDDC\" colspan = 11><B>" + rs.getString("parts_catalog_item_number") + " (" + rs.getString("req_material_description") + ")</B></TD>" 
                   + "</TR>");           
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Requested Part</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Picked Part</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart. ID</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Req</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Pick</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Del</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Ret</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>UX/Qty Due</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Status</B></TD>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Defect Comments</B></TD>"
                   + "</TR>");
           
           buf.append("<TR>"
                   + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Info</B></TD>"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("parts_catalog_item_number") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("item_number_picked") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_detail_id") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("requested_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("deleted_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("returned_quantity") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("ux_item_flag") + " / " + rs.getString("ux_quantity_due") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" " + (rs.getString("shopping_cart_status").equals("Cancelled") ? "" : "bgcolor=RED") + ">" + rs.getString("shopping_cart_status") + "</TD>" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("defect_comments") + " ( " + rs.getString("defect_id") + " )</TD>" 
                   + "</TR>");
           
           buf.append("<TR></TR>");
         } while (rs.next());
         
         buf.append("</TABLE><BR><HR>");
       }
       
       prepStm.close();
       rs.close();       
       
       matQuery = "select spd.shopping_cart_detail_id, spd.shopping_cart_status, spd.parts_catalog_item_id, \n"
               + "spd.item_id_picked, spd.requested_quantity, spd.picked_quantity, \n"
               + "spd.deleted_quantity, spd.returned_quantity, spd.ux_item_flag, \n"
               + "spd.ux_quantity_due, spd.dmr_quantity_due, spd.shortage_flag, \n"
               + "spd.parts_catalog_item_number, spd.item_number_picked, \n"
               + "NVL((select defect_comments from gets_lms_defect_sheets where defect_id = spd.defect_id ), '-') as defect_comments,\n"
               + "spd.defect_id, mat.service_material_id, mat.service_sheet_id, mat.quantity, \n"
               + "mat.serial_number_issued, mat.serial_number_removed, mat.position_applied,\n"
               + "mat.shopping_cart_detail_id as mat_shopping_cart_detail_id, "
               + "(select distinct segment1 from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = mat.inventory_item_id and rownum = 1) as picked_material, "
               + "(select distinct description from GETS_INTF_MTL_SYS_ITEMS_B where inventory_item_id = mat.inventory_item_id and rownum = 1) as picked_material_description, \n"
               + " mat.fail_reason, mat.reverse_quantity from gets_lms_material_usage mat, gets_pc_shopping_cart_details spd\n "
               + "WHERE\n "
               + "  mat.shopping_cart_detail_id = spd.shopping_cart_detail_id(+)\n"
               + " AND mat.service_workorder_id = " + wo.getId() + "   order by picked_material asc ";
       
       prepStm = conn.prepareStatement(matQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next())
       {
         buf.append("<H2>Material Detail</H2><HR><BR>");   
         buf.append("<TABLE border = 1 width=100%>\n");         
         do {
           buf.append("<TR>\n"
                   + "   <TD ALIGN=\"LEFT\" bgcolor=\"#92CDDC\" colspan = 11><B>" + rs.getString("picked_material") + " (" + rs.getString("picked_material_description") + ")</B></TD>\n" 
                   + "</TR>");
           
           if (null == rs.getString("shopping_cart_detail_id")) {
             buf.append("<TR>\n"
                     + "   <TD ALIGN=\"CENTER\" bgcolor=\"#C0C0C0\" colspan = 8><B>No Shopping Cart Details information available. Probably added material from Oracle.</B></TD>\n"
                     + "</TR>");
           }
           else
           {
             buf.append("<TR>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Requested Part</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Picked Part</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Shop. Cart. ID</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Req</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Pick</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Del</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Ret</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>UX/Qty Due</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Status</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Defect Comments</B></TD>\n"
                     + "</TR>");
             
             buf.append("<TR>\n"
                     + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Info</B></TD>\n"
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("parts_catalog_item_number") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("item_number_picked") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_detail_id") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("requested_quantity") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_quantity") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("deleted_quantity") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("returned_quantity") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("ux_item_flag") + " / " + rs.getString("ux_quantity_due") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("shopping_cart_status") + "</TD>\n" 
                     + "   <TD ALIGN=\"CENTER\" >" + rs.getString("defect_comments") + " ( " + rs.getString("defect_id") + " )</TD>\n" 
                     + "</TR>");
           }           
 
           buf.append("<TR>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Mat. Usage</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Picked Material</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>ID</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Pick Qty</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Rev Qty</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>SS ID</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>SN In</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>SN Out</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Position</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Fail Reason</B></TD>\n"
                   + "</TR>");
           
           buf.append("<TR>\n"
                   + "   <TD ALIGN=\"CENTER\" bgcolor=\"#92D050\"><B>Info</B></TD>\n"
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("picked_material") + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("service_material_id") + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + rs.getString("quantity") + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("reverse_quantity") ? "-" : rs.getString("reverse_quantity")) + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" " + (null == rs.getString("service_sheet_id") ? " bgcolor=\"#FF0000\"><B>NA</B>" : new StringBuilder().append(">").append(rs.getString("service_sheet_id")).toString()) + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("serial_number_issued") ? "-" : rs.getString("serial_number_issued")) + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("serial_number_removed") ? "-" : rs.getString("serial_number_removed")) + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" >" + (null == rs.getString("position_applied") ? "-" : rs.getString("position_applied")) + "</TD>\n" 
                   + "   <TD ALIGN=\"CENTER\" " + (null == rs.getString("fail_reason") ? " bgcolor=\"#FF0000\"> -" : new StringBuilder().append(">").append(rs.getString("fail_reason")).toString()) + "</TD>\n" 
                   + "</TR>");
           
           buf.append("<TR></TR>");
         } while (rs.next());
         
         buf.append("</TABLE></BODY></HTML>\n");
       } else {
         editorResults.setText("OH GODS! SOMETHING IS WRONG WITH THIS MATERIAL PULL!");
         return;
       }
       
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: " + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: MaterialInfoHelperIF, Method: fetchMatInfo", 
             "matSummary: \n" + matSummary + "\n\n" + 
             "pendMatQuery: \n" + pendMatQuery + "\n\n" + 
             "orphanMatQuery: \n" + orphanMatQuery + "\n\n" + 
             "matQuery: \n" + matQuery, buf.toString());       
       editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 751, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential