/*
  v 0.13
  - Recreated using a Netbeans form
  - Added the "Pulling records..." message to inform the user that something is happening.
  v 0.14
  - Corrected the a bug that would treat defects with "N" and null repaired flag as different for sorting purposes
    all unsigned defects should bubble up to the top now.
  - The defect comments will now show with "-" instead of the horrible null.
  v 0.19
  - Formatted the dates to a more comfortable standard (dd-Mon-yyyy HH24:mm:ss)
*/

package servicesheet;

import eservicesmanager.SupportCenter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import util.defect.Defect;
import util.workorder.WorkorderData;

public class DefectInfoHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private WorkorderData wo;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;    
    
    public DefectInfoHelperIF(final JDesktopPane desktop, SupportCenter parent, WorkorderData wo, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.wo = wo;
     this.environment = environment;
     
     initComponents();
     
     editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");
     loadInformation();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { DefectInfoHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchDefectInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchDefectInfo()
   {
     String defQuery = "";
     
     try
     {
       conn = util.OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
  
       buf = new StringBuffer();
       
       defQuery = "select * from (select def.wo_number, def.defect_id, def.failure_mode, def.repair_action, def.fail_reason, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_name = def.defect_opened_by) as opened_by, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_name = def.defect_repaired_by) as repaired_by, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = def.last_updated_by) as last_updated_by_user, \n"
               + "NVL(def.repaired_flag, 'N') as repaired_flag, to_char(def.last_update_date,'DD-Mon-yyyy HH24:MI:SS') as last_update_date, def.last_updated_by, "
               + "to_char(def.creation_date,'DD-Mon-yyyy HH24:MI:SS') as creation_date, \n"
               + "def.created_by, NVL(def.defect_comments, '-') as defect_comments, def.action_comments, def.service_sheet_id, ss.service_sheet_comments \n"
               + "FROM gets_lms_defect_sheets def, gets_lms_service_sheet ss  \nWHERE\n def.service_sheet_id  = ss.service_sheet_id (+)\n"
               + " AND def.service_Workorder_id = " + wo.getId() + " ) "
               + " order by repaired_flag asc ";
       
       prepStm = conn.prepareStatement(defQuery);
       rs = prepStm.executeQuery();
       
       ArrayList<Defect> defects = new ArrayList();
       
       if (rs.next()) {
         do {
           defects.add(new Defect(wo.getId(), 
                   rs.getString("wo_number"), 
                   rs.getString("defect_id"), 
                   rs.getString("failure_mode"), 
                   rs.getString("repair_action"), 
                   rs.getString("fail_reason"), 
                   rs.getString("opened_by"), 
                   rs.getString("repaired_by"), 
                   rs.getString("last_updated_by_user"), 
                   rs.getString("repaired_flag"), 
                   rs.getString("last_update_date"), 
                   rs.getString("creation_date"), 
                   rs.getString("defect_comments"), 
                   rs.getString("action_comments"), 
                   rs.getString("service_sheet_id"), 
                   rs.getString("service_sheet_comments"))); 
         }
         while (rs.next());
       } else {
         buf.append("<HTML><BODY><H2>No defects found for this WO.</H2>\n");
         return;
       }
       
       rs.close();
       prepStm.close();
       
       buf.append("<HTML><BODY><TABLE border = 1 width=100%>\n");
       
       for (Defect d : defects)
       {
         buf.append("<TR> <!--  verde: 309330 -->\n" +
                 (d.isRepaired() ? "<TD align = \"center\" bgcolor = #309330><B> REPAIRED </B> </TD>\n" : "<TD align = \"center\" bgcolor = #FF0000><B> OPEN </B> </TD>\n") 
                 + "<TD align = \"center\" ><B> <FONT color=" + (d.getWoNumber().equals(wo.getNumber()) ? "BLUE" : "RED") + "> " + d.getWoNumber() + "</B></FONT></TD>\n" 
                 + "<TD align = \"center\"><B>Defect ID: </B>" + d.getDefectID() + " </TD>\n" 
                 + "</TR>");         
         buf.append("<TR>"
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Defect Comments: </B></TD>"
                 + "  <TD colspan=\"2\">" + d.getDefectComments() + "</TD>" 
                 + "</TR> " 
                 + "<TR>" 
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Action Comments: </B></TD> " 
                 + "<TD colspan=\"2\">" + d.getActionComments() + "</TD>" 
                 + "</TR>" 
                 + "<TR>" 
                 + "<TD align = \"center\" bgcolor=\"#CEE7FF\"><B>Date info: </TD>" 
                 + "<TD align = \"center\"><B>Opened on </B> " + d.getCreationDate() + " <B>by</B> " + d.getOpenedBy() 
                 + "<TD align = \"center\"><B>Repaired on </B> " + d.getLastUpdateDate() + " <B>by</B> " + d.getLastUpdatedByUser() + "</TD>" 
                 + "</TR>" + "<TR>\n" + "<TD align = \"center\"><B>Fail Reason: </B> " + d.getFailReason() + "</TD>" 
                 + "<TD align = \"center\"><B>Repair Action: </B> " + d.getRepairAction() + "</TD>" 
                 + "<TD align = \"center\"></TD>\n" + "</TR>" 
                 + "<TR>" 
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Service Sheet:</B></TD>" 
                 + "<TD colspan=\"2\"><B>ID: </B>" + d.getServiceSheetID() + ". <B>Comments: </B> " + d.getServiceSheetComments() + "</TD>" 
                 + "</TR>");
         
         buf.append("<TR></TR>");
         
         
       }       
       buf.append("</TABLE>\n");
      
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: " + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: DefectInfoHelper, Method: fetchDefInfo", defQuery, buf.toString());       
       editorResults.setText("<HTML><H3>An Error occurred, please check the logs.</H3></HTML>");
     }
   }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential