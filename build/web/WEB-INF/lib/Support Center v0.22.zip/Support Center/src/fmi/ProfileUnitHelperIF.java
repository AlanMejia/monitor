 /*
  v 0.16
  - Added.
  v 0.17
  - Sorted the locomotive listing by road number.
  - Added code to differentiate rows for better readability.
*/

package fmi;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import servicesheet.*;
import util.fmi.*;
import util.servicesheet.ServiceSheetUtil;
import util.workorder.WorkorderData;


public class ProfileUnitHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private ProfileData profile;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;
   private JDesktopPane desktop;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;      
   
    public ProfileUnitHelperIF(final JDesktopPane desktop, SupportCenter parent, ProfileData profile, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {

     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.profile = profile;
     this.environment = environment;
     this.desktop = desktop;
     
     initComponents();
     
     editorResults.setText("<HTML><H3>Pulling records...</H3></HTML>");      
     loadInformation();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { ProfileUnitHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
     
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
        
    
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchFMIAssignInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchFMIAssignInfo()
   {
     String fmiAssignmentDetailsQuery = "";
     
     try
     {
       conn = util.OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       buf = new StringBuffer();
       fmiAssignmentDetailsQuery = "select * from (select (select aar_road || '-' || road_number from gets_lms_locomotive_all where locomotive_id = lass.locomotive_id) as road_number,\n" +
            " lass.assignment_status, NVL(to_char(lass.completion_date,'DD-Mon-yyyy HH24:MI:SS'),'-') as completion_date, "
           + "NVL(to_char(lass.creation_date,'DD-Mon-yyyy HH24:MI:SS'),'-') as creation_date, "
           + "NVL(to_char(lass.last_update_date,'DD-Mon-yyyy HH24:MI:SS'),'-') as last_update_date, " +
            " NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = lass.last_updated_by), '-') as last_updated_by,\n" +
            " NVL((select workorder_number from gets_lms_service_workorder where service_workorder_id = lass.service_workorder_id), '-') as assigned_workorder,\n" +
            " NVL((select profile_id from gets_lms_service_sheet where fmi_id = lass.fmi_id and locomotive_id = lass.locomotive_id), 0) as ss_profile,\n" +
            " NVL((select service_sheet_id from gets_lms_service_sheet where fmi_id = lass.fmi_id and locomotive_id = lass.locomotive_id), 0) as ss_id\n" +
            " from gets_fmi_loco_assign lass where\n" +
            " profile_id = " + profile.getProfileId() +
            " ) order by road_number asc";
 
       prepStm = conn.prepareStatement(fmiAssignmentDetailsQuery);
       rs = prepStm.executeQuery();
       int row = 0;
       
       buf.append("<HTML><BODY>");
       if (rs.next()) {
         buf.append("<TABLE width=100%>"
                 + "<TR><TD ALIGN=CENTER bgcolor=\"#92CDDC\" colspan=9><B>LOCOMOTIVE ASSIGNMENTS</B></TD></TR>"
                 + "<TR>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Road Number</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Status</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Completion Date</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Creation Date</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Last Update Date</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Last Updated By</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Assigned Workorder</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>SS Profile</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>SS ID</B</TD>"
                 + "</TR>");
         do {
           buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")                  
                   + "   <TD align=CENTER>" + rs.getString("road_number") + "</TD>\n" 
                   + "   <TD align=CENTER>" + ServiceSheetUtil.translateSSStatus(rs.getString("assignment_status")) + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("completion_date") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("creation_date") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("last_update_date") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("last_updated_by") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("assigned_workorder") + "</TD>\n" 
                   + "   <TD align=CENTER>" + (profile.getProfileId().equals(rs.getString("ss_profile")) ? rs.getString("ss_profile") : "<FONT COLOR=RED><B>" + rs.getString("ss_profile") + "</B></FONT>") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("ss_id") + "</TD>\n" 
                   + "</TR>\n");
           row++;
         }
         while (rs.next());
         
         buf.append("</TABLE><BR>");
       }
        
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: \"" + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: ProfileUnitHelperIF, Method: fetchFMIAssignInfo", fmiAssignmentDetailsQuery, buf.toString());
       
       editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 770, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential