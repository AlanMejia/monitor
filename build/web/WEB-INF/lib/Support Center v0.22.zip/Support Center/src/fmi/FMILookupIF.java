/*
  v 0.16
  - Added
  v 0.19
  - Added alternating colors to approvals in the profile approval listing, for easier reading.
  v 0.21
  - Added find functionality.
*/

package fmi;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.fmi.*;
import util.workorder.WorkorderData;
import workorder.WorkorderIF;

public class FMILookupIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;    
    private boolean done = false;    
    private SimpleDateFormat dateFormatter;    
    private DefaultListModel modelFMIs;
    private DefaultListModel modelProfiles;
    private ArrayList<FMIData> fmis;
    private ArrayList<ProfileData> profiles;
    private FMIData selectedFMI;
    private ProfileData selectedProfile;
    private StringBuffer buf;    
    private int selIndexFMI;
    private int selIndexProfile;
    private SupportCenter parent;    
    private JDesktopPane desktop;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;    
    
    
    public FMILookupIF(final JDesktopPane desktop, SupportCenter parent, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){       
        
        super(title, resizable, closable, maximizable, iconifiable);        
        this.parent = parent;        
        this.desktop = desktop;
        initComponents();
        
        this.getRootPane().setDefaultButton(btnSearch);
        
        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm z");

        modelFMIs = new DefaultListModel();
        modelFMIs.addElement("Type the FMI number and click Search.");              
        listFMIs.setModel(modelFMIs);        

        
        modelProfiles = new DefaultListModel();
        listProfiles.setModel(modelProfiles);  
        listProfiles.setFixedCellWidth(363);
        
        fmis = new ArrayList<>();
        profiles = new ArrayList<>();
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { FMILookupIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );               
    
      progressBar.setVisible(false);
      
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/      
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
     
    }

   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
    
   private void cleanClose() { 
       dispose(); 
   }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtFMINumber = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        scrollFMIs = new javax.swing.JScrollPane();
        listFMIs = new javax.swing.JList();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listProfiles = new javax.swing.JList();
        txtFMIId = new javax.swing.JTextField();
        comboEnvironment = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        btnAssignedUnits = new javax.swing.JButton();
        btnAssignedTasks = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("FMI Number:");

        txtFMINumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFMINumberFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        jLabel4.setText("FMI Results:");

        listFMIs.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listFMIs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listFMIsMouseClicked(evt);
            }
        });
        scrollFMIs.setViewportView(listFMIs);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollFMIs, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollFMIs, javax.swing.GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE))
        );

        jLabel5.setText("Profile Results:");

        listProfiles.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listProfiles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listProfilesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(listProfiles);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtFMIId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFMIIdFocusGained(evt);
            }
        });

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        jLabel2.setText("FMI Id:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtFMINumber)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtFMIId, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(12, 12, 12))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtFMINumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFMIId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        btnAssignedUnits.setText("Assigned Units");
        btnAssignedUnits.setEnabled(false);
        btnAssignedUnits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignedUnitsActionPerformed(evt);
            }
        });

        btnAssignedTasks.setText("Assigned Tasks");
        btnAssignedTasks.setEnabled(false);
        btnAssignedTasks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignedTasksActionPerformed(evt);
            }
        });

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(btnAssignedUnits, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAssignedTasks, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 190, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnAssignedUnits)
                        .addComponent(btnAssignedTasks))
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        if(txtFMINumber.getText().trim().isEmpty() && txtFMIId.getText().trim().isEmpty()){
            editorResults.setText("<HTML><H3>Please fill at least one field.</H3></HTML>");
        }  
        
        if(!txtFMIId.getText().isEmpty()){
        //Validate integer input
            try {
                int i = Integer.parseInt(txtFMIId.getText().trim());
            } catch(Exception e){
                editorResults.setText("<HTML><H3>FMI ID should be a number.</H3></HTML>");
                return;
            }

        }
        
        loadFMIList();        
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtFMINumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFMINumberFocusGained
        txtFMINumber.selectAll();
    }//GEN-LAST:event_txtFMINumberFocusGained

    private void listFMIsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listFMIsMouseClicked
  if (evt.getClickCount() == 2) {
       selIndexFMI = listFMIs.locationToIndex(evt.getPoint());
       selectedFMI = (FMIData)fmis.get(selIndexFMI);
       protectFields();
       btnAssignedUnits.setEnabled(false);
       btnAssignedTasks.setEnabled(false);
       fetchFMIProfiles(((FMIData)fmis.get(selIndexFMI)).getId());
     }
    }//GEN-LAST:event_listFMIsMouseClicked

    private void listProfilesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listProfilesMouseClicked
  if (evt.getClickCount() == 2) {
       selIndexProfile = listProfiles.locationToIndex(evt.getPoint());
       selectedProfile = (ProfileData)profiles.get(selIndexProfile);
       protectFields();
       btnAssignedUnits.setEnabled(false);
       btnAssignedTasks.setEnabled(false);
       fetchFMIProfileDetails();
     }
    }//GEN-LAST:event_listProfilesMouseClicked

    private void txtFMIIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFMIIdFocusGained
        txtFMIId.selectAll();
    }//GEN-LAST:event_txtFMIIdFocusGained

    private void btnAssignedUnitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignedUnitsActionPerformed
        new ProfileUnitHelperIF(desktop, parent, selectedProfile, getComboConnection(), "Unit Assignments for profile \"" + selectedProfile.getProfileName() + "\"", 
        true, true, true, true);
    }//GEN-LAST:event_btnAssignedUnitsActionPerformed

    private void btnAssignedTasksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignedTasksActionPerformed
        new ProfileTaskHelperIF(desktop, parent, selectedProfile, getComboConnection(), "Task Assignments for profile \"" + selectedProfile.getProfileName() + "\"", 
        true, true, true, true);
    }//GEN-LAST:event_btnAssignedTasksActionPerformed

   private void fetchFMIProfileDetails()
   {
     new Thread(new Runnable() {
       public void run() {
         listAllDetails();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }      
    
   private void fetchFMIProfiles(final String fmiId)
   {
     new Thread(new Runnable() {
       public void run() {
         fetchFMIProfileList(fmiId);
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }    

    private void loadFMIList(){
        new Thread(new Runnable() {
          public void run() {        
            fetchFMIList();
            while (!done)
              try {
                Thread.sleep(100L);
              }
              catch (InterruptedException ie) {
              }
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                //progressBar.setValue((int)(Math.random() * 100.0D));
              }
            });
          }
        }).start();        
    }      
   
    private void fetchFMIProfileList(String fmiId){
        String profileQuery = "";  
        String profileApprovalsQuery = "";
        try{
            
            //1. Display the details of the selected FMI
            buf = new StringBuffer();
            displayFMIInfo();

            done = false;            
            protectFields();
            modelProfiles.clear();
            DefaultListModel tempProfileModel = new DefaultListModel(); //Bug with refresh and concurrency, needed to show the listing            
            profiles.clear();
            selectedFMI.clearProfiles();
            
            //Disable the buttons
            btnAssignedUnits.setEnabled(false);
            btnAssignedTasks.setEnabled(false);
            
            //Fetch the fmi list Information first
            conn = OracleConnectionManager.getConnection(getComboConnection());
            
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }                        
            
            profileQuery = "select pro.profile_id, pro.profile_name, pro.description, " +
                " NVL(to_char(pro.creation_date,'DD-Mon-yyyy HH24:MI:SS'), '-') as creation_date," +
                " NVL(to_char(pro.last_update_date,'DD-Mon-yyyy HH24:MI:SS'), '-') as last_update_date, \n" +                    
                "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = pro.last_updated_by), '-') as last_updated_by,\n" +
                "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = pro.created_by), '-') as created_by,\n" +
                "pro.software_fmi_flag, pro.program_timing, pro.fmi_hours_unit, pro.no_test_units, pro.no_test_days, pro.profile_approve_status,"
                    + "(select count(*) from gets_fmi_loco_assign where profile_id = pro.profile_id) as hasUnits,"
                    + "(select count(*) from gets_fmi_profile_task where profile_id = pro.profile_id) as hasTasks \n" +
                "from gets_fmi_profile pro\n" +
                "where pro.fmi_id = " + selectedFMI.getId() + 
                " order by pro.profile_name asc ";
                        
            prepStm = conn.prepareStatement(profileQuery);
            rs = prepStm.executeQuery();
                                    
            if(rs.next()){
                do {                      
                    ProfileData p = new ProfileData(rs.getString("profile_id"), 
                        rs.getString("profile_name"), 
                        rs.getString("description"), 
                        rs.getString("creation_date"),                             
                        rs.getString("last_update_date"), 
                        rs.getString("created_by"), 
                        rs.getString("last_updated_by"), 
                        rs.getString("software_fmi_flag"), 
                        rs.getString("program_timing"), 
                        rs.getString("fmi_hours_unit"), 
                        rs.getString("no_test_units"), 
                        rs.getString("no_test_days"), 
                        FMIUtil.translateProfileStatus(rs.getString("profile_approve_status")));  
                    
                    if(rs.getInt("hasUnits") > 0 )
                        p.setAssignedUnits(true);
                    if(rs.getInt("hasTasks") > 0 )
                        p.setAssignedTasks(true);
                    
                    profileApprovalsQuery = "select NVL((select name from gets_lms_customer_orgs_v where service_organization_id = app.service_organization_id), to_char(app.service_organization_id)) as org,\n" +
                            "(select customer_name_phonetic from ar_customers where customer_id = app.customer_id) as customer,\n" +
                            "app.eng_approval_flag, app.field_approval, NVL(to_char(app.start_date,'DD-Mon-yyyy'), '-') as start_date,\n" +
                            "app.customer_approval, app.cust_priority_code, NVL(app.cust_priority_comment, '-') as cust_priority_comment \n" +
                            "from GETS_FMI_APPROVAL app \n" +
                            "where app.profile_id = " + p.getProfileId();
                    PreparedStatement pr = conn.prepareCall(profileApprovalsQuery);
                    ResultSet rs2 = pr.executeQuery();
                    if(rs2.next()){
                      do {
                          p.addApproval(new ProfileApprovalData(rs2.getString("org"),
                          rs2.getString("customer"),
                          rs2.getString("eng_approval_flag"),
                          rs2.getString("field_approval"),
                          rs2.getString("start_date"),
                          rs2.getString("customer_approval"),
                          FMIUtil.translateMandatoryStatus(rs2.getString("cust_priority_code")),
                          rs2.getString("cust_priority_comment")));
                      }while(rs2.next());  
                    } 
                    
                    profiles.add(p);  
                    selectedFMI.addProfile(p);
                    tempProfileModel.addElement(p);

                } while(rs.next());
            } else  {                                
                tempProfileModel.addElement("<HTML><B>Selected FMI has no profiles.</B></HTML>");
                //listWO.setModel(tempModel);              
            }
            
            //Display the general information of the profiles            
            buf.append("<TABLE width=100% >"
                    + "<TR>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\" colspan=3><B>Profile Summary</B></TD>"
                    + "</TR>"
                    + "<TR>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\" WIDTH=60%><B>Profile Name</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\" WIDTH=10%><B>Id</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\" WIDTH=30%><B>Status</B></TD>"
                    + "</TR>");
            if(selectedFMI.getProfiles().isEmpty()){
                buf.append("<TR><TD colspan=3 align=CENTER><B>Selected FMI has no profiles</B></TD></TR>");
            } else {
                int row = 0;
                for(ProfileData d : selectedFMI.getProfiles()){
                    buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")                  
                            + "<TD WIDTH=60%>" + d.getProfileName() + "</TD>"
                            + "<TD WIDTH=10% align=center>" + d.getProfileId() + "</TD>"
                            + "<TD WIDTH=30% align=center><B>" + d.getStatus() + "</B></TD>"
                            + "</TR>");
                    row++;
                }
            }
            buf.append("</TABLE>");
            
            //listProfiles.setBounds(null);
            listProfiles.setModel(tempProfileModel);
            editorResults.setText(buf.toString());
            prepStm.close();
            rs.close();      
            releaseFields();
            
        }catch(Exception e){
             //------- Logging begins ----------------
             buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("FMI Number: " + txtFMINumber.getText() + "\"\n"); 
             buf.append("fmiId: " + fmiId);
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Exception info:" + e.getMessage());
             JErrorLog.createErrorLog("Class: FMILookupIF, Method: fetchFMIProfileList",
                 profileQuery + "\n\n" + profileApprovalsQuery, buf.toString());
             editorResults.setText("<HTML><H3>An error ocurred, please check the logs</H3></HTML>");
             //------- Logging ends ----------------         
             releaseFields();
        }   
    }
   
    private void displayFMIInfo(){
        
        buf.append("<TABLE width=100%>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>FMI Number</B></TD>"
                + "<TD>" + selectedFMI.getNumber() + " (<B>ID: </B>" + selectedFMI.getId() + ")</TD>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>" + selectedFMI.getStatus().toUpperCase() + "</B></TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Title</B></TD>"
                + "<TD colspan=2>" + selectedFMI.getTitle() + "</TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Description</B></TD>"
                + "<TD colspan=2>" + selectedFMI.getDescription() + "</TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Creation Date:</B></TD>"
                + "<TD colspan=2><B>Created by </B>" + selectedFMI.getCreatedBy() + " <B>on </B> " + selectedFMI.getCreationDate() + "</TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Update Date:</B></TD>"
                + "<TD colspan=2><B>Updated by </B>" + selectedFMI.getLastUpdatedBy() + " <B>on </B> " + selectedFMI.getLastUpdateDate() + "</TD>"
                + "</TR>"
                + "</TABLE>");
        buf.append("<TABLE width=100%>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Author Information</B></TD>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>is Lead?</B></TD>"
                + "</TR>");
        for(AuthorData a : selectedFMI.getAuthors()){
                buf.append("<TR>"
                + "<TD ALIGN=CENTER >" + a.getName() + "</TD>"
                + "<TD ALIGN=CENTER ><B>" + a.getLeadAuthor() + "</B></TD>"
                + "</TR>");          
        }
        buf.append("</TABLE><BR>");
    }
    
    private void displayProfileInfo(){
        buf.append("<TABLE width=100%>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>SELECTED PROFILE</B></TD>"
                + "<TD>" + selectedProfile.getProfileName() + "</TD>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>" + selectedProfile.getStatus() + "</B></TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Creation Date:</B></TD>"
                + "<TD colspan=2><B>Created by </B>" + selectedProfile.getCreatedBy() + " <B>on </B> " + selectedProfile.getCreationDate() + "</TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Update Date:</B></TD>"
                + "<TD colspan=2><B>Updated by </B>" + selectedProfile.getLastUpdatedBy() + " <B>on </B> " + selectedProfile.getLastUpdateDate() + "</TD>"
                + "</TR>"
                + "<TR>"
                + "<TD ALIGN=CENTER ><B>ID: </B>" + selectedProfile.getProfileId() + "</TD>"
                + "<TD ALIGN=CENTER ><B>Hours/Unit: </B>" + selectedProfile.getFmiHoursUnit() + "</TD>"
                + "<TD ALIGN=CENTER ><B>Timing: </B>" + selectedProfile.getProgramTiming() + "</TD>"
                + "</TR>"
                + "</TABLE><BR>");
        if(selectedProfile.getApprovals().isEmpty()){
            buf.append("<TABLE width=100%>"
                    + "<TR><TD align=CENTER bgcolor=\"#92CDDC\"><B>No approvals for this profile</B></TD></TR>"
                    + "</TABLE>");
        } else {
            buf.append("<TABLE width=100%>"
                    + "<TR>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Customer</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Service Organization</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Priority</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Author Approval?</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Field Approval?</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Cust. Approval?</B></TD>"   
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Approval Comments</B></TD>"
                    + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Start Date</B></TD>"
                    + "</TR>");                
            
            int row = 0;
            for(ProfileApprovalData p : selectedProfile.getApprovals()){
                buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                        + "<TD align=CENTER>" + p.getCustomer() + "</TD>"
                        + "<TD align=CENTER>" + p.getOrganization() + "</TD>"
                        + "<TD align=CENTER>" + p.getPriority() + "</TD>"
                        + "<TD align=CENTER>" + p.getEngApproval() + "</TD>"
                        + "<TD align=CENTER>" + p.getFieldApproval() + "</TD>"
                        + "<TD align=CENTER>" + p.getCustomerApproval() + "</TD>"
                        + "<TD align=CENTER>" + p.getPriorityComment() + "</TD>"
                        + "<TD align=CENTER>" + p.getStartDate() + "</TD>"
                        + "</TR>");
                row++;
            }
            buf.append("</TABLE><BR>");
            
            //Check if the buttons should be enabled
            if(selectedProfile.hasAssignedTasks()){
                btnAssignedTasks.setEnabled(true);                
            } else {
                btnAssignedTasks.setEnabled(false);               
            }
            
            if(selectedProfile.hasAssignedUnits()){
                btnAssignedUnits.setEnabled(true);                
            } else {
                btnAssignedTasks.setEnabled(false);                
            }
            
        }
    }
    
    private void protectFields(){
        txtFMINumber.setEditable(false);
        txtFMIId.setEditable(false);
        btnSearch.setEnabled(false);
        listFMIs.setEnabled(false);
        listProfiles.setEnabled(false);
        btnAssignedUnits.setEnabled(false);
        btnAssignedTasks.setEnabled(false);
        comboEnvironment.setEnabled(false);
        progressBar.setVisible(true);        
    }
    
    private void releaseFields(){
        txtFMINumber.setEditable(true);
        txtFMIId.setEditable(true);
        btnSearch.setEnabled(true);
        listFMIs.setEnabled(true);
        listProfiles.setEnabled(true);
//        btnAssignedUnits.setEnabled(true);
//        btnViewTasks.setEnabled(true);        
        comboEnvironment.setEnabled(true);
        progressBar.setVisible(false);
    }
    
    private void listAllDetails(){
        
        try {
            //1. Display the details of the selected FMI
            buf = new StringBuffer();
            displayFMIInfo();
            
            //2. And now of the selected Profile
            displayProfileInfo();
            
            editorResults.setText(buf.toString());
            releaseFields();
        } catch(Exception e){
            System.out.println("BOOM!");
            releaseFields();
        }
        
    }
   
    private void fetchFMIList(){
        String fmiListQuery = "";
        String authorQuery = "";
        try {
            done = false;            
            protectFields();
            
            //New search, clear everything
            modelFMIs.clear();
            modelProfiles.clear();
            listProfiles.setModel(modelProfiles);            
            DefaultListModel tempFMIModel = new DefaultListModel(); //Bug with refresh and concurrency, needed to show the listing            
            buf = new StringBuffer();
            fmis.clear();
            profiles.clear();
            editorResults.setText("");
            
            //Disable the buttons
            btnAssignedUnits.setEnabled(false);
            btnAssignedTasks.setEnabled(false);
            
            //Fetch the fmi list Information first
            conn = OracleConnectionManager.getConnection(getComboConnection());
            
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }                        
            
            fmiListQuery = "select fmi.fmi_id, fmi.fmi_number,  fmi.current_status_code,  fmi.fmi_title, fmi.description, "
                    + " NVL(to_char(fmi.creation_date,'DD-Mon-yyyy HH24:MI:SS'), '-') as creation_date,"
                    + " NVL(to_char(fmi.last_update_date,'DD-Mon-yyyy HH24:MI:SS'), '-') as last_update_date, \n" +
                    "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = fmi.last_updated_by), '-') as last_updated_by,\n" +
                    "NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = fmi.created_by), '-') as created_by\n" +
                    "from gets_fmi_entries fmi\n" +
                    "where\n 1 = 1 " +
                    (txtFMINumber.getText().trim().isEmpty() ? "" : " AND lower(fmi_number) like '" + txtFMINumber.getText().toLowerCase().trim() + "' ") +
                    (txtFMIId.getText().trim().isEmpty() ? "" : " AND fmi_id = '" + txtFMIId.getText().toLowerCase().trim() + "' ")
                    + " order by fmi.fmi_number asc"; 
                    
            prepStm = conn.prepareStatement(fmiListQuery);
            rs = prepStm.executeQuery();
                                    
            if(rs.next()){
                do {
                   
                    FMIData f = new FMIData(rs.getString("fmi_id"), 
                    rs.getString("fmi_number"),
                    FMIUtil.translateFMIStatus(rs.getString("current_status_code")),
                    rs.getString("fmi_title"),
                    rs.getString("description"),
                    rs.getString("creation_date"),
                    rs.getString("last_update_date"),                    
                    rs.getString("created_by"),
                    rs.getString("last_updated_by"));
                    
                    authorQuery = "select NVL((select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where service_employee_id = fmi.service_employee_id), '-') as author_name,\n" +
                            "NVL(lead_author, 'N') as lead_author from GETS_FMI_AUTHOR fmi \n" +
                            "where fmi.fmi_id = " + f.getId();
                    PreparedStatement pr = conn.prepareCall(authorQuery);
                    ResultSet rs2 = pr.executeQuery();
                    if(rs2.next()){
                      do {
                          f.addAuthor(new AuthorData(rs2.getString("author_name"), rs2.getString("lead_author")));
                      }while(rs2.next());  
                    } 
                    
                    fmis.add(f);                    
                    tempFMIModel.addElement(f);
                } while(rs.next());
            } else  {                                
                tempFMIModel.addElement(new FMIData("No FMIs found with that number."));
            }
                                    
            prepStm.close();
            rs.close();
            listFMIs.setModel(tempFMIModel); 
            
            releaseFields();
            done = true;
            
        }catch(Exception e){
             //------- Logging begins ----------------
             buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("FMI Number: " + txtFMINumber.getText() + "\"\n");             
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Exception info:" + e.getMessage());
             JErrorLog.createErrorLog("Class: FMILookupIF, Method: fetchFMIListing",
                 fmiListQuery, buf.toString());
             editorResults.setText("<HTML><H3>An error ocurred, please check the logs</H3></HTML>");
             //------- Logging ends ----------------         
             releaseFields();
        }           
    }
       
    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            case 3: 
                return OracleConnectionManager.INT_DEV;                
            default:
                return OracleConnectionManager.PROD;
        }
    }  
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssignedTasks;
    private javax.swing.JButton btnAssignedUnits;
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JList listFMIs;
    private javax.swing.JList listProfiles;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JScrollPane scrollFMIs;
    private javax.swing.JTextField txtFMIId;
    private javax.swing.JTextField txtFMINumber;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential