/*
  0.21
  - Added
*/

package fmi;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.fmi.FMIUtil;
import util.servicesheet.ServiceSheetUtil;


public class UnitFMILookupIF extends JInternalFrame {

    private JDesktopPane desktop;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;      
    
    public UnitFMILookupIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){       
        
        super(title, resizable, closable, maximizable, iconifiable);                        
        this.desktop = desktop;
        
        initComponents();
        
        this.getRootPane().setDefaultButton(btnSearch);
        
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/          
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { UnitFMILookupIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );          
        
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/          
    
        progressBar.setVisible(false);
    }

   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
    
     private void cleanClose() { 
         dispose(); 
     }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtFMIId = new javax.swing.JTextField();
        txtAarRoad = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtRoadNumber = new javax.swing.JTextField();
        txtLocomotiveId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtFMINumber = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        scrollFMIDetails = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtFMIId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFMIIdActionPerformed(evt);
            }
        });
        txtFMIId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFMIIdFocusGained(evt);
            }
        });

        txtAarRoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAarRoadActionPerformed(evt);
            }
        });
        txtAarRoad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAarRoadFocusGained(evt);
            }
        });

        jLabel1.setText("FMI ID:");

        jLabel2.setText("Road Number:");

        jLabel3.setText("AAR Road:");

        txtRoadNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRoadNumberFocusGained(evt);
            }
        });

        txtLocomotiveId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLocomotiveIdActionPerformed(evt);
            }
        });
        txtLocomotiveId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLocomotiveIdFocusGained(evt);
            }
        });

        jLabel4.setText("Locomotive Id:");

        jLabel5.setText("FMI Number:");

        txtFMINumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFMINumberFocusGained(evt);
            }
        });

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        scrollFMIDetails.setViewportView(editorResults);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollFMIDetails, javax.swing.GroupLayout.DEFAULT_SIZE, 827, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollFMIDetails)
        );

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addComponent(jLabel5))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(txtAarRoad, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                                            .addComponent(txtFMIId)
                                            .addComponent(txtRoadNumber)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtFMINumber)
                                            .addComponent(txtLocomotiveId)))))
                            .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(progressBar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtFMIId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtAarRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtFMINumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 148, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtAarRoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAarRoadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAarRoadActionPerformed

    private void txtFMIIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFMIIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFMIIdActionPerformed

    private void txtLocomotiveIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLocomotiveIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLocomotiveIdActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        
        if (txtAarRoad.getText().isEmpty()&&txtFMIId.getText().isEmpty()&&txtFMINumber.getText().isEmpty()
                &&txtLocomotiveId.getText().isEmpty()&&txtRoadNumber.getText().isEmpty()){
                editorResults.setText("Please give at least one input value");
            return;
        } 
                
         getDetails();
             
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtFMIIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFMIIdFocusGained
        txtFMIId.selectAll();
    }//GEN-LAST:event_txtFMIIdFocusGained

    private void txtAarRoadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAarRoadFocusGained
        txtAarRoad.selectAll();
    }//GEN-LAST:event_txtAarRoadFocusGained

    private void txtRoadNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRoadNumberFocusGained
        txtRoadNumber.selectAll();
    }//GEN-LAST:event_txtRoadNumberFocusGained

    private void txtLocomotiveIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLocomotiveIdFocusGained
        txtLocomotiveId.selectAll();
    }//GEN-LAST:event_txtLocomotiveIdFocusGained

    private void txtFMINumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFMINumberFocusGained
        txtFMINumber.selectAll();
    }//GEN-LAST:event_txtFMINumberFocusGained
                 
    private void protectFields(){
        txtFMIId.setEditable(false);
        txtAarRoad.setEditable(false);
        txtRoadNumber.setEditable(false);
        txtLocomotiveId.setEditable(false);
        txtFMINumber.setEditable(false);
        btnSearch.setEnabled(false);
        comboEnvironment.setEnabled(false);
        progressBar.setVisible(true);        
    }  
    
    private void releaseFields(){
        txtFMIId.setEditable(true);
        txtAarRoad.setEditable(true);
        txtRoadNumber.setEditable(true);
        txtLocomotiveId.setEditable(true);
        txtFMINumber.setEditable(true);
        btnSearch.setEnabled(true);
        comboEnvironment.setEnabled(true);
        progressBar.setVisible(false);
    }
        
    private void go(){
                     
        protectFields();
        
        Connection con = OracleConnectionManager.getConnection(getComboConnection());            
        if (con == null) {
          editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
          releaseFields();
          return;
        }     
       
        String fmi=new String();
        String fmiNumber=new String();
        String locomotiveId=new String();
        String profileId=null;
        String profileName=new String();
        String profileStatus=new String();
        String completionDate=new String();
        String assignmentStatus=new String();
        String ssId=new String();    
        String ssStatusCode=new String();
        String woId=new String();
        String woNumber=new String();
        String aar=new String ();
        String road=new String();
                
        String myQuery = "";
        StringBuffer result=new StringBuffer();
          try{
        
        myQuery = "select ass.fmi_id,ass.locomotive_id,ss.profile_id,"
               + " NVL((select workorder_number from gets_lms_service_workorder "
               + "where service_workorder_id = ss.service_workorder_id), '-') as workorder_number,\n" 
               + "NVL(pro.profile_name,'-') as profile_name,"
               + "NVL(pro.profile_approve_status,0) as profile_approve_status,"
               + "NVL(TO_CHAR(ass.completion_date,'DD-Mon-yyyy HH24:MI:SS') , '-') as completion_date,"
               + "NVL(ass.assignment_status,0) as assignment_status,"
               + "NVL(ent.fmi_number,'-') as fmi_number,"
               + "NVL(ss.service_sheet_id,0)as service_sheet_id, "
               + "NVL(ss.service_sheet_status_code,0) as service_sheet_status_code,"
               + "NVL(ss.service_workorder_id,0) as service_workorder_id, \n" 
               + "NVL(la.aar_road,'-') as aar_road, \n" 
               + "NVL(la.road_number,'-') as road_number \n" 
               + "from gets_fmi_entries ent,gets_lms_service_sheet ss, gets_fmi_profile pro,"
               + " gets_fmi_loco_assign ass, gets_lms_locomotive_all la\n" +                
               "where ass.profile_id = pro.profile_id\n" +
                "AND ass.locomotive_id = la.locomotive_id\n" +
                "and ass.fmi_id=ss.fmi_id \n" +
                "and ss.locomotive_id = ass.locomotive_id\n" +
                "and ent.fmi_id = ass.fmi_id\n"  +
               ( txtFMIId.getText().isEmpty() ? "" : "AND ss.fmi_id = " + txtFMIId.getText().trim())
               + 
                ( txtLocomotiveId.getText().isEmpty() ? "" : " and ass.locomotive_id=" + txtLocomotiveId.getText().trim())
               + 
                ( txtAarRoad.getText().isEmpty() ? "" : " and la.aar_road ='" + txtAarRoad.getText().trim().toUpperCase() + "' \n" ) +
                ( txtRoadNumber.getText().isEmpty() ? "" : " and la.Road_Number ='" + txtRoadNumber.getText().trim() + "' \n" )+
                (txtFMINumber.getText().isEmpty() ? "" : "and ent.fmi_number like '" + txtFMINumber.getText().trim() + "'")
               +" order by ass.locomotive_id, ass.profile_id";
                     
       PreparedStatement prepStm =con.prepareStatement(myQuery);
                ResultSet rs=prepStm.executeQuery();
                
                //For double coloring multiple records
                int row = 0;
                
                if(rs.next())  {
                    result.append("<HTML>\n<TABLE width=100% border=1>\n"+
                            "<TR BGCOLOR=#92CDDC>"
                    +"<TD ALIGN=CENTER><B>FMI Number (FMI ID)</B></TD>"                
                    +"<TD ALIGN=CENTER WIDTH=30%><B>Profile Name (Proflie ID)</B></TD>"
                    +"<TD ALIGN=CENTER><B>Profile Status</B></TD>"
                    +"<TD ALIGN=CENTER><B>Completion Date</B></TD>"
                    +"<TD ALIGN=CENTER><B>Assignment Status</B></TD>"
                    +"<TD ALIGN=CENTER><B>Service Sheet ID</B></TD>"
                    +"<TD ALIGN=CENTER><B>Service Sheet Status Code</B></TD>"
                    +"<TD ALIGN=CENTER><B>Workorder Number(WO ID)</B></TD>"         
                    +"<TD ALIGN=CENTER><B>Unit (LocoID)</B></TD>"
                    +"</TR>");
                    
                   do{                
                       profileId=rs.getString("profile_id");
                       profileName=rs.getString("profile_name");
                       profileStatus=rs.getString("profile_approve_status");
                       completionDate=rs.getString("completion_date");
                       assignmentStatus=rs.getString("assignment_status");
                       ssId=rs.getString("service_sheet_id");
                       ssStatusCode=rs.getString("service_sheet_status_code");
                       woId=rs.getString("service_workorder_id");
                       locomotiveId=rs.getString("locomotive_id");
                       fmi=rs.getString("FMI_ID");
                       fmiNumber=rs.getString("FMI_NUMBER");
                       woNumber=rs.getString("workorder_number");
                       aar=rs.getString("aar_road");
                       road=rs.getString("road_number");
                        result.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                                         + "<TD ALIGN=CENTER>" + fmiNumber + " (" + fmi + ")" + "</TD>\n"
                                         +"<TD ALIGN=CENTER WIDTH=30%>" + profileName + " (" + profileId + ")" + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + FMIUtil.translateProfileStatus(profileStatus) + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + completionDate + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + ServiceSheetUtil.translateSSStatus(assignmentStatus) + "</TD>\n"+
                                          "<TD ALIGN=CENTER>" + ssId + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + ServiceSheetUtil.translateSSStatus(ssStatusCode) + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + woNumber + " (" + woId + ")" + "</TD>\n"
                                         +"<TD ALIGN=CENTER>" + aar + "-" + road + " (" + locomotiveId + ")" + "</TD>\n"                                       
                                     +"</TR>\n");
                        row++;
                   }while (rs.next());
       
                
       } else {
          editorResults.setText("<HTML><H3>No results found with that criteria.</H3></HTML>");          
       }
     }catch (Exception e){
             //------- Logging begins ----------------
             StringBuffer buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("FMI Number: " + txtFMINumber.getText() + "\"\n");             
             buf.append("FMI Id: " + txtFMIId.getText() + "\"\n");
             buf.append("Locomotive ID: " + txtLocomotiveId.getText() + "\"\n");
             buf.append("AAR Road: " + txtAarRoad.getText() + "\"\n");
             buf.append("Road Number: " + txtRoadNumber.getText() + "\"\n");
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Exception info:" + e.getMessage());
             JErrorLog.createErrorLog("Class: UnitFMILookupIF, Method: go",
                 myQuery, buf.toString());
             editorResults.setText("<HTML><H3>An error ocurred, please check the logs</H3></HTML>");
             //------- Logging ends ----------------            
         releaseFields();
         return;
     }          
          result.append("</TABLE>\n</HTML>");                 
          editorResults.setText(result.toString());
          releaseFields();
          
    }
    
    private void getDetails(){
        new Thread(new Runnable() {
          public void run() {                    
              go();              
            while (!done)
              try {
                Thread.sleep(100L);
                
              }
              catch (InterruptedException ie) {
              }
          }
        }).start();        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JScrollPane scrollFMIDetails;
    private javax.swing.JTextField txtAarRoad;
    private javax.swing.JTextField txtFMIId;
    private javax.swing.JTextField txtFMINumber;
    private javax.swing.JTextField txtLocomotiveId;
    private javax.swing.JTextField txtRoadNumber;
    // End of variables declaration//GEN-END:variables
    boolean done=false;

    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            case 3: 
                return OracleConnectionManager.INT_DEV;                
            default:
                return OracleConnectionManager.PROD;
        }
    }      
    
}
