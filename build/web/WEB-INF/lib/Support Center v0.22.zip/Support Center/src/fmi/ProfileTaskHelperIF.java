 /*
  v 0.16
  - Added.
*/

package fmi;

import eservicesmanager.SupportCenter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import servicesheet.*;
import util.fmi.*;
import util.servicesheet.ServiceSheetUtil;
import util.workorder.WorkorderData;


public class ProfileTaskHelperIF extends JInternalFrame {

   private SupportCenter parent;
   private ProfileData profile;
   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;
   
    public ProfileTaskHelperIF(final JDesktopPane desktop, SupportCenter parent, ProfileData profile, int environment, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {

     super(title, resizable, closable, maximizable, iconifiable);
     this.parent = parent;
     this.profile = profile;
     this.environment = environment;
     
     initComponents();
     
     editorResults.setText("<HTML><H3>Pulling records...</H3></HTML>");      
     loadInformation();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { ProfileTaskHelperIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     parent.addWindow(this);
     try {
       setSelected(true);
     } catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadInformation() {
     new Thread(new Runnable() {
       public void run() {
         fetchFMITaskInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
 
   private void fetchFMITaskInfo()
   {
     String fmiAssignmentDetailsQuery = "";
     
     try
     {
       conn = util.OracleConnectionManager.getConnection(environment);
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         return;
       }
       
       buf = new StringBuffer();
       fmiAssignmentDetailsQuery = "select t.task_id, pt.display_sequence, t.task_description, NVL(t.url, '-') as url \n" +
            "from GETS_FMI_PROFILE_TASK pt, gets_fmi_tasks t where \n" +
            "pt.task_id = t.task_id \n" +
            "AND pt.profile_id = " + profile.getProfileId() + " \n" +
            "order by pt.display_sequence asc";            

       prepStm = conn.prepareStatement(fmiAssignmentDetailsQuery);
       rs = prepStm.executeQuery();
       
       buf.append("<HTML><BODY>");
       if (rs.next()) {
         buf.append("<TABLE width=100%>"
                 + "<TR><TD ALIGN=CENTER bgcolor=\"#92CDDC\" colspan=9><B>PROFILE TASKS</B></TD></TR>"
                 + "<TR>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Task ID</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Display Seq.</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>Description</B</TD>"
                 + "<TD ALIGN=CENTER bgcolor=\"#92CDDC\"><B>URL</B</TD>"
                 + "</TR>");
         do {
           buf.append("<TR>\n"                   
                   + "   <TD align=CENTER>" + rs.getString("task_id") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("display_sequence") + "</TD>\n" 
                   + "   <TD >" + rs.getString("task_description") + "</TD>\n" 
                   + "   <TD align=CENTER>" + rs.getString("url") + "</TD>\n" 
                   + "</TR>\n");
         }
         while (rs.next());
         
         buf.append("</TABLE><BR>");
       }
        
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: \"" + environment + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: ProfileTaskHelperIF, Method: fetchFMIAssignInfo", fmiAssignmentDetailsQuery, buf.toString());
       
       editorResults.setText("An Error occurred, please check the logs.");
     }
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 770, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential