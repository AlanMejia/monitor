/*
 v 0.22
 - Added
 */

package rmd;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;
import util.customerorgs.ServiceOrgData;
import util.servicesheet.ServiceSheetUtil;

/**
 *
 * @author 779609
 */
public class RMDServiceSheetIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;          
    
    public RMDServiceSheetIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){

        super(title, resizable, closable, maximizable, iconifiable);    
        initComponents();
        
     addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { RMDServiceSheetIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );               
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
     
     
     this.getRootPane().setDefaultButton(btnSearch); 
     
     progressBar.setVisible(false);
    }

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     

    
    private void cleanClose() {
      dispose();
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtLocomotiveID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtServiceSheetID = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtSysRecID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtAarRoad = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtRoadNumber = new javax.swing.JTextField();
        comboEnvironment = new javax.swing.JComboBox();
        btnSearch = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Locomotive ID");

        txtLocomotiveID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLocomotiveIDFocusGained(evt);
            }
        });

        jLabel2.setText("Service Sheet ID");

        txtServiceSheetID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtServiceSheetIDFocusGained(evt);
            }
        });

        jLabel3.setText("SYS REC ID");

        txtSysRecID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSysRecIDFocusGained(evt);
            }
        });

        jLabel5.setText("AAR Road");

        jLabel6.setText("Road Number");

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSysRecID, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                            .addComponent(txtServiceSheetID)
                            .addComponent(txtLocomotiveID)
                            .addComponent(txtAarRoad)
                            .addComponent(txtRoadNumber)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSearch)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLocomotiveID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtServiceSheetID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSysRecID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtAarRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearch)
                .addContainerGap())
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane2.setViewportView(editorResults);

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 230, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
         if (txtLocomotiveID.getText().isEmpty()&&txtServiceSheetID.getText().isEmpty()
             &&txtSysRecID.getText().isEmpty()&&txtRoadNumber.getText().isEmpty() &&txtAarRoad.getText().isEmpty()){
                                  editorResults.setText("Please give at least one input value");
                                  return;
        } else{
        
        btnSearch.setEnabled(false);
         threadGetdetails();}
               
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtLocomotiveIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLocomotiveIDFocusGained
        txtLocomotiveID.selectAll();
    }//GEN-LAST:event_txtLocomotiveIDFocusGained

    private void txtServiceSheetIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtServiceSheetIDFocusGained
        txtServiceSheetID.selectAll();
    }//GEN-LAST:event_txtServiceSheetIDFocusGained

    private void txtSysRecIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSysRecIDFocusGained
        txtSysRecID.selectAll();
    }//GEN-LAST:event_txtSysRecIDFocusGained
    
    private void protectFields(){
        btnSearch.setEnabled(false);
        txtLocomotiveID.setEditable(false);
        txtServiceSheetID.setEditable(false);
        txtSysRecID.setEditable(false);
        txtRoadNumber.setEditable(false);
        txtAarRoad.setEditable(false);
        comboEnvironment.setEnabled(false);
        progressBar.setVisible(true);
    }
    
    private void releaseFields(){
        btnSearch.setEnabled(true);
        txtLocomotiveID.setEditable(true);
        txtServiceSheetID.setEditable(true);
        txtSysRecID.setEditable(true);
        txtRoadNumber.setEditable(true);
        txtAarRoad.setEditable(true);
        comboEnvironment.setEnabled(true);
        progressBar.setVisible(false);        
    }
    
     private void dataExtraction(){
         protectFields();
         conn = OracleConnectionManager.getConnection(getComboConnection());
       
        if (conn == null) {
          editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
          releaseFields();
          return;
        }                
        
        String workorder;
        String serviceSheet;
        String locomotiveId;
        String creationDate;
        String lastUpdateDate;        
        String ssStatusCode;
        String aar;
        String road;
        String sysRecId;
        String description;
        String numberOfTasks;
        String RMDstatus;
        String rmdLocomotiveId;
        
        StringBuffer result=new StringBuffer();
        result.append("<HTML>\n<TABLE width=100% border=1>\n"+
        "<TR BGCOLOR=#92CDDC>"
        +"<TD ALIGN=CENTER><b>Unit (LocoID)</b></TD>" 
        +"<TD ALIGN=CENTER><b>RMD Locomotive ID</b></TD>"
        +"<TD ALIGN=CENTER WIDTH=30%><b>Source System Rec ID</b></TD>"
        +"<TD ALIGN=CENTER><b>Description</b></TD>"
        +"<TD ALIGN=CENTER><b>Workorder ID</b></TD>"
        +"<TD ALIGN=CENTER><b>Service Sheet ID</b></TD>"
        +"<TD ALIGN=CENTER><b>Service Sheet Status Code</b></TD>"
        +"<TD ALIGN=CENTER><b>RMD Status Code</b></TD>"
        +"<TD ALIGN=CENTER><b>Creation Date</b></TD>"         
        +"<TD ALIGN=CENTER><b>Last Update Date</b></TD>"                
        +"<TD ALIGN=CENTER><b>Number of Tasks</b></TD>"                
        +"</TR>");
        
        String myQuery = "";
        
          try{
        
        myQuery =  "select distinct (select count(*) from gets_lms_sr_qa_results where service_sheet_id = rmd.service_sheet_id) as no_of_tasks, \n" +
                         "rmd.source_system_rec_id,rmd.description,rmd.service_sheet_id,ss.service_Workorder_id,\n" +
                         "ss.service_sheet_status_code,loco.aar_road,loco.road_number,loco.locomotive_id,\n" +
                         "ss.creation_date,ss.last_update_date,\n" +
                         "rmd.description,rmd.sr_status_code,rmd.locomotive_id as rmd_locoId\n"
                       +"from gets_lms_service_req_entries rmd,gets_lms_service_sheet ss,gets_lms_locomotive_all loco \n "
                       + "where ss.service_sheet_id=rmd.service_sheet_id\n"
                       + "and loco.locomotive_id=rmd.locomotive_id\n"                          
                       + ( txtRoadNumber.getText().isEmpty() ? "" : "AND loco.road_number = '" + txtRoadNumber.getText().trim()+ "' \n" )
                       + ( txtLocomotiveID.getText().isEmpty() ? "" : " and loco.locomotive_id=" + txtLocomotiveID.getText().trim())
                       + ( txtAarRoad.getText().isEmpty() ? "" : " and loco.aar_road ='" + txtAarRoad.getText().trim().toUpperCase() + "' \n" ) 
                       + ( txtSysRecID.getText().isEmpty() ? "" : " and rmd.source_system_rec_id ='" + txtSysRecID.getText().trim() + "' \n" )
                       + (txtServiceSheetID.getText().isEmpty() ? "" : "and rmd.Service_sheet_id = '" + txtServiceSheetID.getText().trim() + "'")
               +" order by ss.creation_date";
       
              System.out.println(myQuery);
              prepStm =conn.prepareStatement(myQuery);
              rs=prepStm.executeQuery();
              int row = 0;
              
                if(rs.next())  {
                   do{   
                       numberOfTasks=rs.getString("no_of_tasks");
                       workorder=rs.getString("service_workorder_id");
                       serviceSheet=rs.getString("service_sheet_id");
                       locomotiveId=rs.getString("locomotive_id");
                       aar=rs.getString("aar_road");
                       road=rs.getString("road_number");
                       sysRecId=rs.getString("source_system_rec_id");
                       description=rs.getString("description");
                       creationDate=rs.getString("creation_date");
                       lastUpdateDate=rs.getString("last_update_date");
                       ssStatusCode=rs.getString("service_sheet_status_code");
                       RMDstatus=rs.getString("sr_status_code");
                       rmdLocomotiveId=rs.getString("rmd_LocoId");
            
                       result.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")                                                           
                                         +"<TD ALIGN=CENTER>"+ aar+"-"+road+" ("+locomotiveId+")"+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+rmdLocomotiveId+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+sysRecId+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+description+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+workorder+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+serviceSheet+"</TD>\n"+
                                          "<TD ALIGN=CENTER>"+ServiceSheetUtil.translateSSStatus(ssStatusCode)+"</TD>\n"
                                         +"<TD " + (!ssStatusCode.equals(RMDstatus) ? " BGCOLOR=RED" : "" ) + " ALIGN=CENTER>"+ServiceSheetUtil.translateSSStatus(RMDstatus)+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+creationDate+"</TD>\n"
                                         +"<TD ALIGN=CENTER>"+lastUpdateDate+"</TD>\n"                         
                                         +"<TD " + (!numberOfTasks.equals("0") ? " BGCOLOR=RED" : "" ) + " ALIGN=CENTER >"+numberOfTasks+"</TD>\n"
                                     +"</TR>\n");  
                       row++;
                   }while (rs.next());
       
                
                } else {
                    prepStm.close();
                    rs.close();                
                    editorResults.setText("<HTML><H2>No records found with that criteria.</H2></HTML>");
                    releaseFields();
                    done = true;
                    return;                    
                }  
                
                result.append("</TABLE>\n</HTML>");                 
                editorResults.setText(result.toString());                
                releaseFields();
                
          }catch (Exception e){
                StringBuffer buf = new StringBuffer("");
                buf.append("-- Fields --\n");
                buf.append("txtLocomotiveID: \"" + txtLocomotiveID.getText() + "\"\n");
                buf.append("txtServiceSheetID: \"" + txtServiceSheetID.getText() + "\"\n");
                buf.append("txtSysRecID: \"" + txtSysRecID.getText() + "\"\n");       
                buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");       
                buf.append("txtAarRoad: \"" + txtAarRoad.getText() + "\"\n");                       
                buf.append("Environment: " + getComboConnection() + "\"\n");
                buf.append("-- Exception --\n");
                buf.append("Could not pull Material details because: \n");
                buf.append(e.getMessage());
                util.JErrorLog.createErrorLog("Class: RMDServiceSheetIF, Method: dataExtraction", myQuery + "\n\n", buf.toString());

                editorResults.setText("An Error occurred, please check the logs.");
                releaseFields();
          }                
    
    }
  
    private int getComboConnection()
    {
     switch (comboEnvironment.getSelectedIndex()) {
        case 0: 
          return OracleConnectionManager.PROD;
        case 1: 
          return OracleConnectionManager.STG;
        case 2: 
          return OracleConnectionManager.DEV;
        case 3: 
          return OracleConnectionManager.INT_DEV;
     }
     return 0;
    }        
     
    private void threadGetdetails(){
        new Thread(new Runnable() {
          public void run() {                    
              dataExtraction();
              
            while (!done)
              try {
                Thread.sleep(100L);
                
              }
              catch (InterruptedException ie) {
              }
          }
        }).start();        
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtAarRoad;
    private javax.swing.JTextField txtLocomotiveID;
    private javax.swing.JTextField txtRoadNumber;
    private javax.swing.JTextField txtServiceSheetID;
    private javax.swing.JTextField txtSysRecID;
    // End of variables declaration//GEN-END:variables
   boolean done=false;

}
