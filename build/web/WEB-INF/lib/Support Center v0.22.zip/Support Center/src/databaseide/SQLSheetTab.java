/*
  0.21
  - Added.
*/

package databaseide;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import jsyntaxpane.DefaultSyntaxKit;
import org.jdesktop.swingx.JXTable;
import util.DBUtils;
import util.OracleConnectionManager;
import util.TextLineNumber;

public class SQLSheetTab extends javax.swing.JPanel {

   private Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = true;   
   private JTextArea areaLog;
   private JXTable tableResults;
   private DBUtils dbUtils;
    
    public SQLSheetTab(String initialText) {
        
        initComponents();
        
        //Set the log area
        areaLog = new JTextArea();
        areaLog.setWrapStyleWord(true);
        areaLog.setLineWrap(true);
        areaLog.setEditable(false);
        
        //Set the table
        tableResults = new JXTable();
        tableResults.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);        
        
        //Set the TextLine component
        TextLineNumber tln = new TextLineNumber(editorSQL);
        scrollSQL.setRowHeaderView( tln );
        
        //Implement the F9 to run functionality
        editorSQL.getActionMap().put("run", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(done)
                        runQuery();
                }
            });  
        InputMap inputMap = editorSQL.getInputMap();
        KeyStroke f9 = KeyStroke.getKeyStroke("F9");
        inputMap.put(f9, "run");
        //-------------------------------------------
        
        //Helper for buffering the pulled rows
        dbUtils = new DBUtils();
        
        //Lets color that syntax!
        DefaultSyntaxKit.initKit();
        editorSQL.setContentType("text/sql");
        
        progressBar.setVisible(false);    
        
        //Set the initial text, if any
        if(null == initialText)
            editorSQL.setText("");
        else
            editorSQL.setText(initialText);
                
    }

   private void runQuery() {
     new Thread(new Runnable() {
       public void run() {
         executeQuery();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }    
    
   private void protectFields(){
       editorSQL.setEditable(false);
       comboEnvironment.setEnabled(false);
       progressBar.setVisible(true);
   }
   
   private void releaseFields(){
       editorSQL.setEditable(true);
       comboEnvironment.setEnabled(true);
       progressBar.setVisible(false);
   }
   
   private void executeQuery(){
       protectFields();
       String query;
       done = false;
       //Are you selecting a query or running the entire script?
       if(editorSQL.getSelectedText() == null){
           query = editorSQL.getText();
       } else {
           query = editorSQL.getSelectedText();
       }      
       
       //Clean up the Query
       query = sanitizeQuery(query);
       
       try {
         conn = util.OracleConnectionManager.getConnection(getComboConnection());

        if (conn == null) {
          scrollResults.setViewportView(areaLog);
          areaLog.setText("Database Connection could not be established, please check your network status.");          
          done = true;
          releaseFields();
          return;
        }       
        
        prepStm = conn.prepareStatement(query);
        rs = prepStm.executeQuery();
        
        //Was it an UPDATE, DELETE, INSERT or anything else?
        ResultSetMetaData meta = prepStm.getMetaData();
        if(meta == null){
          scrollResults.setViewportView(areaLog);
          areaLog.setText("Query \"" + query + "\" executed. "); 
          done = true;
          releaseFields();       
          return;
        }
                
        //Get the first 50 results, first pull so reset the row count.
        dbUtils.resetRows();     
        //Scroll to set it as visible
        JViewport viewport = scrollResults.getViewport();
        Rectangle rect = tableResults.getCellRect(0, 0, true);       
        Point pt = viewport.getViewPosition();
        rect.setLocation(rect.x-pt.x, rect.y-pt.y);
        tableResults.scrollRectToVisible(rect);        
        
        tableResults.setModel(dbUtils.resultSetToTableModel(rs));   
        tableResults.packAll();        
        
        //Display and add the change listener to monitor when you reach the bottom.
        scrollResults.add(tableResults);
        scrollResults.setViewportView(tableResults);
        
        scrollResults.getViewport().addChangeListener(new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent e) {
                Rectangle viewRect = scrollResults.getViewport().getViewRect();
                int first = tableResults.rowAtPoint(new Point(0, viewRect.y));
                if (first == -1)
                {
                    return; // Table is empty
                }
                int last = tableResults.rowAtPoint(new Point(0, viewRect.y + viewRect.height - 1));
                if (last == -1)
                {
                    last = tableResults.getModel().getRowCount() - 1; // Handle empty space below last row
                }

                if (last == tableResults.getModel().getRowCount() - 1) {
                    bufferRecords(rs); //Pull other 50 records
                } //... Last row is visible
            }
            
        });             
        
        done = true;
        releaseFields();
       }catch(Exception e){
          scrollResults.setViewportView(areaLog);
          areaLog.setText("Error occurred while running \"" + query + "\": " + e.getMessage()); 
          done = true;
          releaseFields();          
       }
   }

   //WIP: So far just look for a ";" and remove it.
   private String sanitizeQuery(String query) {
        return query.replace(";", "");
    }
   
   private void bufferRecords(ResultSet res){
        tableResults.setModel(dbUtils.resultSetToTableModel(rs));          
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelHeader = new javax.swing.JPanel();
        comboEnvironment = new javax.swing.JComboBox();
        progressBar = new javax.swing.JProgressBar();
        splitPane = new javax.swing.JSplitPane();
        scrollResults = new javax.swing.JScrollPane();
        scrollSQL = new javax.swing.JScrollPane();
        editorSQL = new javax.swing.JEditorPane();

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout panelHeaderLayout = new javax.swing.GroupLayout(panelHeader);
        panelHeader.setLayout(panelHeaderLayout);
        panelHeaderLayout.setHorizontalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap(470, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelHeaderLayout.setVerticalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHeaderLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(comboEnvironment)
                    .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        splitPane.setDividerLocation(300);
        splitPane.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        splitPane.setRightComponent(scrollResults);

        scrollSQL.setViewportView(editorSQL);

        splitPane.setTopComponent(scrollSQL);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(splitPane)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(splitPane, javax.swing.GroupLayout.DEFAULT_SIZE, 496, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorSQL;
    private javax.swing.JPanel panelHeader;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JScrollPane scrollResults;
    private javax.swing.JScrollPane scrollSQL;
    private javax.swing.JSplitPane splitPane;
    // End of variables declaration//GEN-END:variables

}
