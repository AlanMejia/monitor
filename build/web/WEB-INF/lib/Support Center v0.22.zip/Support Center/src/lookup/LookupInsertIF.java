/*
  v 0.14
   - Created.
*/

package lookup;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import util.*;
import util.lookup.*;

public class LookupInsertIF extends JInternalFrame {

    private boolean done = false; 
    private java.sql.Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;  
    private StringBuffer buf;
    private ArrayList<LookupTypeData> existingLookups;
    private ArrayList<LookupValueData> newValues;
    private LookupTypeData newLookup;
    private DefaultComboBoxModel existingLookupModel;
    private DefaultListModel model;
    private boolean successfulTransaction = false; 
        
    public LookupInsertIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { 
        
     super(title, resizable, closable, maximizable, iconifiable);
     
     model = new DefaultListModel();
     newValues = new ArrayList<>();
    
    initComponents();
    listLookupValues.setModel(model);
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { LookupInsertIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
           
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     
     enableExistingLookup();
     loadExistingLookups();
    }
   
   private void cleanClose() { 
       dispose(); 
   }

   private void loadExistingLookups() {
     new Thread(new Runnable() {
       public void run() {
         fetchExistingLookups();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }     
   
     private void fetchExistingLookups(){
       String customerQuery = "";
       try {
            done = false;
            protectFields();
            editorResults.setText("Populating Existing Lookup dropdown...");     
            
           conn = util.OracleConnectionManager.getConnection(getComboConnection());
                        
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            customerQuery = "select lookup_type_id, lookup_type, type_meaning, type_description from gets_lms_lookup_types order by lookup_type asc";
            existingLookups = new ArrayList<>();
            existingLookups.add(new LookupTypeData("0", "-- Please Select Lookup Type --", "", ""));
            prepStm = conn.prepareStatement(customerQuery);
            rs = prepStm.executeQuery();
            
            while(rs.next()){
                existingLookups.add(new LookupTypeData(rs.getString("lookup_type_id"), 
                        rs.getString("lookup_type"), 
                        rs.getString("type_meaning"), 
                        rs.getString("type_description")));
            }
           
            existingLookupModel = new DefaultComboBoxModel(existingLookups.toArray());
            comboExistingLookups.setModel(existingLookupModel);   
            
            prepStm.close();
            rs.close();
            releaseFields();
            editorResults.setText("");
            
       }catch(Exception e){
            buf = new StringBuffer("");
             buf.append("-- Fields --\n");
//             buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
//             buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
//             buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");       
//             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Could not pull Customer details because: \n");
             buf.append(e.getMessage());
             util.JErrorLog.createErrorLog("Class: LocomotiveInfoIF, Method: fetchCustomerList", customerQuery + "\n\n", buf.toString());

             editorResults.setText("An Error occurred, please check the logs.");
             releaseFields();           
       }
   }
   
     private void protectFields(){
        btnAddValue.setEnabled(false);
        btnClearList.setEnabled(false);
        btnDeleteFromList.setEnabled(false);
        btnEditValue.setEnabled(false);
        btnGenerate.setEnabled(false);
        btnSaveToFile.setEnabled(false);
        comboEnvironment.setEnabled(false);
        comboExistingLookups.setEnabled(false);
        radioExistingLookup.setEnabled(false);
        radioNewLookup.setEnabled(false);
     }
     
     private void releaseFields(){
        btnAddValue.setEnabled(true);
        btnClearList.setEnabled(true);
        btnDeleteFromList.setEnabled(true);
        btnEditValue.setEnabled(true);
        btnGenerate.setEnabled(true);
        btnSaveToFile.setEnabled(true);   
        comboEnvironment.setEnabled(true);
        comboExistingLookups.setEnabled(true);
        radioExistingLookup.setEnabled(true);
        radioNewLookup.setEnabled(true);
     }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }     
     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgInsertLookupType = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        radioExistingLookup = new javax.swing.JRadioButton();
        comboExistingLookups = new javax.swing.JComboBox();
        radioNewLookup = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        lblTypeMeaning = new javax.swing.JLabel();
        lblTypeDescription = new javax.swing.JLabel();
        txtTypeMeaning = new javax.swing.JTextField();
        txtTypeDescription = new javax.swing.JTextField();
        txtTypeType = new javax.swing.JTextField();
        lblTypeType = new javax.swing.JLabel();
        comboEnvironment = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtValueCode = new javax.swing.JTextField();
        txtValueMeaning = new javax.swing.JTextField();
        txtValueDescription = new javax.swing.JTextField();
        btnAddValue = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        listLookupValues = new javax.swing.JList();
        btnClearList = new javax.swing.JButton();
        btnDeleteFromList = new javax.swing.JButton();
        btnEditValue = new javax.swing.JButton();
        btnGenerate = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        btnSaveToFile = new javax.swing.JButton();

        bgInsertLookupType.add(radioExistingLookup);
        bgInsertLookupType.add(radioNewLookup);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        radioExistingLookup.setSelected(true);
        radioExistingLookup.setText("Use existing Lookup Type:");
        radioExistingLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioExistingLookupActionPerformed(evt);
            }
        });

        comboExistingLookups.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Populating existing lookups... --" }));

        radioNewLookup.setText("Create a new Lookup Type:");
        radioNewLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioNewLookupActionPerformed(evt);
            }
        });

        lblTypeMeaning.setText("Meaning:");

        lblTypeDescription.setText("Description:");

        txtTypeMeaning.setDocument(new JCharacterLimitVerifier(100));
        txtTypeMeaning.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeMeaningFocusGained(evt);
            }
        });

        txtTypeDescription.setDocument(new JCharacterLimitVerifier(1000));
        txtTypeDescription.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeDescriptionFocusGained(evt);
            }
        });

        txtTypeType.setDocument(new JCharacterLimitVerifier(30));
        txtTypeType.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeTypeFocusGained(evt);
            }
        });

        lblTypeType.setText("Type:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblTypeMeaning)
                    .addComponent(lblTypeDescription)
                    .addComponent(lblTypeType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTypeMeaning)
                    .addComponent(txtTypeDescription)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtTypeType, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTypeType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTypeType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTypeMeaning)
                    .addComponent(txtTypeMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTypeDescription)
                    .addComponent(txtTypeDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(radioNewLookup, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                    .addComponent(radioExistingLookup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(comboExistingLookups, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioExistingLookup)
                    .addComponent(comboExistingLookups, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(radioNewLookup)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));
        comboEnvironment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboEnvironmentActionPerformed(evt);
            }
        });

        jLabel1.setText("Required Lookup Value data:");

        jLabel5.setText("Lookup Code:");

        jLabel6.setText("Value Meaning:");

        jLabel7.setText("Value Description:");

        txtValueCode.setDocument(new JCharacterLimitVerifier(30));
        txtValueCode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueCodeFocusGained(evt);
            }
        });

        txtValueMeaning.setDocument(new JCharacterLimitVerifier(1000));
        txtValueMeaning.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueMeaningFocusGained(evt);
            }
        });

        txtValueDescription.setDocument(new JCharacterLimitVerifier(1000));
        txtValueDescription.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueDescriptionFocusGained(evt);
            }
        });

        btnAddValue.setText("Add Lookup Value ------>");
        btnAddValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddValueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAddValue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtValueCode, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtValueDescription, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
                                    .addComponent(txtValueMeaning))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtValueCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(txtValueMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtValueDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAddValue)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(listLookupValues);

        btnClearList.setText("Clear");
        btnClearList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearListActionPerformed(evt);
            }
        });

        btnDeleteFromList.setText("Delete");
        btnDeleteFromList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteFromListActionPerformed(evt);
            }
        });

        btnEditValue.setText("Edit");
        btnEditValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditValueActionPerformed(evt);
            }
        });

        btnGenerate.setText("Generate!");
        btnGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerateActionPerformed(evt);
            }
        });

        editorResults.setEditable(false);
        editorResults.setFont(new java.awt.Font("Courier New", 0, 13)); // NOI18N
        jScrollPane2.setViewportView(editorResults);

        btnSaveToFile.setText("Save to File");
        btnSaveToFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveToFileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnGenerate)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSaveToFile)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                                .addComponent(btnEditValue)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDeleteFromList)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearList))
                            .addComponent(jScrollPane1)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnClearList)
                        .addComponent(btnDeleteFromList)
                        .addComponent(btnEditValue))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnGenerate)
                        .addComponent(btnSaveToFile)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTypeTypeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeTypeFocusGained
        txtTypeType.selectAll();
    }//GEN-LAST:event_txtTypeTypeFocusGained

    private void txtTypeMeaningFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeMeaningFocusGained
        txtTypeMeaning.selectAll();
    }//GEN-LAST:event_txtTypeMeaningFocusGained

    private void txtTypeDescriptionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeDescriptionFocusGained
        txtTypeDescription.selectAll();
    }//GEN-LAST:event_txtTypeDescriptionFocusGained

    private void txtValueCodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueCodeFocusGained
        txtValueCode.selectAll();
    }//GEN-LAST:event_txtValueCodeFocusGained

    private void txtValueMeaningFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueMeaningFocusGained
        txtValueCode.selectAll();
    }//GEN-LAST:event_txtValueMeaningFocusGained

    private void txtValueDescriptionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueDescriptionFocusGained
        txtValueDescription.selectAll();
    }//GEN-LAST:event_txtValueDescriptionFocusGained

    private void radioExistingLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioExistingLookupActionPerformed
       enableExistingLookup();
    }//GEN-LAST:event_radioExistingLookupActionPerformed

    private void radioNewLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioNewLookupActionPerformed
       enableNewLookup();  
    }//GEN-LAST:event_radioNewLookupActionPerformed

    private void btnAddValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddValueActionPerformed
        if ((txtValueCode.getText().isEmpty()) || (txtValueMeaning.getText().isEmpty()) || (txtValueDescription.getText().isEmpty()) ) {            
            
        } else {
            listLookupValues.clearSelection();
            addLookupValueToList();
        }
    }//GEN-LAST:event_btnAddValueActionPerformed

    private void btnEditValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditValueActionPerformed
        //1. Get the selected data
        LookupValueData d = (LookupValueData)model.getElementAt(listLookupValues.getSelectedIndex());
        //2. fill the form
        txtValueCode.setText(d.getCode());
        txtValueMeaning.setText(d.getValueMeaning());
        txtValueDescription.setText(d.getValueDescription());
        //3. Remove the value from the list
        model.remove(listLookupValues.getSelectedIndex());
        newValues.remove(d);        
        listLookupValues.clearSelection();
        
    }//GEN-LAST:event_btnEditValueActionPerformed

    private void btnDeleteFromListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteFromListActionPerformed
        newValues.remove((LookupValueData)model.getElementAt(listLookupValues.getSelectedIndex()));
        model.remove(listLookupValues.getSelectedIndex());        
    }//GEN-LAST:event_btnDeleteFromListActionPerformed

    private void btnClearListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearListActionPerformed
        model.removeAllElements();
        newValues.clear();
    }//GEN-LAST:event_btnClearListActionPerformed

    private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateActionPerformed
        if(radioExistingLookup.isSelected()){
            if(0 == comboExistingLookups.getSelectedIndex()) {
                editorResults.setText("Please select an Existing Lookup Type from the dropdown.");
                return;
            } 
            else
             if (newValues.size() == 0 ){
                editorResults.setText("Please add at least one Lookup Value to the list.");
                return;
            } else {
                existingLookupInsertScript();
                successfulTransaction = true;
             }
        } else {
           if ((txtTypeType.getText().isEmpty()) || (txtTypeMeaning.getText().isEmpty()) || (txtTypeDescription.getText().isEmpty()) ) {            
             editorResults.setText("Please fill all the details of the new Lookup Type.");
             return;
           } else if (newValues.size() == 0 ){
                editorResults.setText("Please add at least one Lookup Value to the list.");
                return;
            } else {
                newLookupInsertScript();
                successfulTransaction = true;
           }
        } 

    }//GEN-LAST:event_btnGenerateActionPerformed

    private void comboEnvironmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboEnvironmentActionPerformed
        loadExistingLookups();
    }//GEN-LAST:event_comboEnvironmentActionPerformed

    private void btnSaveToFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveToFileActionPerformed
        if(successfulTransaction){
            JFileChooser fc = new JFileChooser();
            fc.setFileFilter(new util.FolderFilter());
            fc.setFileSelectionMode(1);

            int returnVal = fc.showOpenDialog(this);

            if (returnVal == 0)
              try {
                org.apache.commons.io.FileUtils.write(new File(fc.getSelectedFile().getAbsolutePath() + "\\\\LookupInsert-" + (radioExistingLookup.isSelected() ? ((LookupTypeData)comboExistingLookups.getSelectedItem()).getType() : txtTypeType.getText().toUpperCase().trim() )+ ".sql"), this.editorResults.getText());
                javax.swing.JOptionPane.showMessageDialog(null, "Operation Successful!", "File saved!", -1);
              } catch (Exception e) {
                System.out.println(e.getMessage()); }            
        }
    }//GEN-LAST:event_btnSaveToFileActionPerformed

    private void newLookupInsertScript(){
        //1. Insert the new Lookup Type
        buf = new StringBuffer();
        
        buf.append("DECLARE\n" +
                   "    v_lookup_type_id NUMBER;\n" +
                   "BEGIN\n\n");
        buf.append("select GETS_LMS.gets_lms_lookup_types_s.nextval into v_lookup_type_id from dual;\n");
        buf.append("insert into gets_lms.gets_lms_lookup_types (lookup_type_id, lookup_type, type_meaning, type_description, created_by, creation_date, last_updated_by, last_update_date) \n" +
                    "values (v_lookup_type_id, '" + txtTypeType.getText().trim() +"', "
                + "'" + txtTypeMeaning.getText().trim() + "', '" + txtTypeDescription.getText().trim() + "', '-1', sysdate, '-1', sysdate);\n\n");

          for(LookupValueData v : newValues) {
              buf.append("-- Adding Lookup value '" + v.getCode() + "' in Lookup Type '" + txtTypeType.getText().trim() + "'\n");
              buf.append("INSERT INTO gets_lms.gets_lms_lookup_values (lookup_value_id,lookup_type_id, lookup_code, value_meaning, value_description, enabled_flag, active_date_start, active_date_end, created_by, creation_date, last_updated_by, last_update_date)\n " 
                + " VALUES (GETS_LMS.GETS_LMS_LOOKUP_VALUES_S.nextval, v_lookup_type_id, \n" 
                + "'" + v.getCode() + "', '" + v.getValueMeaning() + "', "
                + "'" + v.getValueDescription() + "', 'Y', sysdate, null, '-1', sysdate, '-1', sysdate);\n\n");
          }
 
        buf.append("COMMIT;\n\nEND;\n");        
        editorResults.setText(buf.toString());        
    }    
    
    private void existingLookupInsertScript(){
        
        buf = new StringBuffer();
        LookupTypeData lt = (LookupTypeData)comboExistingLookups.getSelectedItem();
        buf.append("BEGIN \n");
          
          for(LookupValueData v : newValues) {
              buf.append("-- Adding Lookup value '" + v.getCode() + "' in Lookup Type '" + lt.getType() + "'\n");
              buf.append("INSERT INTO gets_lms.gets_lms_lookup_values (lookup_value_id,lookup_type_id, lookup_code, value_meaning, value_description, enabled_flag, active_date_start, active_date_end, created_by, creation_date, last_updated_by, last_update_date)\n " 
                + " VALUES (GETS_LMS.GETS_LMS_LOOKUP_VALUES_S.nextval, " + lt.getTypeId() + ", \n" 
                + "'" + v.getCode() + "', '" + v.getValueMeaning() + "', "
                + "'" + v.getValueDescription() + "', 'Y', sysdate, null, '-1', sysdate, '-1', sysdate);\n\n");
          }
 
        buf.append("COMMIT;\n\nEND;\n");        
        editorResults.setText(buf.toString());
    }
    
    private void addLookupValueToList(){
        LookupValueData d = new LookupValueData(txtValueCode.getText().trim(), txtValueMeaning.getText().trim(), txtValueDescription.getText().trim());
        model.addElement(d);
        newValues.add(d);
        clearValueFields();
    }
    
    private void clearValueFields() {
        txtValueCode.setText("");
        txtValueMeaning.setText("");
        txtValueDescription.setText("");
    }    
    
    private void enableExistingLookup(){
        comboExistingLookups.setEnabled(true);
        txtTypeType.setEnabled(false);
        txtTypeMeaning.setEnabled(false);
        txtTypeDescription.setEnabled(false);
        lblTypeType.setEnabled(false);
        lblTypeMeaning.setEnabled(false);
        lblTypeDescription.setEnabled(false); 
    }
    
    private void enableNewLookup(){
        comboExistingLookups.setEnabled(false);
        txtTypeType.setEnabled(true);
        txtTypeMeaning.setEnabled(true);
        txtTypeDescription.setEnabled(true);
        lblTypeType.setEnabled(true);
        lblTypeMeaning.setEnabled(true);
        lblTypeDescription.setEnabled(true);         
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgInsertLookupType;
    private javax.swing.JButton btnAddValue;
    private javax.swing.JButton btnClearList;
    private javax.swing.JButton btnDeleteFromList;
    private javax.swing.JButton btnEditValue;
    private javax.swing.JButton btnGenerate;
    private javax.swing.JButton btnSaveToFile;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JComboBox comboExistingLookups;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblTypeDescription;
    private javax.swing.JLabel lblTypeMeaning;
    private javax.swing.JLabel lblTypeType;
    private javax.swing.JList listLookupValues;
    private javax.swing.JRadioButton radioExistingLookup;
    private javax.swing.JRadioButton radioNewLookup;
    private javax.swing.JTextField txtTypeDescription;
    private javax.swing.JTextField txtTypeMeaning;
    private javax.swing.JTextField txtTypeType;
    private javax.swing.JTextField txtValueCode;
    private javax.swing.JTextField txtValueDescription;
    private javax.swing.JTextField txtValueMeaning;
    // End of variables declaration//GEN-END:variables


}

//GE Confidential