/*
  v 0.14
  - Created.
  v 0.22
  - Implemented Find functionality
*/

package lookup;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;
import util.lookup.*;

public class OracleLookupViewerIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private ArrayList<LookupTypeData> lookups;
   private StringBuffer buf;   
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;    
    
    public OracleLookupViewerIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { super(title, resizable, closable, maximizable, iconifiable);
     
    initComponents();
    
    this.getRootPane().setDefaultButton(btnSearch);

     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { OracleLookupViewerIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
      
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
     
    }
   

   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
       
    
   private void cleanClose() { 
       dispose(); 
   }

   private void protectFields()
   {
     btnSearch.setEnabled(false);
     txtType.setEditable(false);
     txtMeaning.setEditable(false);
     txtDescription.setEditable(false);
     txtCode.setEditable(false);
     comboEnvironment.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     txtType.setEditable(true);
     txtMeaning.setEditable(true);
     txtDescription.setEditable(true);
     txtCode.setEditable(true);
     comboEnvironment.setEnabled(true);
     progressBar.setVisible(false);
   }   
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtType = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtMeaning = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtDescription = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCode = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setText("Lookup:");

        jLabel3.setText("Type:");

        txtType.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeFocusGained(evt);
            }
        });

        jLabel4.setText("Meaning:");

        txtMeaning.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtMeaningFocusGained(evt);
            }
        });

        jLabel5.setText("Description:");

        txtDescription.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDescriptionFocusGained(evt);
            }
        });

        jLabel6.setText("Code:");

        txtCode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodeFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtType))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMeaning, javax.swing.GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)
                            .addComponent(txtDescription))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTypeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeFocusGained
        txtType.selectAll();
    }//GEN-LAST:event_txtTypeFocusGained

    private void txtMeaningFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtMeaningFocusGained
        txtMeaning.selectAll();
    }//GEN-LAST:event_txtMeaningFocusGained

    private void txtDescriptionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescriptionFocusGained
        txtDescription.selectAll();
    }//GEN-LAST:event_txtDescriptionFocusGained

    private void txtCodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodeFocusGained
        txtCode.selectAll();
    }//GEN-LAST:event_txtCodeFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if ( txtType.getText().isEmpty() &&
            txtMeaning.getText().isEmpty() &&
            txtDescription.getText().isEmpty() &&
            txtCode.getText().isEmpty() ) {
       editorResults.setText("Please fill at least one field.");
     } else {
         loadList();
     }
    }//GEN-LAST:event_btnSearchActionPerformed

   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         fetchLookupList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
       
   private void fetchLookupList(){
       String lookupQuery = "";
       try {
            done = false;
            protectFields();
            editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");    
            buf = new StringBuffer();
            
           conn = util.OracleConnectionManager.getConnection(getComboConnection());
                        
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            lookupQuery = "select lookup_type, lookup_code, meaning, description, enabled_flag from cs_lookups " +
                            "where \n" +
                            " 1 = 1 " + 
                            (txtType.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(lookup_type) like '%" + txtType.getText().trim().toLowerCase() + "%'" ) + 
                            (txtCode.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(lookup_code) like '%" + txtCode.getText().trim().toLowerCase() + "%'" ) + 
                            (txtDescription.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(description) like '%" + txtDescription.getText().trim().toLowerCase() + "%'" ) + 
                            (txtMeaning.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(meaning) like '%" + txtMeaning.getText().trim().toLowerCase() + "%'" ) +                 
                      " order by lookup_type asc, lookup_code asc "; 
            
            lookups = new ArrayList<>();
            prepStm = conn.prepareStatement(lookupQuery);
            rs = prepStm.executeQuery();
            LookupTypeData d;
            
            if(rs.next()){
               // Set up 
                d = new LookupTypeData(rs.getString("lookup_type")); 
                do{
                   if(!rs.getString("lookup_type").equals(d.getType())) {
                       lookups.add(d);
                       d = new LookupTypeData(rs.getString("lookup_type")); 

                   }//if new lookup                   
                   d.addValue(new LookupValueData(rs.getString("lookup_code"),
                           rs.getString("meaning"),
                           rs.getString("description"),
                           rs.getString("enabled_flag")));                   
                }while(rs.next());                
                
                lookups.add(d);
                
            } else {
               prepStm.close();
               rs.close();                
               editorResults.setText("<HTML><H2>No records found with that criteria.</H2></HTML>");
               releaseFields();
               done = true;
               return;
            }                   

            buf.append("<HTML><BODY>");
            for(LookupTypeData lt : lookups){
                buf.append("<TABLE border = 1 width=100%>"
                        + "<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>TYPE</B></TD>"
                        + "<TD colspan = 3>" + lt.getType() + "</TD>"
                        + "</TR>");
                
                buf.append("<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 20%><B>CODE</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>MEANING</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>DESCRIPTION</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>ENABLED?</B></TD>"
                        + "</TR>");
                for(LookupValueData v : lt.getValues()){
                    buf.append("<TR " + ( lt.getValues().indexOf(v) % 2 == 1 ? " bgcolor = #DDDDDD " : "" ) + ">"
                            + "<TD>" + v.getCode() + "</TD>"
                            + "<TD>" + v.getValueMeaning() + "</TD>"
                            + "<TD>" + v.getValueDescription() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + v.getValueFlag() + "</TD>"
                            + "</TR>");
                }
                buf.append("</TABLE><BR>");
            }             
            
            editorResults.setText(buf.toString());                        
            prepStm.close();
            rs.close();
            releaseFields();
            done = true;
            
       }catch(Exception e){
            buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("txtType: \"" + txtType.getText() + "\"\n");
             buf.append("txtCode: \"" + txtCode.getText() + "\"\n");
             buf.append("txtMeaning: \"" + txtMeaning.getText() + "\"\n");       
             buf.append("txtDescription: \"" + txtDescription.getText() + "\"\n");       
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Could not pull Customer details because: \n");
             buf.append(e.getMessage());
             util.JErrorLog.createErrorLog("Class: OracleLookupViewer, Method: fetchLookupList", lookupQuery + "\n\n", buf.toString());

             editorResults.setText("An Error occurred, please check the logs.");
             releaseFields();           
       }
   }
   
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }     
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtCode;
    private javax.swing.JTextField txtDescription;
    private javax.swing.JTextField txtMeaning;
    private javax.swing.JTextField txtType;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential