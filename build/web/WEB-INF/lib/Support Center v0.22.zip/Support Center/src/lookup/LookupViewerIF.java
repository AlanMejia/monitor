/*
  v 0.14
  - Created.
  v 0.22
  - Implemented Find functionality
*/

package lookup;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;
import util.lookup.*;

public class LookupViewerIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private boolean done = false;
   private ArrayList<LookupTypeData> lookups;
   private StringBuffer buf;   
   private ArrayList<Integer> findHits;
   private int hitIndex;
   private String findText;    
    
    public LookupViewerIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { super(title, resizable, closable, maximizable, iconifiable);
     
    initComponents();

     this.getRootPane().setDefaultButton(btnSearch);    
    
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { LookupViewerIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
      
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/        
          
    }
   

   private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
       
    
   private void cleanClose() { 
       dispose(); 
   }

   private void protectFields()
   {
     btnSearch.setEnabled(false);
     txtTypeID.setEditable(false);
     txtTypeType.setEditable(false);
     txtTypeMeaning.setEditable(false);
     txtTypeDescription.setEditable(false);
     txtValueCode.setEditable(false);
     txtValueDescription.setEditable(false);
     txtValueMeaning.setEditable(false);
     comboEnvironment.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     txtTypeID.setEditable(true);
     txtTypeType.setEditable(true);
     txtTypeMeaning.setEditable(true);
     txtTypeDescription.setEditable(true);
     txtValueCode.setEditable(true);
     txtValueDescription.setEditable(true);
     txtValueMeaning.setEditable(true);
     comboEnvironment.setEnabled(true);
     progressBar.setVisible(false);
   }   
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTypeID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtTypeType = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTypeMeaning = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTypeDescription = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtValueCode = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtValueMeaning = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtValueDescription = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("ID:");

        txtTypeID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeIDFocusGained(evt);
            }
        });

        jLabel2.setText("Lookup Type:");

        jLabel3.setText("Type:");

        txtTypeType.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeTypeFocusGained(evt);
            }
        });

        jLabel4.setText("Meaning:");

        txtTypeMeaning.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeMeaningFocusGained(evt);
            }
        });

        jLabel5.setText("Description:");

        txtTypeDescription.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTypeDescriptionFocusGained(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTypeType, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTypeID, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTypeMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTypeDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTypeID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4)
                    .addComponent(txtTypeMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTypeType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtTypeDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel6.setText("Code:");

        txtValueCode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueCodeFocusGained(evt);
            }
        });

        jLabel7.setText("Lookup Value:");

        jLabel9.setText("Meaning:");

        txtValueMeaning.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueMeaningFocusGained(evt);
            }
        });

        jLabel10.setText("Description:");

        txtValueDescription.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtValueDescriptionFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtValueCode, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                            .addComponent(txtValueDescription))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
                            .addComponent(txtValueMeaning))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValueCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9)
                    .addComponent(txtValueMeaning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtValueDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTypeIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeIDFocusGained
        txtTypeID.selectAll();
    }//GEN-LAST:event_txtTypeIDFocusGained

    private void txtTypeTypeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeTypeFocusGained
        txtTypeType.selectAll();
    }//GEN-LAST:event_txtTypeTypeFocusGained

    private void txtTypeMeaningFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeMeaningFocusGained
        txtTypeMeaning.selectAll();
    }//GEN-LAST:event_txtTypeMeaningFocusGained

    private void txtTypeDescriptionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTypeDescriptionFocusGained
        txtTypeDescription.selectAll();
    }//GEN-LAST:event_txtTypeDescriptionFocusGained

    private void txtValueCodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueCodeFocusGained
        txtValueCode.selectAll();
    }//GEN-LAST:event_txtValueCodeFocusGained

    private void txtValueDescriptionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueDescriptionFocusGained
        txtValueDescription.selectAll();
    }//GEN-LAST:event_txtValueDescriptionFocusGained

    private void txtValueMeaningFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtValueMeaningFocusGained
        txtValueMeaning.selectAll();
    }//GEN-LAST:event_txtValueMeaningFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if (txtTypeID.getText().isEmpty() &&
            txtTypeType.getText().isEmpty() &&
            txtTypeMeaning.getText().isEmpty() &&
            txtTypeDescription.getText().isEmpty() &&
            txtValueCode.getText().isEmpty() &&
            txtValueDescription.getText().isEmpty() &&
            txtValueMeaning.getText().isEmpty() ) {
       editorResults.setText("Please fill at least one field.");
     } else {
         loadList();
     }
    }//GEN-LAST:event_btnSearchActionPerformed

   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         fetchLookupList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
       
   private void fetchLookupList(){
       String lookupQuery = "";
       try {
            done = false;
            protectFields();
            editorResults.setText("<HTML><H2>Pulling records...</H2></HTML>");    
            buf = new StringBuffer();
            
           conn = util.OracleConnectionManager.getConnection(getComboConnection());
                        
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            lookupQuery = "select ty.lookup_type_id, ty.lookup_type, ty.type_meaning, ty.type_description, va.lookup_code, va.value_meaning, \n" +
                            "va.value_description, va.enabled_flag, va.lookup_value_id \n" +
                            "from gets_lms_lookup_types ty, gets_lms_lookup_values va\n" +
                            "where \n" +
                            " ty.lookup_type_id = va.lookup_type_id " + 
                            (txtTypeID.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(ty.lookup_type_id) like '%" + txtTypeID.getText().trim().toLowerCase() + "%'" ) + 
                            (txtTypeType.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(lookup_type) like '%" + txtTypeType.getText().trim().toLowerCase() + "%'" ) + 
                            (txtTypeMeaning.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(type_meaning) like '%" + txtTypeMeaning.getText().trim().toLowerCase() + "%'" ) + 
                            (txtTypeDescription.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(type_description) like '%" + txtTypeDescription.getText().trim().toLowerCase() + "%'" ) + 
                            (txtValueCode.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(lookup_code) like '%" + txtValueCode.getText().trim().toLowerCase() + "%'" ) + 
                            (txtValueDescription.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(value_description) like '%" + txtValueDescription.getText().trim().toLowerCase() + "%'" ) + 
                            (txtValueMeaning.getText().trim().toLowerCase().isEmpty() ? "" : 
                                  " AND lower(value_meaning) like '%" + txtValueMeaning.getText().trim().toLowerCase() + "%'" ) +                     
                      " order by ty.lookup_type asc, va.lookup_code asc";      
            lookups = new ArrayList<>();
            prepStm = conn.prepareStatement(lookupQuery);
            rs = prepStm.executeQuery();

            LookupTypeData d;
            
            if(rs.next()){
               // Set up 
                d = new LookupTypeData(rs.getString("lookup_type_id"),
                                               rs.getString("lookup_type"),
                                               rs.getString("type_meaning"),
                                               rs.getString("type_description")); 
                do{
                   if(!rs.getString("lookup_type").equals(d.getType())) {
                       lookups.add(d);
                       d = new LookupTypeData(rs.getString("lookup_type_id"),
                                               rs.getString("lookup_type"),
                                               rs.getString("type_meaning"),
                                               rs.getString("type_description"));                        
                   }//if new lookup                   
                   d.addValue(new LookupValueData(rs.getString("lookup_value_id"), 
                           rs.getString("lookup_type_id"),
                           rs.getString("lookup_code"),
                           rs.getString("value_meaning"),
                           rs.getString("value_description"),
                           rs.getString("enabled_flag")));                   
                }while(rs.next());                
                
                lookups.add(d);
                
            } else {
               prepStm.close();
               rs.close();                
               editorResults.setText("<HTML><H2>No records found with that criteria.</H2></HTML>");
               releaseFields();
               done = true;
               return;
            }                   
             
            buf.append("<HTML><BODY>");
            for(LookupTypeData lt : lookups){
                buf.append("<TABLE border = 1 width=100%>"
                        + "<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>TYPE</B></TD>"
                        + "<TD colspan = 3>" + lt.getType() + " ( " + lt.getTypeId() + " ) </TD>"
                        + "</TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>MEANING</B></TD>"
                        + "<TD colspan = 3>" + lt.getTypeMeaning() + " </TD>"
                        + "</TR>"                        
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>DESCRIPTION</B></TD>"
                        + "<TD colspan = 3>" + lt.getTypeDescription() + " </TD>"
                        + "</TR>");
                
                buf.append("<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 20%><B>CODE</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>MEANING</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>DESCRIPTION</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>ENABLED?</B></TD>"
                        + "</TR>");
                for(LookupValueData v : lt.getValues()){
                    buf.append("<TR " + ( lt.getValues().indexOf(v) % 2 == 1 ? " bgcolor = #DDDDDD " : "" ) + ">"
                            + "<TD>" + v.getCode() + "</TD>"
                            + "<TD>" + v.getValueMeaning() + "</TD>"
                            + "<TD>" + v.getValueDescription() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + v.getValueFlag() + "</TD>"
                            + "</TR>");
                }
                buf.append("</TABLE><BR>");
            }            
            
            editorResults.setText(buf.toString());                        
            prepStm.close();
            rs.close();
            releaseFields();
            done = true;
            
       }catch(Exception e){
            buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("txtTypeID: \"" + txtTypeID.getText() + "\"\n");
             buf.append("txtTypeType: \"" + txtTypeType.getText() + "\"\n");
             buf.append("txtTypeMeaning: \"" + txtTypeMeaning.getText() + "\"\n");       
             buf.append("txtTypeDescription: \"" + txtTypeDescription.getText() + "\"\n");
             buf.append("txtValueCode: \"" + txtValueCode.getText() + "\"\n");
             buf.append("txtValueDescription: \"" + txtValueDescription.getText() + "\"\n");             
             buf.append("txtValueMeaning: \"" + txtValueMeaning.getText() + "\"\n");                          
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Could not pull Customer details because: \n");
             buf.append(e.getMessage());
             util.JErrorLog.createErrorLog("Class: LookupViewerIF, Method: fetchLookupList", lookupQuery + "\n\n", buf.toString());

             editorResults.setText("An Error occurred, please check the logs.");
             releaseFields();           
       }
   }
   
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }     
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtTypeDescription;
    private javax.swing.JTextField txtTypeID;
    private javax.swing.JTextField txtTypeMeaning;
    private javax.swing.JTextField txtTypeType;
    private javax.swing.JTextField txtValueCode;
    private javax.swing.JTextField txtValueDescription;
    private javax.swing.JTextField txtValueMeaning;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential