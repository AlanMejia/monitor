/*
   v 0.19
   - Added the main "Search" Button as default button in all forms. Now the "Enter" key will default to the search action. Lovely. Look for the button with the slightly bluish hue.
   - INT DEV environment was missing in the dropdown in several forms, this has been corrected and consistently been renamed to "INT DEV".
   v 0.20
   - Removed the iconify functionality by default. There is now an "Iconify when Minimized" option under "Utilities". Yes, this was annoying, I apologize.
   - Global change: now all of the JInternalForms will dispose() on "ESC" key.
*/

package eservicesmanager;

 import customerorgs.*;
 import databaseide.MicroSQLDeveloper;
 import databaseobjects.DBObjectLookupIF;
 import dataextracts.MassiveDataExtractIF;
 import defect.*;
 import feedback.*; 
 import fmi.*;
 import java.awt.AWTException;
 import static java.awt.Frame.ICONIFIED;
 import static java.awt.Frame.MAXIMIZED_BOTH;
 import static java.awt.Frame.NORMAL;
 import java.awt.Image;
 import java.awt.MenuItem;
 import java.awt.PopupMenu;
 import java.awt.SystemTray;
 import java.awt.TrayIcon;
 import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;
 import java.awt.event.WindowEvent;
 import java.awt.event.WindowStateListener;
 import java.beans.PropertyVetoException;
 import java.util.logging.Level;
 import java.util.logging.Logger;
 import javax.swing.*;
 import loader.*;
 import locomotive.*;
 import lookup.*;
 import material.*;
import rmd.RMDServiceSheetIF;
 import servicesheet.*;
 import user.*;
 import utilities.*;
 import workorder.WOTimeAdjustIF;
 import workscope.*;

public class SupportCenter extends javax.swing.JFrame {

   private boolean doneBlockingScreen;
   private static final String VERSION = "0.22";
    
   private FeedbackTextUpdaterIF fbTextUpdater;
   private FeedbackListIF fbList;
   private UserInformationIF userInfo;
   private feedback.AgedFeedbackIF agedFeedbacks;
   private LinkCentralIF linkCentral;
   private LocomotiveInfoIF locoInfo;
   private CustomerIF customerInfo;
   private feedback.FeedbackCPTrackerUpdaterIF fbUpdater;
   private LocoDocIF locoDoc;
   private MaterialInfoIF materialInfo;
   private workorder.WorkorderIF workorderInfo;   
   private user.ResponsibilityIF respInfo;
   private user.MissingV2RespIF missing2Resp;
   private customerorgs.ServiceOrgIF serviceOrgInfo;
   private GenerateUserIF insertUser;
   private ServiceSheetInfoIF serviceSheetInfo;
   private locomotive.FleetLocoConfigIF fleetLocoConfig;
   private TaskLookupIF taskLookup;
   private utilities.CharacterCounterIF charCounter;
   private LookupViewerIF lookupViewer;
   private OracleLookupViewerIF oracleLookupViewer;   
   private LookupInsertIF lookupInsert;
   private DefectInfoIF defectLookup;
   private FeedbackSummaryIF feedbackSummary;
   private FMILookupIF fmiLookup;
   private LoaderSupportIF loaderSupport;
   private FeedbackLookupIF archivedFeedback;
   private ServiceSheetHistoryIF serviceSheetHistory;
   private MassiveDataExtractIF massiveDataExtract;
   private DefectFailReasonIF failReasonInsert;
   private DBObjectLookupIF dbObjectLookup;
   private WOTimeAdjustIF woTiming;
   private MicroSQLDeveloper microSQLDev;
   private UnitFMILookupIF unitFMILookup;
   private RMDServiceSheetIF rmdSSLookup;
      
   private util.PropertyManager pm;    
   private TrayIcon trayIcon;
   private SystemTray tray;       

    public SupportCenter() {
        initComponents();


     pm = new util.PropertyManager();
     setTitle("eServices Support Center version " + getVersion() + ", Build " + pm.getProperty(1));
     
        try {
          this.setIconImage(new ImageIcon(getClass().getResource("toolbox.png")).getImage());
        }catch(Exception e){
            e.printStackTrace();
        }     
  
        // System Tray magic!
        //Check the SystemTray is supported
        if(SystemTray.isSupported()){
            tray = SystemTray.getSystemTray();

            Image image = new ImageIcon(getClass().getResource("toolbox.png")).getImage();
            ActionListener exitListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Exiting....");
                    System.exit(0);
                }

            };
            PopupMenu popup = new PopupMenu();
            MenuItem defaultItem = new MenuItem("Exit");
            defaultItem.addActionListener(exitListener);
            popup.add(defaultItem);
            defaultItem=new MenuItem("Open");
            defaultItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(true);
                    setExtendedState(JFrame.NORMAL);
                }
            });
            popup.add(defaultItem);          
            
            trayIcon=new TrayIcon(image, "eServices Support Center", popup);
            trayIcon.setImageAutoSize(true);
                        
        }
        addWindowStateListener(new WindowStateListener() {
            public void windowStateChanged(WindowEvent e) {
                if(e.getNewState()==ICONIFIED){
                    try {
                        if(miIconify.isSelected()){
                            tray.add(trayIcon);
                            setVisible(false);         
                        }
                    } catch (AWTException ex) {
                        
                    }
                }
        if(e.getNewState()==7){
             try{
                if(miIconify.isSelected()){ 
                    tray.add(trayIcon);
                    setVisible(false);
                }
            }catch(AWTException ex){
        }
            }
        if(e.getNewState()==MAXIMIZED_BOTH){
                    tray.remove(trayIcon);
                    setVisible(true);
                    //System.out.println("Tray icon removed");
                }
                if(e.getNewState()==NORMAL){
                    tray.remove(trayIcon);
                    setVisible(true);
                    //System.out.println("Tray icon removed");
                }
            }
        });        
        
        trayIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    setVisible(true);
                    setExtendedState(JFrame.NORMAL);
                }
            }

        });
        
        
    }

   public static final String getVersion() {
     return VERSION;
   }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        desktop = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        menuFeedbacks = new javax.swing.JMenu();
        miFeedbackSummary = new javax.swing.JMenuItem();
        miFeedbackTextUpdater = new javax.swing.JMenuItem();
        miFeedbackList = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        miArchivedFeedbackLookup = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        miDateRangeReport = new javax.swing.JMenuItem();
        miAgedFeedbacks = new javax.swing.JMenuItem();
        menuFMIs = new javax.swing.JMenu();
        miFMILookup = new javax.swing.JMenuItem();
        miUnitFMILookup = new javax.swing.JMenuItem();
        menuLoaderSupport = new javax.swing.JMenu();
        miLoaderViewer = new javax.swing.JMenuItem();
        menuLocomotives = new javax.swing.JMenu();
        miLocomotiveLookup = new javax.swing.JMenuItem();
        miLocoDocLookup = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        miFleetLocoConfig = new javax.swing.JMenuItem();
        menuLookups = new javax.swing.JMenu();
        miLookupViewer = new javax.swing.JMenuItem();
        miOracleLookupViewer = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        miLookupInserter = new javax.swing.JMenuItem();
        menuDataExtracts = new javax.swing.JMenu();
        miDataExtract = new javax.swing.JMenuItem();
        menuMaterials = new javax.swing.JMenu();
        miMaterialLookup = new javax.swing.JMenuItem();
        menuObjectLookup = new javax.swing.JMenu();
        miDBObjectLookup = new javax.swing.JMenuItem();
        menuOrgCustomers = new javax.swing.JMenu();
        miCustomerLookup = new javax.swing.JMenuItem();
        miServiceOrgLookup = new javax.swing.JMenuItem();
        menuRMD = new javax.swing.JMenu();
        miRMDServiceSheet = new javax.swing.JMenuItem();
        menuUsers = new javax.swing.JMenu();
        miUserLookup = new javax.swing.JMenuItem();
        miResponsibilityLookup = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        miUserInsertGenerator = new javax.swing.JMenuItem();
        miMissing20Responsibilities = new javax.swing.JMenuItem();
        menuUtilities = new javax.swing.JMenu();
        miCloseAllWindows = new javax.swing.JMenuItem();
        miPreventScreenLock = new javax.swing.JCheckBoxMenuItem();
        miIconify = new javax.swing.JCheckBoxMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        miCharacterCounter = new javax.swing.JMenuItem();
        miLinkCentral = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        miMicroSQLDeveloper = new javax.swing.JMenuItem();
        menuWorkorders = new javax.swing.JMenu();
        miWorkorderLookup = new javax.swing.JMenuItem();
        miWOTimingAdjustment = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        miDefectLookup = new javax.swing.JMenuItem();
        miDefectFailReasonInsert = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JPopupMenu.Separator();
        miServiceSheetLookup = new javax.swing.JMenuItem();
        miLocoServiceSheet = new javax.swing.JMenuItem();
        menuWorkscopes = new javax.swing.JMenu();
        miTaskLookup = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout desktopLayout = new javax.swing.GroupLayout(desktop);
        desktop.setLayout(desktopLayout);
        desktopLayout.setHorizontalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 869, Short.MAX_VALUE)
        );
        desktopLayout.setVerticalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 576, Short.MAX_VALUE)
        );

        menuFeedbacks.setText("Feedbacks");

        miFeedbackSummary.setText("Open Feedback Summary");
        miFeedbackSummary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miFeedbackSummaryActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miFeedbackSummary);

        miFeedbackTextUpdater.setText("Feedback Text Updater");
        miFeedbackTextUpdater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miFeedbackTextUpdaterActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miFeedbackTextUpdater);

        miFeedbackList.setText("Open Feedback Detailed List");
        miFeedbackList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miFeedbackListActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miFeedbackList);
        menuFeedbacks.add(jSeparator1);

        miArchivedFeedbackLookup.setText("Feedback Search");
        miArchivedFeedbackLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miArchivedFeedbackLookupActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miArchivedFeedbackLookup);
        menuFeedbacks.add(jSeparator6);

        miDateRangeReport.setText("Date Range Report");
        miDateRangeReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miDateRangeReportActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miDateRangeReport);

        miAgedFeedbacks.setText("Open Aged Feedbacks");
        miAgedFeedbacks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAgedFeedbacksActionPerformed(evt);
            }
        });
        menuFeedbacks.add(miAgedFeedbacks);

        menuBar.add(menuFeedbacks);

        menuFMIs.setText("FMIs");

        miFMILookup.setText("FMI Lookup");
        miFMILookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miFMILookupActionPerformed(evt);
            }
        });
        menuFMIs.add(miFMILookup);

        miUnitFMILookup.setText("Loco / FMI Lookup");
        miUnitFMILookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miUnitFMILookupActionPerformed(evt);
            }
        });
        menuFMIs.add(miUnitFMILookup);

        menuBar.add(menuFMIs);

        menuLoaderSupport.setText("Loader Support");

        miLoaderViewer.setText("Loader Dashboard");
        miLoaderViewer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLoaderViewerActionPerformed(evt);
            }
        });
        menuLoaderSupport.add(miLoaderViewer);

        menuBar.add(menuLoaderSupport);

        menuLocomotives.setText("Locomotives");

        miLocomotiveLookup.setText("Locomotive Lookup");
        miLocomotiveLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLocomotiveLookupActionPerformed(evt);
            }
        });
        menuLocomotives.add(miLocomotiveLookup);

        miLocoDocLookup.setText("Locomotive Doc");
        miLocoDocLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLocoDocLookupActionPerformed(evt);
            }
        });
        menuLocomotives.add(miLocoDocLookup);
        menuLocomotives.add(jSeparator3);

        miFleetLocoConfig.setText("Fleet Loco Config Setup");
        miFleetLocoConfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miFleetLocoConfigActionPerformed(evt);
            }
        });
        menuLocomotives.add(miFleetLocoConfig);

        menuBar.add(menuLocomotives);

        menuLookups.setText("Lookups");

        miLookupViewer.setText("eServices Lookup Viewer");
        miLookupViewer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLookupViewerActionPerformed(evt);
            }
        });
        menuLookups.add(miLookupViewer);

        miOracleLookupViewer.setText("Oracle Lookup Viewer");
        miOracleLookupViewer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miOracleLookupViewerActionPerformed(evt);
            }
        });
        menuLookups.add(miOracleLookupViewer);
        menuLookups.add(jSeparator5);

        miLookupInserter.setText("eServices Lookup Insert");
        miLookupInserter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLookupInserterActionPerformed(evt);
            }
        });
        menuLookups.add(miLookupInserter);

        menuBar.add(menuLookups);

        menuDataExtracts.setText("Massive Data Extract");

        miDataExtract.setText("Massive Data Extractor");
        miDataExtract.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miDataExtractActionPerformed(evt);
            }
        });
        menuDataExtracts.add(miDataExtract);

        menuBar.add(menuDataExtracts);

        menuMaterials.setText("Materials");

        miMaterialLookup.setText("Material Lookup");
        miMaterialLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miMaterialLookupActionPerformed(evt);
            }
        });
        menuMaterials.add(miMaterialLookup);

        menuBar.add(menuMaterials);

        menuObjectLookup.setText("Object Lookup");

        miDBObjectLookup.setText("Database Object Lookup");
        miDBObjectLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miDBObjectLookupActionPerformed(evt);
            }
        });
        menuObjectLookup.add(miDBObjectLookup);

        menuBar.add(menuObjectLookup);

        menuOrgCustomers.setText("Orgs and Customers");

        miCustomerLookup.setText("Customer Lookup");
        miCustomerLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCustomerLookupActionPerformed(evt);
            }
        });
        menuOrgCustomers.add(miCustomerLookup);

        miServiceOrgLookup.setText("Service Org Lookup");
        miServiceOrgLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miServiceOrgLookupActionPerformed(evt);
            }
        });
        menuOrgCustomers.add(miServiceOrgLookup);

        menuBar.add(menuOrgCustomers);

        menuRMD.setText("RMD");

        miRMDServiceSheet.setText("RMD Service Sheet Lookup");
        miRMDServiceSheet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miRMDServiceSheetActionPerformed(evt);
            }
        });
        menuRMD.add(miRMDServiceSheet);

        menuBar.add(menuRMD);

        menuUsers.setText("Users");

        miUserLookup.setText("User Lookup");
        miUserLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miUserLookupActionPerformed(evt);
            }
        });
        menuUsers.add(miUserLookup);

        miResponsibilityLookup.setText("Responsibility Lookup");
        miResponsibilityLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miResponsibilityLookupActionPerformed(evt);
            }
        });
        menuUsers.add(miResponsibilityLookup);
        menuUsers.add(jSeparator2);

        miUserInsertGenerator.setText("User Insert Script Generator");
        miUserInsertGenerator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miUserInsertGeneratorActionPerformed(evt);
            }
        });
        menuUsers.add(miUserInsertGenerator);

        miMissing20Responsibilities.setText("Users Missing 2.0 Responsibilities");
        miMissing20Responsibilities.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miMissing20ResponsibilitiesActionPerformed(evt);
            }
        });
        menuUsers.add(miMissing20Responsibilities);

        menuBar.add(menuUsers);

        menuUtilities.setText("Utilities");

        miCloseAllWindows.setText("Close All Windows");
        miCloseAllWindows.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCloseAllWindowsActionPerformed(evt);
            }
        });
        menuUtilities.add(miCloseAllWindows);

        miPreventScreenLock.setText("Prevent Screen from Locking");
        miPreventScreenLock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miPreventScreenLockActionPerformed(evt);
            }
        });
        menuUtilities.add(miPreventScreenLock);

        miIconify.setText("Iconify when Minimized");
        miIconify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miIconifyActionPerformed(evt);
            }
        });
        menuUtilities.add(miIconify);
        menuUtilities.add(jSeparator4);

        miCharacterCounter.setText("Character Counter");
        miCharacterCounter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCharacterCounterActionPerformed(evt);
            }
        });
        menuUtilities.add(miCharacterCounter);

        miLinkCentral.setText("Link Central");
        miLinkCentral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLinkCentralActionPerformed(evt);
            }
        });
        menuUtilities.add(miLinkCentral);
        menuUtilities.add(jSeparator7);

        miMicroSQLDeveloper.setText("Micro SQL Developer");
        miMicroSQLDeveloper.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miMicroSQLDeveloperActionPerformed(evt);
            }
        });
        menuUtilities.add(miMicroSQLDeveloper);

        menuBar.add(menuUtilities);

        menuWorkorders.setText("Workorders");

        miWorkorderLookup.setText("Workorder Lookup");
        miWorkorderLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miWorkorderLookupActionPerformed(evt);
            }
        });
        menuWorkorders.add(miWorkorderLookup);

        miWOTimingAdjustment.setText("WO Timing Adjustment");
        miWOTimingAdjustment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miWOTimingAdjustmentActionPerformed(evt);
            }
        });
        menuWorkorders.add(miWOTimingAdjustment);
        menuWorkorders.add(jSeparator8);

        miDefectLookup.setText("Defect Lookup");
        miDefectLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miDefectLookupActionPerformed(evt);
            }
        });
        menuWorkorders.add(miDefectLookup);

        miDefectFailReasonInsert.setText("Defect Fail Reason Insert");
        miDefectFailReasonInsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miDefectFailReasonInsertActionPerformed(evt);
            }
        });
        menuWorkorders.add(miDefectFailReasonInsert);
        menuWorkorders.add(jSeparator9);

        miServiceSheetLookup.setText("Service Sheet Lookup");
        miServiceSheetLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miServiceSheetLookupActionPerformed(evt);
            }
        });
        menuWorkorders.add(miServiceSheetLookup);

        miLocoServiceSheet.setText("Service Sheet History");
        miLocoServiceSheet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miLocoServiceSheetActionPerformed(evt);
            }
        });
        menuWorkorders.add(miLocoServiceSheet);

        menuBar.add(menuWorkorders);

        menuWorkscopes.setText("Workscopes");

        miTaskLookup.setText("Task Lookup");
        miTaskLookup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miTaskLookupActionPerformed(evt);
            }
        });
        menuWorkscopes.add(miTaskLookup);

        menuBar.add(menuWorkscopes);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void miFeedbackListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miFeedbackListActionPerformed
        openFeedbackList();
    }//GEN-LAST:event_miFeedbackListActionPerformed

    private void miFeedbackTextUpdaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miFeedbackTextUpdaterActionPerformed
        openFeedbackTextUpdater();
    }//GEN-LAST:event_miFeedbackTextUpdaterActionPerformed

    private void miDateRangeReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miDateRangeReportActionPerformed
        openFeedbackDateRangeReport();
    }//GEN-LAST:event_miDateRangeReportActionPerformed

    private void miAgedFeedbacksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miAgedFeedbacksActionPerformed
        openAgedFeedbackList();
    }//GEN-LAST:event_miAgedFeedbacksActionPerformed

    private void miWorkorderLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miWorkorderLookupActionPerformed
        openWOInfo();
    }//GEN-LAST:event_miWorkorderLookupActionPerformed

    private void miServiceSheetLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miServiceSheetLookupActionPerformed
        openServiceSheetInfo();
    }//GEN-LAST:event_miServiceSheetLookupActionPerformed

    private void miTaskLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miTaskLookupActionPerformed
        openTaskLookup();
    }//GEN-LAST:event_miTaskLookupActionPerformed

    private void miUserLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miUserLookupActionPerformed
        openUserInfo();
    }//GEN-LAST:event_miUserLookupActionPerformed

    private void miResponsibilityLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miResponsibilityLookupActionPerformed
        openRespInfo();
    }//GEN-LAST:event_miResponsibilityLookupActionPerformed

    private void miUserInsertGeneratorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miUserInsertGeneratorActionPerformed
        openInsertUser();
    }//GEN-LAST:event_miUserInsertGeneratorActionPerformed

    private void miMissing20ResponsibilitiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miMissing20ResponsibilitiesActionPerformed
        openMissing2Responsibilities();
    }//GEN-LAST:event_miMissing20ResponsibilitiesActionPerformed

    private void miLocomotiveLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLocomotiveLookupActionPerformed
        openLocoInfo();
    }//GEN-LAST:event_miLocomotiveLookupActionPerformed

    private void miLocoDocLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLocoDocLookupActionPerformed
        openLocoDoc();
    }//GEN-LAST:event_miLocoDocLookupActionPerformed

    private void miFleetLocoConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miFleetLocoConfigActionPerformed
        openFleetLocoConfig();
    }//GEN-LAST:event_miFleetLocoConfigActionPerformed

    private void miCustomerLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miCustomerLookupActionPerformed
        openCustomerInfo();
    }//GEN-LAST:event_miCustomerLookupActionPerformed

    private void miServiceOrgLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miServiceOrgLookupActionPerformed
        openServiceOrgInfo();
    }//GEN-LAST:event_miServiceOrgLookupActionPerformed

    private void miCloseAllWindowsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miCloseAllWindowsActionPerformed
        JInternalFrame[] frames = desktop.getAllFrames();
        for (int i = 0; i < frames.length; i++)
          frames[i].dispose();
    }//GEN-LAST:event_miCloseAllWindowsActionPerformed

    private void miPreventScreenLockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miPreventScreenLockActionPerformed
        validateScreenBlock();
    }//GEN-LAST:event_miPreventScreenLockActionPerformed

    private void miLinkCentralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLinkCentralActionPerformed
        openLinkCentral();
    }//GEN-LAST:event_miLinkCentralActionPerformed

    private void miCharacterCounterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miCharacterCounterActionPerformed
        countCharacters();
    }//GEN-LAST:event_miCharacterCounterActionPerformed

    private void miLookupViewerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLookupViewerActionPerformed
        openLookupViewer();
    }//GEN-LAST:event_miLookupViewerActionPerformed

    private void miOracleLookupViewerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miOracleLookupViewerActionPerformed
        openOracleLookupViewer();
    }//GEN-LAST:event_miOracleLookupViewerActionPerformed

    private void miLookupInserterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLookupInserterActionPerformed
        openLookupInsert();
    }//GEN-LAST:event_miLookupInserterActionPerformed

    private void miDefectLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miDefectLookupActionPerformed
        openDefectLookup();
    }//GEN-LAST:event_miDefectLookupActionPerformed

    private void miFeedbackSummaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miFeedbackSummaryActionPerformed
        openFeedbackSummary();
    }//GEN-LAST:event_miFeedbackSummaryActionPerformed

    private void miMaterialLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miMaterialLookupActionPerformed
        openMaterialInfo();
    }//GEN-LAST:event_miMaterialLookupActionPerformed

    private void miFMILookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miFMILookupActionPerformed
        openFMILookup();
    }//GEN-LAST:event_miFMILookupActionPerformed

    private void miLoaderViewerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLoaderViewerActionPerformed
        openLoaderViewer();
    }//GEN-LAST:event_miLoaderViewerActionPerformed

    private void miArchivedFeedbackLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miArchivedFeedbackLookupActionPerformed
        openArchivedFeedback();
    }//GEN-LAST:event_miArchivedFeedbackLookupActionPerformed

    private void miLocoServiceSheetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miLocoServiceSheetActionPerformed
        openServiceSheetHistory();
    }//GEN-LAST:event_miLocoServiceSheetActionPerformed

    private void miDataExtractActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miDataExtractActionPerformed
        openMassiveDataExtract();
    }//GEN-LAST:event_miDataExtractActionPerformed

    private void miDefectFailReasonInsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miDefectFailReasonInsertActionPerformed
        openDefectFailReasonInsert();
    }//GEN-LAST:event_miDefectFailReasonInsertActionPerformed

    private void miDBObjectLookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miDBObjectLookupActionPerformed
        openDBObjectLookupIF();
    }//GEN-LAST:event_miDBObjectLookupActionPerformed

    private void miIconifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miIconifyActionPerformed
        //Not needed.
    }//GEN-LAST:event_miIconifyActionPerformed

    private void miWOTimingAdjustmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miWOTimingAdjustmentActionPerformed
        openWOTimingAdjustment();
    }//GEN-LAST:event_miWOTimingAdjustmentActionPerformed

    private void miMicroSQLDeveloperActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miMicroSQLDeveloperActionPerformed
        openMicroSQLDeveloper();
    }//GEN-LAST:event_miMicroSQLDeveloperActionPerformed

    private void miUnitFMILookupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miUnitFMILookupActionPerformed
        openUnitFMILookup();
    }//GEN-LAST:event_miUnitFMILookupActionPerformed

    private void miRMDServiceSheetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miRMDServiceSheetActionPerformed
        openRMDSSLookup();
    }//GEN-LAST:event_miRMDServiceSheetActionPerformed

  private void openRMDSSLookup(){
     rmdSSLookup = new RMDServiceSheetIF(desktop, "RMD Service Sheet Lookup", true, true, true, true);
     rmdSSLookup.setVisible(true);
     desktop.add(rmdSSLookup);
     try { 
       rmdSSLookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}      
  }            
    
  private void openUnitFMILookup(){
     unitFMILookup = new UnitFMILookupIF(desktop, "Locomotive - FMI Lookup", true, true, true, true);
     unitFMILookup.setVisible(true);
     desktop.add(unitFMILookup);
     try { 
       unitFMILookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}      
  }
    
  private void openMicroSQLDeveloper() {
     microSQLDev = new MicroSQLDeveloper(desktop, "Micro SQL Developer", true, true, true, true);
     microSQLDev.setVisible(true);
     desktop.add(microSQLDev);
     try { 
       microSQLDev.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }     
    
  private void openWOTimingAdjustment() {
     woTiming = new WOTimeAdjustIF(desktop, "Workorder Timing Adjustment", false, true, false, true);
     woTiming.setVisible(true);
     desktop.add(woTiming);
     try { 
       woTiming.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }          
        
  private void openDBObjectLookupIF() {
     dbObjectLookup = new DBObjectLookupIF(desktop, "Database Object Lookup", true, true, true, true);
     dbObjectLookup.setVisible(true);
     desktop.add(dbObjectLookup);
     try { 
       dbObjectLookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }            
    
  private void openDefectFailReasonInsert() {
     failReasonInsert = new DefectFailReasonIF(desktop, "Defect Fail Reason Insert Generator", false, true, false, true);
     failReasonInsert.setVisible(true);
     desktop.add(failReasonInsert);
     try { 
       failReasonInsert.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }         
    
  private void openMassiveDataExtract() {
     massiveDataExtract = new MassiveDataExtractIF(desktop, "Massive Data Extractor", true, true, true, true);
     massiveDataExtract.setVisible(true);
     desktop.add(massiveDataExtract);
     try { 
       massiveDataExtract.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }        
    
  private void openServiceSheetHistory() {
     serviceSheetHistory = new ServiceSheetHistoryIF(desktop, "Service Sheet History Search", true, true, true, true);
     serviceSheetHistory.setVisible(true);
     desktop.add(serviceSheetHistory);
     try { 
       serviceSheetHistory.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }          
    
  private void openArchivedFeedback() {
     archivedFeedback = new FeedbackLookupIF(desktop, "Feedback Search", true, true, true, true);
     archivedFeedback.setVisible(true);
     desktop.add(archivedFeedback);
     try { 
       archivedFeedback.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }      
    
  private void openLoaderViewer() {
     loaderSupport = new LoaderSupportIF(desktop, this, "Loader Support Dashboard", true, true, true, true);
     loaderSupport.setVisible(true);
     desktop.add(loaderSupport);
     try { 
       loaderSupport.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }      
    
  private void openFMILookup() {
     fmiLookup = new FMILookupIF(desktop, this, "FMI Lookup", true, true, true, true);
     fmiLookup.setVisible(true);
     desktop.add(fmiLookup);
     try { 
       fmiLookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }    
    
  private void openFeedbackSummary() {
     feedbackSummary = new FeedbackSummaryIF(desktop, "Feedback Summary", true, true, true, true);
     feedbackSummary.setVisible(true);
     desktop.add(feedbackSummary);
     try { 
       feedbackSummary.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }   
    
 private void openDefectLookup() {
     defectLookup = new DefectInfoIF(desktop, "Defect Information Lookup", true, true, true, true);
     defectLookup.setVisible(true);
     desktop.add(defectLookup);
     try { 
       defectLookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }     
    
  private void openLookupInsert() {
     lookupInsert = new LookupInsertIF(desktop, "eServices Lookup Insert Generator", true, true, false, true);
     lookupInsert.setVisible(true);
     desktop.add(lookupInsert);
     try {
       lookupInsert.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }    
        
    
   private void openOracleLookupViewer() {
     oracleLookupViewer = new OracleLookupViewerIF(desktop, "Oracle Lookup Type/Value Viewer", true, true, true, true);
     oracleLookupViewer.setVisible(true);
     desktop.add(oracleLookupViewer);
     try {
       oracleLookupViewer.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }    
       
    
   private void openLookupViewer() {
     lookupViewer = new LookupViewerIF(desktop, "Lookup Type/Value Viewer", true, true, true, true);
     lookupViewer.setVisible(true);
     desktop.add(lookupViewer);
     try {
       lookupViewer.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }    
   
   private void countCharacters() {
     charCounter = new utilities.CharacterCounterIF(desktop, "Character Counter", false, true, false, true);
     charCounter.setVisible(true);
     desktop.add(charCounter);
     try {
       charCounter.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }
   
   private void openTaskLookup() {
     taskLookup = new TaskLookupIF(desktop, "Task Information Lookup", true, true, true, true);
     taskLookup.setVisible(true);
     desktop.add(taskLookup);
     try {
       taskLookup.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }
   
   private void openFleetLocoConfig() {
     fleetLocoConfig = new FleetLocoConfigIF(desktop, "Fleet Setup - New Locomotive Config Values", true, true, true, true);
     fleetLocoConfig.setVisible(true);
     desktop.add(fleetLocoConfig);
     try {
       fleetLocoConfig.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openLinkCentral() {
     linkCentral = new LinkCentralIF(desktop, "Link Central", true, true, false, true);
     linkCentral.setVisible(true);
     desktop.add(linkCentral);
     try {
       linkCentral.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openServiceSheetInfo() {
     serviceSheetInfo = new ServiceSheetInfoIF(desktop, "Service Sheet Lookup", true, true, true, true);
     serviceSheetInfo.setVisible(true);
     desktop.add(serviceSheetInfo);
     try {
       serviceSheetInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openAgedFeedbackList() {
     agedFeedbacks = new feedback.AgedFeedbackIF(desktop, "Aged Feedback listing", true, true, true, true);
     agedFeedbacks.setVisible(true);
     desktop.add(agedFeedbacks);
     try {
       agedFeedbacks.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   /************************************** SCREEN BLOCKING **********************************/
   private void validateScreenBlock(){
     if (miPreventScreenLock.isSelected()) {
       doneBlockingScreen = false;
       preventScreenBlock();
     } else {
       doneBlockingScreen = true;
     }       
   }
   
   private void preventScreenBlock() {
     new Thread(new Runnable() {
       public void run() {
         while (!doneBlockingScreen) {
           try {
             java.awt.PointerInfo a = java.awt.MouseInfo.getPointerInfo();
             java.awt.Point b = a.getLocation();
             
             java.awt.Robot robot = new java.awt.Robot();
             robot.mouseMove((int)b.getX(), (int)b.getY());
             Thread.sleep(60000L);
           } catch (Exception e) {}
         }
       }
     }).start();
   }
   /************************************** SCREEN BLOCKING **********************************/
   
   private void openServiceOrgInfo() {
     serviceOrgInfo = new customerorgs.ServiceOrgIF(desktop, "Service Organization Information", true, true, false, true);
     serviceOrgInfo.setVisible(true);
     desktop.add(serviceOrgInfo);
     try {
       serviceOrgInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openInsertUser() {
     insertUser = new GenerateUserIF(desktop, "Insert User Script Generator", true, true, false, true);
     insertUser.setVisible(true);
     desktop.add(insertUser);
     try {
       insertUser.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openCustomerInfo() {
     customerInfo = new CustomerIF(desktop, "Customer Information", true, true, false, true);
     customerInfo.setVisible(true);
     desktop.add(customerInfo);
     try {
       customerInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openMissing2Responsibilities() {
     missing2Resp = new user.MissingV2RespIF(desktop, "Users Missing 2.0 responsibilities", true, true, false, true);
     missing2Resp.setVisible(true);
     desktop.add(missing2Resp);
     try {
       missing2Resp.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openMaterialInfo() {
     materialInfo = new MaterialInfoIF(desktop, "Material Information", true, true, true, true);
     materialInfo.setVisible(true);
     desktop.add(materialInfo);
     try {
       materialInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openUserInfo() {
     userInfo = new UserInformationIF(desktop, "User Information", true, true, true, true);
     userInfo.setVisible(true);
     desktop.add(userInfo);
     try {
       userInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openLocoInfo() {
     locoInfo = new LocomotiveInfoIF(desktop, "Locomotive Information", true, true, true, true);
     locoInfo.setVisible(true);
     desktop.add(locoInfo);
     try {
       locoInfo.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openLocoDoc() {
     locoDoc = new LocoDocIF(desktop, "Locomotive History Reporter", true, true, true, true);
     locoDoc.setVisible(true);
     desktop.add(locoDoc);
     try {
       locoDoc.setSelected(true);
     }
     catch (PropertyVetoException e) {}
   }
   
   private void openFeedbackDateRangeReport() {
     fbUpdater = new feedback.FeedbackCPTrackerUpdaterIF(desktop, "Date Range Report", false, true, false, true);
     fbUpdater.setVisible(true);
     desktop.add(fbUpdater);
     try {
       fbUpdater.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openFeedbackList() {
     fbList = new FeedbackListIF(desktop, "Feedback List (Press F5 to refresh)", true, true, true, true);
     fbList.setVisible(true);
     desktop.add(fbList);
     try {
       fbList.setSelected(true);
     } catch (PropertyVetoException e) {}
   }
   
   private void openFeedbackTextUpdater() {
     fbTextUpdater = new FeedbackTextUpdaterIF(desktop, "Feedback Text Updater", false, true, false, true);
     fbTextUpdater.setVisible(true);
     desktop.add(fbTextUpdater);
     try {
       fbTextUpdater.setSelected(true);
     }
     catch (Exception e) {}
   }
   
   private void openWOInfo() {
     workorderInfo = new workorder.WorkorderIF(desktop, this, "Workorder Information", true, true, true, true);
     workorderInfo.setVisible(true);
     desktop.add(workorderInfo);
     try {
       workorderInfo.setSelected(true);
     } catch (Exception e) {}
   }   
   
   private void openRespInfo() {
     respInfo = new user.ResponsibilityIF(desktop, "Responsibility Information", true, true, true, true);
     respInfo.setVisible(true);
     desktop.add(respInfo);
     try {
       respInfo.setSelected(true);
     } catch (Exception e) {}
   }
   
   public void cleanClose() {
     System.exit(0);
   }
   
   public void addWindow(JInternalFrame j) {
     j.setVisible(true);
     desktop.add(j);
   }
       
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SupportCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SupportCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SupportCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SupportCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SupportCenter().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktop;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JPopupMenu.Separator jSeparator9;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuDataExtracts;
    private javax.swing.JMenu menuFMIs;
    private javax.swing.JMenu menuFeedbacks;
    private javax.swing.JMenu menuLoaderSupport;
    private javax.swing.JMenu menuLocomotives;
    private javax.swing.JMenu menuLookups;
    private javax.swing.JMenu menuMaterials;
    private javax.swing.JMenu menuObjectLookup;
    private javax.swing.JMenu menuOrgCustomers;
    private javax.swing.JMenu menuRMD;
    private javax.swing.JMenu menuUsers;
    private javax.swing.JMenu menuUtilities;
    private javax.swing.JMenu menuWorkorders;
    private javax.swing.JMenu menuWorkscopes;
    private javax.swing.JMenuItem miAgedFeedbacks;
    private javax.swing.JMenuItem miArchivedFeedbackLookup;
    private javax.swing.JMenuItem miCharacterCounter;
    private javax.swing.JMenuItem miCloseAllWindows;
    private javax.swing.JMenuItem miCustomerLookup;
    private javax.swing.JMenuItem miDBObjectLookup;
    private javax.swing.JMenuItem miDataExtract;
    private javax.swing.JMenuItem miDateRangeReport;
    private javax.swing.JMenuItem miDefectFailReasonInsert;
    private javax.swing.JMenuItem miDefectLookup;
    private javax.swing.JMenuItem miFMILookup;
    private javax.swing.JMenuItem miFeedbackList;
    private javax.swing.JMenuItem miFeedbackSummary;
    private javax.swing.JMenuItem miFeedbackTextUpdater;
    private javax.swing.JMenuItem miFleetLocoConfig;
    private javax.swing.JCheckBoxMenuItem miIconify;
    private javax.swing.JMenuItem miLinkCentral;
    private javax.swing.JMenuItem miLoaderViewer;
    private javax.swing.JMenuItem miLocoDocLookup;
    private javax.swing.JMenuItem miLocoServiceSheet;
    private javax.swing.JMenuItem miLocomotiveLookup;
    private javax.swing.JMenuItem miLookupInserter;
    private javax.swing.JMenuItem miLookupViewer;
    private javax.swing.JMenuItem miMaterialLookup;
    private javax.swing.JMenuItem miMicroSQLDeveloper;
    private javax.swing.JMenuItem miMissing20Responsibilities;
    private javax.swing.JMenuItem miOracleLookupViewer;
    private javax.swing.JCheckBoxMenuItem miPreventScreenLock;
    private javax.swing.JMenuItem miRMDServiceSheet;
    private javax.swing.JMenuItem miResponsibilityLookup;
    private javax.swing.JMenuItem miServiceOrgLookup;
    private javax.swing.JMenuItem miServiceSheetLookup;
    private javax.swing.JMenuItem miTaskLookup;
    private javax.swing.JMenuItem miUnitFMILookup;
    private javax.swing.JMenuItem miUserInsertGenerator;
    private javax.swing.JMenuItem miUserLookup;
    private javax.swing.JMenuItem miWOTimingAdjustment;
    private javax.swing.JMenuItem miWorkorderLookup;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential