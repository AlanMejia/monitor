 package utilities;
 
 import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
 import java.io.File;
 import java.net.URI;
 import java.sql.Connection;
 import java.sql.PreparedStatement;
import javax.swing.AbstractAction;
import javax.swing.Action;
 import javax.swing.GroupLayout;
 import javax.swing.GroupLayout.Alignment;
 import javax.swing.GroupLayout.ParallelGroup;
 import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.JComponent;
 import javax.swing.JDesktopPane;
 import javax.swing.JEditorPane;
 import javax.swing.JInternalFrame;
 import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
 import javax.swing.event.HyperlinkEvent;
 import javax.swing.event.HyperlinkListener;
import javax.swing.event.InternalFrameEvent;
 
 public class LinkCentralIF extends JInternalFrame
 {
   private util.workorder.WorkorderData wo;
   private Connection conn;
   private PreparedStatement prepStm;
   private java.sql.ResultSet rs;
   private boolean done = false;
   private StringBuffer buf;
   private int environment;
   private JEditorPane editorResults;
   private JScrollPane jScrollPane1;
   
   public LinkCentralIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { super(title, resizable, closable, maximizable, iconifiable);
     this.environment = this.environment;
     
     initComponents();
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { LinkCentralIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     try {
       setSelected(true);
     }
     catch (Exception e) {}
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
     loadLinks();
   }
   
   private void cleanClose() {
     dispose();
   }
   
   private void loadLinks() {
     try {
       File file = new File("ExternalDocs\\Links\\eServicesLinks.htm");
       this.editorResults.setPage(file.toURI().toURL());
     }
     catch (Exception e) {}
   }
   
 
 
 
 
 
 
 
   private void initComponents()
   {
     this.jScrollPane1 = new JScrollPane();
     this.editorResults = new JEditorPane();
     
     setDefaultCloseOperation(2);
     
     this.editorResults.setEditable(false);
     this.editorResults.setContentType("text/html");
     this.editorResults.addHyperlinkListener(new HyperlinkListener() {
       public void hyperlinkUpdate(HyperlinkEvent evt) {
         LinkCentralIF.this.editorResultsHyperlinkUpdate(evt);
       }
     });
     this.jScrollPane1.setViewportView(this.editorResults);
     
     GroupLayout layout = new GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 473, 32767));
     
 
 
     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane1, -2, 545, -2).addGap(0, 0, 32767)));
     
 
 
 
 
 
     pack();
   }
   
   private void editorResultsHyperlinkUpdate(HyperlinkEvent evt) {
     if (evt.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
       try {
         Desktop.getDesktop().browse(new URI(evt.getURL().toString()));
       } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(this, "Could not open browser, reason:\n" + e.getMessage(), "Error!", 0);
       }
     }
   }
 }


//GE Confidential