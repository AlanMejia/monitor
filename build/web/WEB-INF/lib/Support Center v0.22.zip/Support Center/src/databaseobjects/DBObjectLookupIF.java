/*
 v 0.20
 - Added.
 */

package databaseobjects;

import customerorgs.CustomerIF;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.OracleConnectionManager;

public class DBObjectLookupIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private boolean done = false;
    private StringBuffer buf = new StringBuffer();
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;    
 
    public DBObjectLookupIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){
        
        super(title, resizable, closable, maximizable, iconifiable);                
        initComponents();
        
        lblTableName.setVisible(false);
        txtTableName.setVisible(false);
        
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
                
        this.getRootPane().setDefaultButton(btnSearch);
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { DBObjectLookupIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } ); 
    
      progressBar.setVisible(false);
      
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/      
    }

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
    private void cleanClose() {     
      dispose();
    }    

    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            case 3: 
                return OracleConnectionManager.INT_DEV;                
            default:
                return OracleConnectionManager.PROD;
        }
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        comboEnvironment = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        comboType = new javax.swing.JComboBox();
        btnSearch = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtOwner = new javax.swing.JTextField();
        lblTableName = new javax.swing.JLabel();
        txtTableName = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNameFocusGained(evt);
            }
        });

        jLabel1.setText("Name:");

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        jLabel3.setText("Type:");

        comboType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "TABLE", "COLUMN", "VIEW", "SEQUENCE" }));
        comboType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTypeActionPerformed(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        jLabel2.setText("Owner:");

        txtOwner.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtOwnerFocusGained(evt);
            }
        });

        lblTableName.setText("Table:");

        txtTableName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTableNameFocusGained(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtOwner, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboType, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTableName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTableName)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(comboType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(txtOwner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblTableName)
                        .addComponent(txtTableName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 513, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        if(txtName.getText().trim().isEmpty() && txtOwner.getText().trim().isEmpty()) {
            if("COLUMN".equals((String)comboType.getSelectedItem()) && txtTableName.getText().trim().isEmpty()){
                editorResults.setText("Please fill at least one field.");
                return;
            } else {
                loadList();
            }           
        }
        else {
            loadList();
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void comboTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTypeActionPerformed
        if("COLUMN".equals((String)comboType.getSelectedItem())){
            lblTableName.setVisible(true);
            txtTableName.setVisible(true);
        } else {
            lblTableName.setVisible(false);
            txtTableName.setVisible(false); 
            txtTableName.setText("");
        }
    }//GEN-LAST:event_comboTypeActionPerformed

    private void txtNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNameFocusGained
        txtName.selectAll();
    }//GEN-LAST:event_txtNameFocusGained

    private void txtOwnerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtOwnerFocusGained
        txtOwner.selectAll();
    }//GEN-LAST:event_txtOwnerFocusGained

    private void txtTableNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTableNameFocusGained
        txtTableName.selectAll();
    }//GEN-LAST:event_txtTableNameFocusGained

    private void loadList(){
        new Thread(new Runnable() {
          public void run() {        
            fetchDBObjectList();
            while (!done)
              try {
                Thread.sleep(100L);
              }
              catch (InterruptedException ie) {
              }
          }
        }).start();        
    }

    private void fetchDBObjectList(){
        
       try {
        done = false;
        protectFields();
        editorResults.setText("");
        buf = new StringBuffer();              
 
        conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
        if (conn == null) {
          editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
          releaseFields();
          return;
        }
       
        prepStm = conn.prepareStatement(getObjectQuery());
        rs = prepStm.executeQuery();        
        
        if(rs.next()){
            
            editorResults.setText(printResults(rs));
            releaseFields();
            
        } else {
            editorResults.setText("No records found with this criteria.");       
            releaseFields();
            return;            
        }
        }catch(Exception e){
            buf = new StringBuffer("");
            buf.append("-- Fields --\n");
            buf.append("txtName: \"" + txtName.getText() + "\"\n");
            buf.append("txtOwner: \"" + txtOwner.getText() + "\"\n");
            buf.append("txtTableName: \"" + txtTableName.getText() + "\"\n");
            buf.append("Environment: " + getComboConnection() + "\"\n");
            buf.append("-- Exception --\n");
            buf.append("Exception info:" + e.getMessage());
            util.JErrorLog.createErrorLog("Class: DBObjectLookupIF, Method: fetchObjectList ", getObjectQuery(), buf.toString());                   
            releaseFields();            
            editorResults.setText("An Error occurred, please check the logs.");
        }
        
    }
    
    private String printResults(ResultSet rs){
        StringBuffer buf = new StringBuffer();
        int row = 0;
        try {
            switch((String)comboType.getSelectedItem()){
                case "TABLE":
                    row = 0;
                    buf.append("<HTML><TABLE width=100%>");
                    buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\" colspan=2><B>ALL_TABLES QUERY</B></TD></TR>"
                     + "<TR bgcolor=\"#92CDDC\">"
                     + "<TD align=\"center\"><B>Owner</B></TD>"
                     + "<TD align=\"center\"><B>Table Name</B></TD>"
                     + "</TR>");
                     do{
                        buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">") +                  
                        "<TD align=\"center\">" + rs.getString("owner") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("table_name") + "</TD>" + 
                        "</TR>");
                        row++;
                     }while(rs.next());
                     buf.append("</TABLE></HTML>");
                    return buf.toString();

                case "COLUMN":
                    row = 0;
                    buf.append("<HTML><TABLE width=100%>");
                    buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\" colspan=5><B>ALL_TAB_COLUMNS QUERY</B></TD></TR>"
                     + "<TR bgcolor=\"#92CDDC\">"
                     + "<TD align=\"center\"><B>Column Name</B></TD>"
                     + "<TD align=\"center\"><B>Table Name</B></TD>"
                     + "<TD align=\"center\"><B>Owner</B></TD>"
                     + "<TD align=\"center\"><B>Data Type</B></TD>"
                     + "<TD align=\"center\"><B>Data Length</B></TD>"                            
                     + "</TR>");
                     do{
                        buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">") +                  
                        "<TD align=\"center\">" + rs.getString("column_name") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("table_name") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("owner") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("data_type") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("data_length") + "</TD>" +                                 
                        "</TR>");
                        row++;
                     }while(rs.next());
                     buf.append("</TABLE></HTML>");
                    return buf.toString();                    

                case "VIEW":
                    row = 0;
                    buf.append("<HTML><TABLE width=100% >");
                    buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\" colspan=3><B>ALL_VIEWS QUERY</B></TD></TR>"
                     + "<TR bgcolor=\"#92CDDC\">"
                     + "<TD align=\"center\"><B>View Name</B></TD>"                     
                     + "<TD align=\"center\"><B>Owner</B></TD>"
                     + "<TD align=\"center\"><B>Text</B></TD>"
                     + "</TR>");
                     do{
                        buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">") +                  
                        "<TD align=\"center\">" + rs.getString("view_name") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("owner") + "</TD>" + 
                        "<TD ><PRE>" + rs.getString("text") + "</PRE></TD>" + 
                        "</TR>");
                        row++;
                     }while(rs.next());
                     buf.append("</TABLE></HTML>");                    
                    return buf.toString();   

                case "SEQUENCE":
                    row = 0;
                    buf.append("<HTML><TABLE width=100% >");
                    buf.append("<TR bgcolor=\"#92CDDC\"><TD align=\"center\" colspan=3><B>ALL_SEQUENCE QUERY</B></TD></TR>"
                     + "<TR bgcolor=\"#92CDDC\">"
                     + "<TD align=\"center\"><B>Sequence Name</B></TD>"                     
                     + "<TD align=\"center\"><B>Owner</B></TD>"
                     + "<TD align=\"center\"><B>Last Number</B></TD>"
                     + "</TR>");
                     do{
                        buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">") +                  
                        "<TD align=\"center\">" + rs.getString("sequence_name") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("sequence_owner") + "</TD>" + 
                        "<TD align=\"center\">" + rs.getString("last_number") + "</TD>" + 
                        "</TR>");
                        row++;
                     }while(rs.next());
                     buf.append("</TABLE></HTML>");                    
                     return buf.toString();                     
 
                default:
                    return "An error occurred, please check the logs.";

            }        
        }catch(Exception e){
            buf = new StringBuffer("");
            buf.append("-- Fields --\n");
            buf.append("txtName: \"" + txtName.getText() + "\"\n");
            buf.append("txtOwner: \"" + txtOwner.getText() + "\"\n");
            buf.append("txtTableName: \"" + txtTableName.getText() + "\"\n");
            buf.append("Environment: " + getComboConnection() + "\"\n");
            buf.append("-- Exception --\n");
            buf.append("Exception info:" + e.getMessage());
            util.JErrorLog.createErrorLog("Class: DBObjectLookupIF, Method: fetchObjectList ", getObjectQuery(), buf.toString());                   
            releaseFields();              
        }
        
        return  "An error occurred, please check the logs.";
    }
    
    private String getObjectQuery(){
        
        switch((String)comboType.getSelectedItem()){
            case "TABLE":
                return "select owner, table_name from all_tables where 1=1 " +
                        (txtName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(table_name) like '%").append(txtName.getText().trim().toLowerCase()).append("%'").toString()) + 
                        (txtOwner.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(owner) like '%").append(txtOwner.getText().trim().toLowerCase()).append("%'").toString()) +
                        " order by table_name asc, owner asc ";
            
            case "COLUMN":
                return "select owner, table_name, column_name, data_type, data_length from all_tab_columns where 1=1 " +
                        (txtName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(column_name) like '%").append(txtName.getText().trim().toLowerCase()).append("%'").toString()) + 
                        (txtOwner.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(owner) like '%").append(txtOwner.getText().trim().toLowerCase()).append("%'").toString()) +
                        (txtTableName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(table_name) like '%").append(txtTableName.getText().trim().toLowerCase()).append("%'").toString()) +
                        " order by column_name asc, table_name asc ";

            case "VIEW":
                return "select * from all_views where 1=1 " +
                        (txtName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(view_name) like '%").append(txtName.getText().trim().toLowerCase()).append("%'").toString()) + 
                        (txtOwner.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(owner) like '%").append(txtOwner.getText().trim().toLowerCase()).append("%'").toString()) + 
                        " order by view_name asc, owner asc ";
                        
            case "SEQUENCE":
                return "select * from all_sequences where 1=1 " +
                        (txtName.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(sequence_name) like '%").append(txtName.getText().trim().toLowerCase()).append("%'").toString()) + 
                        (txtOwner.getText().trim().toLowerCase().isEmpty() ? "" : new StringBuilder().append("AND lower(sequence_owner) like '%").append(txtOwner.getText().trim().toLowerCase()).append("%'").toString()) +
                        " order by sequence_name asc, sequence_owner asc ";
                        
            default:
                return "";
                
        }
                
    }
    
    //To call whenever the form is running, so as to avoid corrupted data
    private void protectFields(){
       btnSearch.setEnabled(false);
       txtOwner.setEditable(false);
       txtName.setEditable(false);
       comboEnvironment.setEnabled(false);
       comboType.setEnabled(false);
       txtTableName.setEditable(false);
       progressBar.setVisible(true);
    }
    
    //To call whenever the form is done running, to allow editing again
    private void releaseFields(){
       btnSearch.setEnabled(true);  
       txtOwner.setEditable(true);
       txtName.setEditable(true);       
       comboEnvironment.setEnabled(true);
       comboType.setEnabled(true);       
       txtTableName.setEditable(true);
       progressBar.setVisible(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JComboBox comboType;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTableName;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtOwner;
    private javax.swing.JTextField txtTableName;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential