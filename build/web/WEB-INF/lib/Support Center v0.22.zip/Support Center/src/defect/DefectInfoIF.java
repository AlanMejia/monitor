/*
  v 0.15
    - Added.
  v 0.16
    - Corrected an issue that would not inform that a defect was not found and it would not release the fields.
  v 0.19
  - Formatted the dates to a more comfortable standard (dd-Mon-yyyy HH24:mm:ss)
*/

package defect;

import static com.sun.java.accessibility.util.SwingEventMonitor.addInternalFrameListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import servicesheet.*;
import util.OracleConnectionManager;
import util.defect.Defect;


public class DefectInfoIF extends JInternalFrame {

   private java.sql.Connection conn;
   private PreparedStatement prepStm;
   private ResultSet rs;
   private SimpleDateFormat dateFormatter;
   private SimpleDateFormat timeFormatter;
   private StringBuffer buf;
   private boolean done;
   
    public DefectInfoIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable)
   {
     super(title, resizable, closable, maximizable, iconifiable);
     
     initComponents();
     
     this.getRootPane().setDefaultButton(btnSearch);
     buf = new StringBuffer();
     
     dateFormatter = new SimpleDateFormat("EEE, MM-dd-yyyy, ");
     timeFormatter = new SimpleDateFormat("HH:mm z");
     done = false;
     
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { DefectInfoIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
     
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
   }

   private void cleanClose() {
     dispose();
   }
   
   private void getDefectInfo() {
     new Thread(new Runnable()
     {
       public void run() {
         searchDefectInfo();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }
   
   private void searchDefectInfo()
   {
     String defQuery = "";
     String materialList = "";
     
     StringBuffer buf = new StringBuffer();
     try
     {
       done = false;
       protectFields();
       
 
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       defQuery = "select * from (select def.service_workorder_id, def.wo_number, def.defect_id, def.failure_mode, def.repair_action, def.fail_reason, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_name = def.defect_opened_by) as opened_by, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_name = def.defect_repaired_by) as repaired_by, \n"
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = def.last_updated_by) as last_updated_by_user, \n"
               + "NVL(def.repaired_flag, 'N') as repaired_flag, to_char(def.last_update_date, 'DD-Mon-yyyy HH24:MI:SS') as last_update_date, def.last_updated_by, "
               + "to_char(def.creation_date, 'DD-Mon-yyyy HH24:MI:SS') as creation_date, \n"
               + "def.created_by, NVL(def.defect_comments, '-') as defect_comments, def.action_comments, def.service_sheet_id, ss.service_sheet_comments \n"
               + "FROM gets_lms_defect_sheets def, gets_lms_service_sheet ss  \n WHERE \n def.service_sheet_id  = ss.service_sheet_id (+)\n"
               + " AND def.defect_id = " + txtDefectId.getText().trim() + " ) "
               + " order by repaired_flag asc ";
              
       prepStm = conn.prepareStatement(defQuery);
       rs = prepStm.executeQuery();
       
       ArrayList<Defect> defects = new ArrayList();
       
       if (rs.next()) {
         do {
           defects.add(new Defect(rs.getString("service_workorder_id"),
                   rs.getString("wo_number"), 
                   rs.getString("defect_id"), 
                   rs.getString("failure_mode"), 
                   rs.getString("repair_action"), 
                   rs.getString("fail_reason"), 
                   rs.getString("opened_by"), 
                   rs.getString("repaired_by"), 
                   rs.getString("last_updated_by_user"), 
                   rs.getString("repaired_flag"), 
                   rs.getString("last_update_date"), 
                   rs.getString("creation_date"), 
                   rs.getString("defect_comments"), 
                   rs.getString("action_comments"), 
                   rs.getString("service_sheet_id"), 
                   rs.getString("service_sheet_comments"))); 
         }
         while (rs.next());
       } else {
         editorResults.setText("<HTML><BODY><H3>No defects found with this ID.</H3>\n");
         releaseFields();
         return;
       }
       
       rs.close();
       prepStm.close();
       
       buf.append("<HTML><BODY><TABLE border = 1 width=100%>\n");
       
       for (Defect d : defects)
       {
         buf.append("<TR> <!--  verde: 309330 -->\n" +
                 (d.isRepaired() ? "<TD align = \"center\" bgcolor = #309330><B> REPAIRED </B> </TD>\n" : "<TD align = \"center\" bgcolor = #FF0000><B> OPEN </B> </TD>\n") 
                 + "<TD align = \"center\" >" + d.getWoNumber() + "</TD>\n" 
                 + "<TD align = \"center\"><B>Defect ID: </B>" + d.getDefectID() + " </TD>\n" 
                 + "</TR>");         
         buf.append("<TR>"
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Defect Comments: </B></TD>"
                 + "  <TD colspan=\"2\">" + d.getDefectComments() + "</TD>" 
                 + "</TR> " 
                 + "<TR>" 
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Action Comments: </B></TD> " 
                 + "<TD colspan=\"2\">" + d.getActionComments() + "</TD>" 
                 + "</TR>" 
                 + "<TR>" 
                 + "<TD align = \"center\" bgcolor=\"#CEE7FF\"><B>Date info: </TD>" 
                 + "<TD align = \"center\"><B>Opened on </B> " + d.getCreationDate() + " <B>by</B> " + d.getOpenedBy() 
                 + "<TD align = \"center\"><B>Repaired on </B> " + d.getLastUpdateDate() + " <B>by</B> " + d.getLastUpdatedByUser() + "</TD>" 
                 + "</TR>" + "<TR>\n" + "<TD align = \"center\"><B>Fail Reason: </B> " + d.getFailReason() + "</TD>" 
                 + "<TD align = \"center\"><B>Repair Action: </B> " + d.getRepairAction() + "</TD>" 
                 + "<TD align = \"center\"></TD>\n" + "</TR>" 
                 + "<TR>" 
                 + "<TD colspan=\"1\" align = \"center\" bgcolor=\"#CEE7FF\"><B>Service Sheet:</B></TD>" 
                 + "<TD colspan=\"2\"><B>ID: </B>" + d.getServiceSheetID() + ". <B>Comments: </B> " + d.getServiceSheetComments() + "</TD>" 
                 + "</TR>");
         
         buf.append("<TR></TR>");
         
         
       }       
       
       prepStm.close();
       rs.close();
        
       materialList = "SELECT hdr.service_workorder_id, hdr.workorder_number, det.shopping_cart_detail_id, det.shopping_cart_status,\n" +
            "det.item_number_picked, det.requested_quantity, det.picked_quantity, det.deleted_quantity, det.returned_quantity\n" +
            "FROM gets_pc_shopping_cart_header hdr, gets_pc_shopping_cart_details det\n" +
            "WHERE det.shopping_cart_header_id = hdr.shopping_cart_header_id\n" +
            "and det.defect_id = " + txtDefectId.getText() + 
               " order by det.item_number_picked";
       
       prepStm = conn.prepareStatement(materialList);
       rs = prepStm.executeQuery();
              
       if (rs.next()) {
       buf.append("<BR></TABLE><TABLE width=100% border=1>"
               + "<TR>   "
               + "<TD colspan=8 bgcolor=\"#92CDDC\"><B>Material Assigned to this Defect</B></TD>"
               + "</TR>");      
       buf.append("<TR>"
               + "   <TD align=\"center\"><B>Part Number Picked</B></TD>"
               + "   <TD align=\"center\"><B>SP Status</B></TD>"
               + "   <TD align=\"center\"><B>Workorder Info</B></TD>"
               + "   <TD align=\"center\"><B>Req</B></TD>"
               + "   <TD align=\"center\"><B>Pick</B></TD>"
               + "   <TD align=\"center\"><B>Del</B></TD>"
               + "   <TD align=\"center\"><B>Ret</B></TD>"               
               + "   <TD align=\"center\"><B>Shp. Cart. Id</B></TD>" 
               + "</TR>");
           
         do {
           buf.append("<TR>"
                   + "   <TD align=\"center\">" + rs.getString("item_number_picked") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("shopping_cart_status") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("workorder_number") + " (" + rs.getString("service_workorder_id") + ")</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("requested_quantity") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("picked_quantity") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("deleted_quantity") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("returned_quantity") + "</TD>" 
                   + "   <TD align=\"center\">" + rs.getString("shopping_cart_detail_id") + "</TD>" 
                   + "</TR>");
         }
         while (rs.next());
       } else {
         buf.append("<TD colspan=8 align=center ><B>No materials assigned to this Defect.</B></TD>");
       }
       buf.append("</TABLE>");
       
       prepStm.close();
       rs.close();
       
       editorResults.setText(buf.toString());
       
       releaseFields();
       done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("Service Sheet ID: " + txtDefectId.getText() + "\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       util.JErrorLog.createErrorLog("Class: DefectInfoIF, Method: searchServiceSheetInfo", defQuery + "\n\n" + materialList, buf.toString());
        
       releaseFields();
       editorResults.setText("<HTML><H3>An error occurred, please check the logs.<H3></HTML>");
     }
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }  
   
   private void protectFields()
   {
     btnSearch.setEnabled(false);
     progressBar.setVisible(true);
   }
   
   private void releaseFields() {
     btnSearch.setEnabled(true);
     progressBar.setVisible(false);
   }
       
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtDefectId = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Defect ID:");

        txtDefectId.setText("##########");
        txtDefectId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDefectIdFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDefectId, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDefectId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
     if (txtDefectId.getText().trim().isEmpty()) {
       editorResults.setText("<HTML><H3>Please input the Defect ID.<H3></HTML>");
       return;
     }
     try
     {
       Integer.parseInt(txtDefectId.getText());
       getDefectInfo();
       return;
     }
     catch (NumberFormatException e) {
       editorResults.setText("<HTML><H3>Please enter a numeric value.<H3></HTML>");
     }    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtDefectIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDefectIdFocusGained
        txtDefectId.selectAll();
    }//GEN-LAST:event_txtDefectIdFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtDefectId;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential