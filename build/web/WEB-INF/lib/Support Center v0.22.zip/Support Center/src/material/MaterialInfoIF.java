/*
  v 0.15
  - Finally implemented!
  v 0.17
  - Corrected a horrible null value when there is no value on the component id.
  v 0.22
  - Added Find functionality.
*/

package material;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.customerorgs.ServiceOrgData;
import util.material.*;


public class MaterialInfoIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private SimpleDateFormat dateFormatter;
    private SimpleDateFormat timeFormatter;    
    private ArrayList<ServiceOrgData> orgs;    
    private ArrayList<MaterialData> materials;
    private StringBuffer buf;
    private boolean done;    
    private boolean done2;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;     

    public MaterialInfoIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){

        super(title, resizable, closable, maximizable, iconifiable);        
        initComponents();               

        this.getRootPane().setDefaultButton(btnSearch);        
        
        orgs = new ArrayList<>();
        materials = new ArrayList<>();
        
     addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { MaterialInfoIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );               
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
     
     
     loadServiceOrgs();
    }

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }         
    
    private void cleanClose() {
      dispose();
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtPartNumber = new javax.swing.JTextField();
        txtInventoryItemID = new javax.swing.JTextField();
        txtComponentID = new javax.swing.JTextField();
        comboOrgs = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        comboEnvironment = new javax.swing.JComboBox();
        progressBar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtPartNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtPartNumberFocusGained(evt);
            }
        });

        txtInventoryItemID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtInventoryItemIDFocusGained(evt);
            }
        });

        txtComponentID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtComponentIDFocusGained(evt);
            }
        });

        comboOrgs.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Loading Service Orgs --" }));

        jLabel1.setText("Part Number:");

        jLabel2.setText("Inventory Item ID:");

        jLabel3.setText("Service Org");

        jLabel4.setText("Component ID:");

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtPartNumber)
                    .addComponent(txtInventoryItemID, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(comboOrgs, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtComponentID, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPartNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboOrgs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInventoryItemID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtComponentID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(btnSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));
        comboEnvironment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboEnvironmentActionPerformed(evt);
            }
        });

        progressBar.setIndeterminate(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 41, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPartNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtPartNumberFocusGained
        txtPartNumber.selectAll();
    }//GEN-LAST:event_txtPartNumberFocusGained

    private void txtInventoryItemIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtInventoryItemIDFocusGained
        txtInventoryItemID.selectAll();
    }//GEN-LAST:event_txtInventoryItemIDFocusGained

    private void txtComponentIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtComponentIDFocusGained
        txtComponentID.selectAll();
    }//GEN-LAST:event_txtComponentIDFocusGained

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        if(txtPartNumber.getText().isEmpty() && txtInventoryItemID.getText().isEmpty() && txtComponentID.getText().isEmpty()
                && (comboOrgs.getSelectedIndex() == 0)){
            editorResults.setText("Please fill at least one field.");
        } else {   
           loadList();
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void comboEnvironmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboEnvironmentActionPerformed
        loadServiceOrgs();
    }//GEN-LAST:event_comboEnvironmentActionPerformed

   private void loadServiceOrgs() {
     new Thread(new Runnable() {
       public void run() {
         fillOrgData();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }   
   
   private void protectFields(){
        txtPartNumber.setEditable(false);
        txtInventoryItemID.setEditable(false);
        txtComponentID.setEditable(false);
        comboOrgs.setEnabled(false);
        btnSearch.setEnabled(false);
        comboEnvironment.setEnabled(false);
        progressBar.setVisible(true);
   }
   
   private void releaseFields(){
        txtPartNumber.setEditable(true);
        txtInventoryItemID.setEditable(true);
        txtComponentID.setEditable(true);
        comboOrgs.setEnabled(true);
        btnSearch.setEnabled(true);
        comboEnvironment.setEnabled(true);
        progressBar.setVisible(false);       
   }
   
   
   private void fillOrgData()
   {
     protectFields();       
     String orgDataQuery = "";
     try
     {
       conn = OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       orgDataQuery = "select customer_id, service_organization_id, organization_code, name from gets_lms_customer_orgs_v order by name asc";
       
       prepStm = conn.prepareStatement(orgDataQuery);
       rs = prepStm.executeQuery();
              
       if (rs.next()) {
         orgs.clear();
         orgs.add(new ServiceOrgData("0", "0", "0", "-- Select a Service Org --" ));
         do {
           orgs.add(new ServiceOrgData(rs.getString("customer_id"), rs.getString("service_organization_id"), rs.getString("organization_code"), rs.getString("name")));  
         }
         while (rs.next());
       }
       
       prepStm.close();
       rs.close();
       
 
       DefaultComboBoxModel model = new DefaultComboBoxModel(orgs.toArray());
       comboOrgs.setModel(model);
       
       done2 = true;
       releaseFields();
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("No fields.\n");
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: MaterialInforIF, Method: fillOrgData", orgDataQuery, buf.toString());       
 
       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();
     }
   }
           
   private void loadList() {
     new Thread(new Runnable() {
       public void run() {
         fetchMaterialList();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }

 private void fetchMaterialList()
   {
     String materialQuery = "";
     try {
       done = false;
       protectFields();
       editorResults.setText("");
       buf = new StringBuffer();
       materials = new ArrayList<>();
 
       conn = util.OracleConnectionManager.getConnection(getComboConnection());
       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }
       
       materialQuery = "select mat.inventory_item_id, mat.description, mat.segment1, NVL(mat.attribute6,-1) as attribute6, mat.cumulative_total_lead_time, \n" +
                "NVL((select name from gets_lms_customer_orgs_v where service_organization_id = mat.organization_id), to_char(organization_id)) as service_org,\n" +
                " inventory_item_status_code, " +
                "NVL(comp.component_id, '-') as component_name, NVL(comp.traceable, '-') as traceable, "
               + "NVL(comp.emission_critical, '-') as emission_critical, NVL(comp.software, '-') as software, "
               + "NVL(comp.position_tracked,'-') as position_tracked, NVL(comp.removal_reason_required,'-') as removal_reason_required \n" +
                "from GETS_INTF_MTL_SYS_ITEMS_B mat, GETS_INTF_CCS_COMPONENTS comp\n" +
                "where \n" +
                "  mat.attribute6 = comp.item_component_id(+) \n" +               
               (comboOrgs.getSelectedIndex() != 0 ? " and organization_id = " + ((ServiceOrgData)comboOrgs.getSelectedItem()).getId() : ""  ) +
               (txtPartNumber.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(mat.segment1) like '%" + txtPartNumber.getText().trim().toLowerCase() + "%' " ) + 
               (txtInventoryItemID.getText().trim().toLowerCase().isEmpty()  ? "" : " AND lower(mat.inventory_item_id) = " + txtInventoryItemID.getText().trim().toLowerCase() + " " ) + 
               (txtComponentID.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(mat.attribute6) = " + txtComponentID.getText().trim().toLowerCase() + " " ) + 
               " order by mat.segment1 asc , service_org asc ";
       
       prepStm = conn.prepareStatement(materialQuery);
       rs = prepStm.executeQuery();
       
       MaterialData d;
       
        if(rs.next()){
           // Set up
            d = new MaterialData(rs.getString("inventory_item_id"),
                                           rs.getString("segment1"),
                                           rs.getString("description"),
                                           rs.getInt("cumulative_total_lead_time"),
                                           rs.getInt("attribute6"),
                                           rs.getString("inventory_item_status_code")); 
            do{
               if(!rs.getString("segment1").equals(d.getPartNumber())) {
                   materials.add(d);
                   d = new MaterialData(rs.getString("inventory_item_id"),
                                           rs.getString("segment1"),
                                           rs.getString("description"),
                                           rs.getInt("cumulative_total_lead_time"),
                                           rs.getInt("attribute6"),
                                           rs.getString("inventory_item_status_code")); 
               }//if new lookup                   

               d.addComponent(new ComponentData(rs.getString("service_org"), 
                       rs.getString("attribute6"),
                       rs.getString("component_name"),
                       rs.getString("traceable"),
                       rs.getString("emission_critical"),
                       rs.getString("position_tracked"),
                       rs.getString("removal_reason_required"),
                       rs.getString("software")));                   
            }while(rs.next());                

            materials.add(d);

        } else {
           prepStm.close();
           rs.close();                
           editorResults.setText("<HTML><H2>No records found with that criteria.</H2></HTML>");
           releaseFields();
           done = true;
           return;
        }                   
       
       prepStm.close();
       rs.close();

            buf.append("<HTML><BODY>");
            for(MaterialData md : materials){
                buf.append("<TABLE border = 1 width=100%>"
                        + "<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>PART NUMBER</B></TD>"
                        + "<TD colspan = 5>" + md.getPartNumber() + " ( " + md.getInventoryItemId() + " ) </TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"" + md.htmlStatusColor() + "\"><B><FONT color=#FFFFFF>" + md.getInventoryStatus().toUpperCase() + "</FONT></B></TD>"
                        + "</TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>DESCRIPTION</B></TD>"
                        + "<TD colspan = 6>" + md.getDescription() + " </TD>"
                        + "</TR>");
                
                buf.append("<TR>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 20%><B>Service Organization</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>Component (ID)</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 35%><B>Traceable?</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>Em. Critical?</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>Pos. Tracked?</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>Software?</B></TD>"
                        + "<TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\" width = 10%><B>Rem. Reason?</B></TD>"                        
                        + "</TR>");
                for(ComponentData c : md.getComponents()){
                    buf.append("<TR " + ( md.getComponents().indexOf(c) % 2 == 1 ? " bgcolor = #DDDDDD " : "" ) + ">"
                            + "<TD>" + c.getServiceOrg() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getComponentName() + (c.getComponentID().equals("-1") ? "" : " (" + c.getComponentID() + ") " ) + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getTraceable() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getEmissionCritical() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getPositionTracked() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getSoftware() + "</TD>"
                            + "<TD ALIGN=\"CENTER\">" + c.getRemovalReasonRequired() + "</TD>"
                            + "</TR>");
                }
                buf.append("</TABLE><BR>");
            }            
            
            editorResults.setText(buf.toString());                        
            prepStm.close();
            rs.close();
            releaseFields();
            done = true;
     }
     catch (Exception e)
     {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtPartNumber: \"" + txtPartNumber.getText() + "\"\n");
       buf.append("txtInventoryItemID: \"" + txtInventoryItemID.getText() + "\"\n");
       buf.append("txtComponentID: \"" + txtComponentID.getText() + "\"\n");       
       buf.append("comboOrgs: \"" + ((ServiceOrgData)comboOrgs.getSelectedItem()).getName() + "\"\n");       
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Could not pull Material details because: \n");
       buf.append(e.getMessage());
       util.JErrorLog.createErrorLog("Class: MaterialInfoIF, Method: fetchMaterialList", materialQuery + "\n\n", buf.toString());

       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();
     }
   }
      
   
    private int getComboConnection()
    {
     switch (comboEnvironment.getSelectedIndex()) {
        case 0: 
          return OracleConnectionManager.PROD;
        case 1: 
          return OracleConnectionManager.STG;
        case 2: 
          return OracleConnectionManager.DEV;
        case 3: 
          return OracleConnectionManager.INT_DEV;
     }
     return 0;
    }       

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JComboBox comboOrgs;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtComponentID;
    private javax.swing.JTextField txtInventoryItemID;
    private javax.swing.JTextField txtPartNumber;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential