/* 
  v 0.15
   - Created
*/
package util.material;

import java.util.ArrayList;

public class MaterialData {

    private String inventoryItemId;
    private String description;
    private String partNumber;
    private int cumulativeLT;
    private ArrayList<ComponentData> components;
    private int componentID;
    private String inventoryStatus;

    public MaterialData(String inventoryItemId, String partNumber, String description, int cumulativeLT, int componentID, String inventoryStatus){
        this.inventoryItemId = inventoryItemId;
        this.partNumber = partNumber;
        this.description = description;
        this.cumulativeLT = cumulativeLT;
        this.componentID = componentID;
        this.inventoryStatus = inventoryStatus;
        this.components = new ArrayList<>();
        
    }
    
    /**
     * @return the inventoryItemId
     */
    public String getInventoryItemId() {
        return inventoryItemId;
    }

    /**
     * @param inventoryItemId the inventoryItemId to set
     */
    public void setInventoryItemId(String inventoryItemId) {
        this.inventoryItemId = inventoryItemId;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the partNumber
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * @param partNumber the partNumber to set
     */
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    /**
     * @return the cumulativeLT
     */
    public int getCumulativeLT() {
        return cumulativeLT;
    }

    /**
     * @param cumulativeLT the cumulativeLT to set
     */
    public void setCumulativeLT(int cumulativeLT) {
        this.cumulativeLT = cumulativeLT;
    }

    /**
     * @return the components
     */
    public ArrayList<ComponentData> getComponents() {
        return components;
    }

    /**
     * @param components the components to set
     */
    public void setComponents(ArrayList<ComponentData> components) {
        this.components = components;
    }

    public void addComponent(ComponentData d){
        this.components.add(d);
    }

    /**
     * @return the componentID
     */
    public int getComponentID() {
        return componentID;
    }

    /**
     * @param componentID the componentID to set
     */
    public void setComponentID(int componentID) {
        this.componentID = componentID;
    }

    /**
     * @return the inventoryStatus
     */
    public String getInventoryStatus() {
        return inventoryStatus;
    }

    /**
     * @param inventoryStatus the inventoryStatus to set
     */
    public void setInventoryStatus(String inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }
    
    public String htmlStatusColor() {
      
       switch(inventoryStatus){
           
           case "Active":
               return "#009933"; //Green
           case "Inactive":
               return "#FF1919"; //Red 
           default:
               return "#3366FF"; //Blue
       }
    }
}

//GE Confidential