
package util;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class DBUtils {
    
    private Vector columnNames;
    private Vector rows;
    
    public DBUtils(){
        columnNames = new Vector();
        rows = new Vector();
    }
    
    public Vector getColumnNames(){
        return columnNames;
    }
    
    public Vector getRows(){
        return rows;
    }
    
    public void resetRows(){
        rows = new Vector();
    }
    
    public TableModel resultSetToTableModel(ResultSet rs) {
        try {
            int maxRows = 50;
            int count = 0;
            
            ResultSetMetaData metaData = rs.getMetaData();
            int numberOfColumns = metaData.getColumnCount();
            columnNames = new Vector();

            // Get the column names
            for (int column = 0; column < numberOfColumns; column++) {
                columnNames.addElement(metaData.getColumnLabel(column + 1));
            }

            // Get all rows.            
            while (rs.next() && count < 50) {
                Vector newRow = new Vector();

                for (int i = 1; i <= numberOfColumns; i++) {
                    newRow.addElement(rs.getObject(i));
                }

                rows.addElement(newRow);
                count++;
            }

            return new DefaultTableModel(rows, columnNames);
            
        } catch (Exception e) {
            e.printStackTrace();

            return null;
        }
    }
}