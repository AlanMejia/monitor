
package util.fmi;

public class AuthorData {

    private String name;
    private String leadAuthor;

    public AuthorData(String name, String leadAuthor){
        this.name = name;
        this.leadAuthor = leadAuthor;
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the leadAuthor
     */
    public String getLeadAuthor() {
        return leadAuthor;
    }

    /**
     * @param leadAuthor the leadAuthor to set
     */
    public void setLeadAuthor(String leadAuthor) {
        this.leadAuthor = leadAuthor;
    }
    
}

//GE Confidential