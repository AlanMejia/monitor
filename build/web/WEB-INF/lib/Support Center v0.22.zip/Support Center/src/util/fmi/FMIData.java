
package util.fmi;

import java.util.ArrayList;

public class FMIData {

    private String id;
    private String number;
    private String status;
    private String title;
    private String description;
    private String creationDate;
    private String lastUpdateDate;
    private String createdBy;
    private String lastUpdatedBy;
    private ArrayList<AuthorData> authors;
    private ArrayList<ProfileData> profiles;

    public FMIData(String number){
        this.number = number;
        this.id = this.title = this.description = this.creationDate = this.lastUpdateDate = this.createdBy = this.lastUpdatedBy = "";
        this.status = "";
        this.authors = new ArrayList<>();
        this.profiles = new ArrayList<>();                               
    }
    
    public FMIData(String id, String number, String status, String title, String description, 
            String creationDate, String lastUpdateDate, String createdBy,
            String lastUpdatedBy){
        this.id = id;
        this.number = number;
        this.title = title;
        this.description = description;
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.createdBy = createdBy;
        this.lastUpdatedBy = lastUpdatedBy;
        this.status = status;
        this.authors = new ArrayList<>();
        this.profiles = new ArrayList<>();                       
    }
    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the number
     */
    public String getNumber() {
        return number;
    }

    /**
     * @param number the number to set
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the creationDate
     */
    public String getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastUpdateDate
     */
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * @param lastUpdateDate the lastUpdateDate to set
     */
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the lastUpdatedBy
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * @param lastUpdatedBy the lastUpdatedBy to set
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /**
     * @return the authors
     */
    public ArrayList<AuthorData> getAuthors() {
        return authors;
    }

    /**
     * @param authors the authors to set
     */
    public void setAuthors(ArrayList<AuthorData> authors) {
        this.authors = authors;
    }

    /**
     * @return the profiles
     */
    public ArrayList<ProfileData> getProfiles() {
        return profiles;
    }

    /**
     * @param profiles the profiles to set
     */
    public void setProfiles(ArrayList<ProfileData> profiles) {
        this.profiles = profiles;
    }
    
    public void addAuthor(AuthorData a){
        this.authors.add(a);
    }
    
    public void addProfile(ProfileData p){
        this.profiles.add(p);
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String toString(){
        return "<HTML><B>" + this.number + "</B> (" + this.title + ")</HTML>";
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    public void clearProfiles(){
        this.profiles.clear();
    }
    
    public void clearAuthors(){
        this.authors.clear();
    }
}

//GE Confidential