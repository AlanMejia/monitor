 package util.user;
 
 public class RespData
 {
   private String id;
   
   private String name;
   
   private int applicationId;
   
   private String toDate;
   private String fromDate;
   
   public RespData(String id, String name, String toDate)
   {
     this.id = id;
     this.name = name;
     this.toDate = toDate;
   }
   
   public RespData(String id, String name, int applicationId) {
     this.id = id;
     this.name = name;
     this.applicationId = applicationId;
   }
   
   public RespData(String id, String name, String fromDate, String toDate) {
     this.id = id;
     this.name = name;
     this.toDate = toDate;
     this.fromDate = fromDate;
   }
   
   public RespData(String id, String name) {
     this.id = id;
     this.name = name;
   }
   
 
 
 
   public String getId()
   {
     return this.id;
   }
   
 
 
   public void setId(String id)
   {
     this.id = id;
   }
   
 
 
   public String getName()
   {
     return this.name;
   }
   
 
 
   public void setName(String name)
   {
     this.name = name;
   }
   
 
 
   public String getToDate()
   {
     return null == this.toDate ? "-" : this.toDate;
   }
   
 
 
   public void setToDate(String toDate)
   {
     this.toDate = toDate;
   }
   
 
 
   public String getFromDate()
   {
     return this.fromDate;
   }
   
 
 
   public void setFromDate(String fromDate)
   {
     this.fromDate = fromDate;
   }
   
 
 
   public int getApplicationId()
   {
     return this.applicationId;
   }
   
 
 
   public void setApplicationId(int applicationId)
   {
     this.applicationId = applicationId;
   }
   
   public String toString() {
     return this.name;
   }
 }


//GE Confidential