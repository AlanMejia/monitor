 package util;
 
 import java.io.File;
 import javax.swing.filechooser.FileFilter;
 
 public class FolderFilter extends FileFilter
 {
   public boolean accept(File file)
   {
     return file.isDirectory();
   }
   
   public String getDescription()
   {
     return "Please select a Directory.";
   }
 }


//GE Confidential