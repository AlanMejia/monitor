 package util.defect;
 
 
 public class Defect
 {
private String woID;

private String woNumber;

private String defectID;

private String failureMode;

private String repairAction;

private String failReason;

private String openedBy;

private String repairedBy;
private String lastUpdatedByUser;
private String repairedFlag;
private String lastUpdateDate;
private String creationDate;
private String defectComments;
private String actionComments;
private String serviceSheetID;
private String serviceSheetComments;

public Defect(String woID, String woNumber, String defectID, String failureMode, String repairAction, String failReason, String openedBy, String repairedBy, String lastUpdatedByUser, String repairedFlag, String lastUpdateDate, String creationDate, String defectComments, String actionComments, String serviceSheetID, String serviceSheetComments)
{
     this.woID = woID;
     this.woNumber = woNumber;
     this.defectID = defectID;
     this.failureMode = failureMode;
     this.repairAction = repairAction;
     this.failReason = failReason;
     this.openedBy = openedBy;
     this.repairedBy = repairedBy;
     this.lastUpdatedByUser = lastUpdatedByUser;
     this.repairedFlag = repairedFlag;
     this.lastUpdateDate = lastUpdateDate;
     this.creationDate = creationDate;
     this.defectComments = defectComments;
     this.actionComments = actionComments;
     this.serviceSheetID = serviceSheetID;
     this.serviceSheetComments = serviceSheetComments;
}

 
 
public String getWoID()
{
     return this.woID;
}

 
 
public void setWoID(String woID)
{
     this.woID = woID;
}

 
 
public String getDefectID()
{
     return this.defectID;
}

 
 
public void setDefectID(String defectID)
{
     this.defectID = defectID;
}

 
 
public String getFailureMode()
{
     return null == this.failureMode ? "-" : this.failureMode;
}

 
 
public void setFailureMode(String failureMode)
{
     this.failureMode = failureMode;
}

 
 
public String getRepairAction()
{
     return null == this.repairAction ? "-" : this.repairAction;
}

 
 
public void setRepairAction(String repairAction)
{
     this.repairAction = repairAction;
}

 
 
public String getFailReason()
{
     return null == this.failReason ? "-" : this.failReason;
}

 
 
public void setFailReason(String failReason)
{
     this.failReason = failReason;
}

 
 
public String getOpenedBy()
{
     return this.openedBy;
}

 
 
public void setOpenedBy(String openedBy)
{
     this.openedBy = openedBy;
}

 
 
public String getRepairedBy()
{
     return null == this.repairedBy ? "-" : this.repairedBy;
}

 
 
public void setRepairedBy(String repairedBy)
{
     this.repairedBy = repairedBy;
}

 
 
public String getLastUpdatedByUser()
{
     return this.lastUpdatedByUser;
}

 
 
public void setLastUpdatedByUser(String lastUpdatedByUser)
{
     this.lastUpdatedByUser = lastUpdatedByUser;
}

 
 
public String getRepairedFlag()
{
     return this.repairedFlag;
}

 
 
public void setRepairedFlag(String repairedFlag)
{
     this.repairedFlag = repairedFlag;
}

public boolean isRepaired() {
     if (this.repairedFlag == null)
       return false;
     if (this.repairedFlag.equals("Y")) {
       return true;
  }
     return false;
}

 
 
public String getLastUpdateDate()
{
     return this.lastUpdateDate;
}

 
 
public void setLastUpdateDate(String lastUpdateDate)
{
     this.lastUpdateDate = lastUpdateDate;
}

 
 
public String getCreationDate()
{
     return this.creationDate;
}

 
 
public void setCreationDate(String creationDate)
{
     this.creationDate = creationDate;
}

 
 
public String getDefectComments()
{
     return this.defectComments;
}

 
 
public void setDefectComments(String defectComments)
{
     this.defectComments = defectComments;
}

 
 
public String getActionComments()
{
     return null == this.actionComments ? "-" : this.actionComments;
}

 
 
public void setActionComments(String actionComments)
{
     this.actionComments = actionComments;
}

 
 
public String getServiceSheetID()
{
     return null == this.serviceSheetID ? "-" : this.serviceSheetID;
}

 
 
public void setServiceSheetID(String serviceSheetID)
{
     this.serviceSheetID = serviceSheetID;
}

 
 
public String getServiceSheetComments()
{
     return null == this.serviceSheetComments ? "-" : this.serviceSheetComments;
}

 
 
public void setServiceSheetComments(String serviceSheetComments)
{
     this.serviceSheetComments = serviceSheetComments;
}

 
 
public String getWoNumber()
{
     return this.woNumber;
}

 
 
public void setWoNumber(String woNumber)
{
     this.woNumber = woNumber;
}
 }

//GE Confidential