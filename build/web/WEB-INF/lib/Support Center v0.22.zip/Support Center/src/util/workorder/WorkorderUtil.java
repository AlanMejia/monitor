 package util.workorder;
 
 public class WorkorderUtil
 {
   public static String translateWOStatus(String status)
   {
     if (null == status) {
       return "000";
     }
     switch (Integer.parseInt(status)) {
     case 100: 
       return "Incoming";
     case 150: 
       return "Off-Line";
     case 200: 
       return "Arrived";
     case 300: 
       return "Inshopped";
     case 325: 
       return "Reviewed";
     case 350: 
       return "Being Serviced";
     case 355: 
       return "Service Track";
     case 360: 
       return "Set Over";
     case 400: 
       return "Waiting Material";
     case 425: 
       return "Needing Material";
     case 450: 
       return "Waiting Labor";
     case 500: 
       return "Waiting Space";
     case 550: 
       return "Waiting Move";
     case 575: 
       return "Wash";
     case 600: 
       return "Wheel True";
     case 625: 
       return "Load Test";
     case 650: 
       return "Drop Pit";
     case 675: 
       return "Heavy Repair";
     case 680: 
       return "Parked";
     case 690: 
       return "System Hold";
     case 700: 
       return "Outshopped";
     case 800: 
       return "Re-Open for Data";
     case 900: 
       return "Closed";
     }
     return "NA";
   }
 }

//GE Confidential