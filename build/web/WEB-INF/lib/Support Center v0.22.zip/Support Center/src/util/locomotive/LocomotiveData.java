/*
  v 0.15
  - Added the LNG attribute for the Loco Config All table.
  v 0.17
  - Added the htmlStatusColor method to determine the color of the status.
  v 0.19
  - Added the status to the toString method.
  v 0.22
  - Added Locomotive Model and Inverter Type CBTA entries.
*/

package util.locomotive;
  
 public class LocomotiveData
 {
   private String id;   
   private String aarRoad;   
   private String roadNumber;   
   private String lastUpdateDate;   
   private String lastUpdatedBy;   
   private String creationDate;   
   private String createdBy;      
   private String customer;   
   private String fleet;   
   private String fleetId;   
   private String model;
   private String type;
   private String status;
   private String horsepower;
   private String brakeType;
   private String inserviceDate;
   private String assetType;
   private String emissionTier;
   private String locoList;
   private String partsCatalogId;   
   
   private String hpfp;
   private String airDryer;
   private String tractionMotor;
   private String aess;
   private String locoType;
   private String airBrake;
   private String engineHP;
   private String videoSystem;
   private String truckType;
   private String blasterSystem;
   private String numberOfAxles;
   private String lng;
   private String locoModel;
   private String inverterType;
   
   public LocomotiveData(String id, String aarRoad, String roadNumber, String hpfp, String airDryer, 
           String tractionMotor, String aess, String locoType, String airBrake, String engineHP, 
           String videoSystem, String truckType, String blasterSystem, String numberOfAxles, String lng,
           String locoModel, String inverterType)
   {
     this.id = id;
     this.hpfp = hpfp;
     this.airDryer = airDryer;
     this.tractionMotor = tractionMotor;
     this.aess = aess;
     this.locoType = locoType;
     this.airBrake = airBrake;
     this.engineHP = engineHP;
     this.videoSystem = videoSystem;
     this.truckType = truckType;
     this.blasterSystem = blasterSystem;
     this.numberOfAxles = numberOfAxles;
     this.aarRoad = aarRoad;
     this.roadNumber = roadNumber;
     this.lng = lng;
     this.locoModel = locoModel;
     this.inverterType = inverterType;
     
   }     
 
   public LocomotiveData(String id, String aarRoad, String roadNumber, String creationDate,
           String createdBy, String lastUpdateDate, 
           String lastUpdatedBy, String customer, String fleet, String fleetId, String model, 
           String type, String status, String horsepower, String brakeType, String inserviceDate, 
           String assetType, String emissionTier, String locoList, String partsCatalogId, String hpfp, 
           String airDryer, String tractionMotor, String aess, String locoType, String airBrake, 
           String engineHP, String videoSystem, String truckType, String blasterSystem, 
           String numberOfAxles, String lng, String locoModel, String inverterType)
   {
     this.id = id;
     this.aarRoad = aarRoad;
     this.roadNumber = roadNumber;
     this.createdBy = createdBy;
     this.creationDate = creationDate;
     this.lastUpdateDate = lastUpdateDate;
     this.lastUpdatedBy = lastUpdatedBy;
     this.customer = customer;
     this.fleet = fleet;
     this.fleetId = fleetId;
     this.model = model;
     this.type = type;
     this.status = status;
     this.horsepower = horsepower;
     this.brakeType = brakeType;
     this.inserviceDate = inserviceDate;
     this.assetType = assetType;
     this.emissionTier = emissionTier;
     this.locoList = locoList;
     this.partsCatalogId = partsCatalogId;
     this.hpfp = hpfp;
     this.airDryer = airDryer;
     this.tractionMotor = tractionMotor;
     this.aess = aess;
     this.locoType = locoType;
     this.airBrake = airBrake;
     this.engineHP = engineHP;
     this.videoSystem = videoSystem;
     this.truckType = truckType;
     this.blasterSystem = blasterSystem;
     this.numberOfAxles = numberOfAxles;
     this.lng = lng;
     this.locoModel = locoModel;
     this.inverterType = inverterType;     
   }
   
   public LocomotiveData() {
     this.id = new String();
     this.aarRoad = new String();
     this.roadNumber = new String();
   }
   
   public LocomotiveData(String id, String aarRoad, String roadNumber, String status) {
     this.id = id;
     this.aarRoad = aarRoad;
     this.roadNumber = roadNumber;
     this.status = status;
   }
   
   public LocomotiveData(String aarRoad, String roadNumber) {
     this.id = new String();
     this.aarRoad = aarRoad;
     this.roadNumber = roadNumber;
   }
   
 
 
   public String getId()
   {
     return this.id;
   }
   
 
 
   public void setId(String id)
   {
     this.id = id;
   }
   
 
 
   public String getAarRoad()
   {
     return this.aarRoad;
   }
   
 
 
   public void setAarRoad(String aarRoad)
   {
     this.aarRoad = aarRoad;
   }
   
 
 
   public String getRoadNumber()
   {
     return this.roadNumber;
   }
   
 
 
   public void setRoadNumber(String roadNumber)
   {
     this.roadNumber = roadNumber;
   }
   
 
 
   public String getLastUpdateDate()
   {
     return this.lastUpdateDate;
   }
   
 
 
   public void setLastUpdateDate(String lastUpdateDate)
   {
     this.lastUpdateDate = lastUpdateDate;
   }
   
 
 
   public String getLastUpdatedBy()
   {
     return this.lastUpdatedBy;
   }
   
 
 
   public void setLastUpdatedBy(String lastUpdatedBy)
   {
     this.lastUpdatedBy = lastUpdatedBy;
   }
   
 
 
   public String getCustomer()
   {
     return this.customer;
   }
   
 
 
   public void setCustomer(String customer)
   {
     this.customer = customer;
   }
   
 
 
   public String getFleet()
   {
     return this.fleet;
   }
   
 
 
   public void setFleet(String fleet)
   {
     this.fleet = fleet;
   }
   
 
 
   public String getFleetId()
   {
     return this.fleetId;
   }
   
 
 
   public void setFleetId(String fleetId)
   {
     this.fleetId = fleetId;
   }
   
 
 
   public String getModel()
   {
     return this.model;
   }
   
 
 
   public void setModel(String model)
   {
     this.model = model;
   }
   
 
 
   public String getType()
   {
     return this.type;
   }
   
 
 
   public void setType(String type)
   {
     this.type = type;
   }
   
 
 
   public String getStatus()
   {
     if(this.status.equals("-"))
          return "NO STATUS";
     else
         return this.status;
   }
   
 
 
   public void setStatus(String status)
   {
     this.status = status;
   }
   
 
 
   public String getHorsepower()
   {
     return null == this.horsepower ? "-" : this.horsepower;
   }
   
 
 
   public void setHorsepower(String horsepower)
   {
     this.horsepower = horsepower;
   }
   
 
 
   public String getBrakeType()
   {
     return null == this.brakeType ? "-" : this.brakeType;
   }
   
 
 
   public void setBrakeType(String brakeType)
   {
     this.brakeType = brakeType;
   }
   
 
 
   public String getInserviceDate()
   {
     return this.inserviceDate;
   }
   
 
 
   public void setInserviceDate(String inserviceDate)
   {
     this.inserviceDate = inserviceDate;
   }
   
 
 
   public String getAssetType()
   {
     return null == this.assetType ? "-" : this.assetType;
   }
   
 
 
   public void setAssetType(String assetType)
   {
     this.assetType = assetType;
   }
   
 
 
   public String getEmissionTier()
   {
     return null == this.emissionTier ? "-" : this.emissionTier;
   }
   
 
 
   public void setEmissionTier(String emissionTier)
   {
     this.emissionTier = emissionTier;
   }
   
 
 
   public String getLocoList()
   {
     return null == this.locoList ? "-" : this.locoList;
   }
   
 
 
   public void setLocoList(String locoList)
   {
     this.locoList = locoList;
   }
   
 
 
   public String getPartsCatalogId()
   {
     return null == this.partsCatalogId ? "-" : this.partsCatalogId;
   }
   
 
 
   public void setPartsCatalogId(String partsCatalogId)
   {
     this.partsCatalogId = partsCatalogId;
   }
   
 
 
   public String getHpfp()
   {
     return null == this.hpfp ? "-" : this.hpfp;
   }
   
 
 
   public void setHpfp(String hpfp)
   {
     this.hpfp = hpfp;
   }
   
 
 
   public String getAirDryer()
   {
     return null == this.airDryer ? "-" : this.airDryer;
   }
   
 
 
   public void setAirDryer(String airDryer)
   {
     this.airDryer = airDryer;
   }
   
 
 
   public String getTractionMotor()
   {
     return null == this.tractionMotor ? "-" : this.tractionMotor;
   }
   
 
 
   public void setTractionMotor(String tractionMotor)
   {
     this.tractionMotor = tractionMotor;
   }
   
 
 
   public String getAess()
   {
     return null == this.aess ? "-" : this.aess;
   }
   
 
 
   public void setAess(String aess)
   {
     this.aess = aess;
   }
   
 
 
   public String getLocoType()
   {
     return null == this.locoType ? "-" : this.locoType;
   }
   
 
 
   public void setLocoType(String locoType)
   {
     this.locoType = locoType;
   }
   
 
 
   public String getAirBrake()
   {
     return null == this.airBrake ? "-" : this.airBrake;
   }
   
 
 
   public void setAirBrake(String airBrake)
   {
     this.airBrake = airBrake;
   }
   
 
 
   public String getEngineHP()
   {
     return null == this.engineHP ? "-" : this.engineHP;
   }
   
 
 
   public void setEngineHP(String engineHP)
   {
     this.engineHP = engineHP;
   }
   
 
 
   public String getVideoSystem()
   {
     return null == this.videoSystem ? "-" : this.videoSystem;
   }
   
 
 
   public void setVideoSystem(String videoSystem)
   {
     this.videoSystem = videoSystem;
   }
   
 
 
   public String getTruckType()
   {
     return null == this.truckType ? "-" : this.truckType;
   }
   
 
 
   public void setTruckType(String truckType)
   {
     this.truckType = truckType;
   }
   
 
 
   public String getBlasterSystem()
   {
     return null == this.blasterSystem ? "-" : this.blasterSystem;
   }
   
 
 
   public void setBlasterSystem(String blasterSystem)
   {
     this.blasterSystem = blasterSystem;
   }
   
 
 
   public String getNumberOfAxles()
   {
     return null == this.numberOfAxles ? "-" : this.numberOfAxles;
   }
   
 
 
   public void setNumberOfAxles(String numberOfAxles)
   {
     this.numberOfAxles = numberOfAxles;
   }
   
   public String htmlStatusColor() {
      
       switch(status){
           case "DESIGN/BUILD":
               return "#FFA319"; //Ocher Yellow
           case "ACTIVE":
               return "#009933"; //Green
           case "INACTIVE":
               return "#999966"; //Grey
           case "RETIRED":
               return "#999966"; //Grey
           case "TEST":
               return "#3366FF"; //Blue
           default:
               return "#FF1919"; //Red 
       }

   }

    /**
     * @return the lng
     */
    public String getLng() {
        return (null == lng ? "-" : lng);
    }

    /**
     * @param lng the lng to set
     */
    public void setLng(String lng) {
        this.lng = lng;
    }
    
    public String toString(){
        if(this.id.equals("-1"))
            return "No locomotives found.";
        else 
            return this.aarRoad + "-" + this.roadNumber + " (" + this.status + ")";
    }

    /**
     * @return the creationDate
     */
    public String getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the locoModel
     */
    public String getLocoModel() {
        return (null == locoModel ? "-" : locoModel);
    }

    /**
     * @param locoModel the locoModel to set
     */
    public void setLocoModel(String locoModel) {
        this.locoModel = locoModel;
    }

    /**
     * @return the inverterType
     */
    public String getInverterType() {
        return (null == inverterType ? "-" : inverterType);
    }

    /**
     * @param inverterType the inverterType to set
     */
    public void setInverterType(String inverterType) {
        this.inverterType = inverterType;
    }
 }

//GE Confidential