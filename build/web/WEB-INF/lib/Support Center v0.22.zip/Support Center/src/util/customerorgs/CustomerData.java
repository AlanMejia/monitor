/*
  v0.12
  - Added CustomerData(customerId, customerName) constructor for use in the locomotive lookup which
    will now include the customer as a search option.
*/ 

package util.customerorgs;
 
 import java.util.ArrayList;
 
 public class CustomerData
 {
   private String customerName;
   private String customerId;
   private String customerNumber;
   private String customerPhonetic;
   private ArrayList<ServiceOrgData> serviceOrgs;
   
   public CustomerData(String customerId, String customerName, String customerNumber, String customerPhonetic)
   {
     this.customerName = customerName;
     this.customerId = customerId;
     this.customerNumber = customerNumber;
     this.customerPhonetic = customerPhonetic;
     this.serviceOrgs = new ArrayList();
   }
   
   public CustomerData(String customerId, String customerName, String customerPhonetic) {
     this.customerName = customerName;
     this.customerId = customerId;
     this.customerPhonetic = customerPhonetic;
     this.serviceOrgs = new ArrayList();
   }
   
   public CustomerData(String customerId, String customerName){
       this.customerId = customerId;
       this.customerName = customerName;
   }
 
   public String getCustomerName()
   {
     return this.customerName;
   }
 
   public void setCustomerName(String customerName)
   {
     this.customerName = customerName;
   }
 
   public String getCustomerId()
   {
     return this.customerId;
   }
 
   public void setCustomerId(String customerId)
   {
     this.customerId = customerId;
   }
 
   public String getCustomerNumber()
   {
     return this.customerNumber;
   }
 
   public void setCustomerNumber(String customerNumber)
   {
     this.customerNumber = customerNumber;
   }
 
   public String getCustomerPhonetic()
   {
     return this.customerPhonetic;
   }

   public void setCustomerPhonetic(String customerPhonetic)
   {
     this.customerPhonetic = customerPhonetic;
   }
   
   public ArrayList<ServiceOrgData> getServiceOrgs()
   {
     return this.serviceOrgs;
   }
   
   public void setServiceOrgs(ArrayList<ServiceOrgData> serviceOrgs)
   {
     this.serviceOrgs = serviceOrgs;
   }
   
   public void addServiceOrg(ServiceOrgData o) {
     this.serviceOrgs.add(o);
   }
   
   public String toString(){
       return this.customerName;
   }
 }


//GE Confidential