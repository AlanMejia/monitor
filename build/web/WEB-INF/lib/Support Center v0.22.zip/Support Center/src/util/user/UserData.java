/*
  v 0.18
  - Added Last Updated Date and Last Updated By fields.
  - Added the htmlStatusColor method to determine the color of the status.
*/

package util.user;
 
 import java.util.ArrayList; 
 
 public class UserData
 {
   private String firstName;
   private String lastName;
   private String userName;
   private String activeFlag;
   private String orgName;
   private String creationDate;
   private String createdByUser;
   private String lastUpdateDate;
   private String lastUpdatedBy;
   private String effectiveFrom;
   private String effectiveTo;
   private String userId;
   private String language2;
   private String language1;
   private String skillClass;
   private String employeeClass;
   private String email;
   private String lastLogon;
   private ArrayList<RespData> respList;
   private String currentResp;
   private String accessLevel;
   
   public UserData(String firstName, String lastName, String userName, String activeFlag, String orgName, 
           String creationDate, String createdByUser, String lastUpdateDate, String lastUpdatedBy, 
           String effectiveFrom, String effectiveTo, 
           String userId, String language2, String language1, String skillClass, String employeeClass, 
           String email, String lastLogon, String currentResp, String accessLevel)
   {
     this.firstName = firstName;
     this.lastName = lastName;
     this.userName = userName;
     this.activeFlag = (null == activeFlag ? "NO" : activeFlag);
     this.orgName = orgName;
     this.creationDate = creationDate;
     this.createdByUser = createdByUser;
     this.lastUpdateDate = lastUpdateDate;
     this.lastUpdatedBy = lastUpdatedBy;
     this.effectiveFrom = effectiveFrom;
     this.effectiveTo = effectiveTo;
     this.userId = userId;
     this.language2 = language2;
     this.language1 = language1;
     this.skillClass = skillClass;
     this.employeeClass = employeeClass;
     this.email = email;
     this.lastLogon = lastLogon;
     this.respList = new ArrayList();
     this.currentResp = currentResp;
     this.accessLevel = accessLevel;     
   }
   
   public UserData(String firstName, String lastName, String userName, String userId) {
     this.firstName = firstName;
     this.lastName = lastName;
     this.userName = userName;
     this.userId = userId;
   }
   
 
 
   public String getFirstName()
   {
     return this.firstName;
   }
   
 
 
   public void setFirstName(String firstName)
   {
     this.firstName = firstName;
   }
   
 
 
   public String getLastName()
   {
     return this.lastName;
   }
   
 
 
   public void setLastName(String lastName)
   {
     this.lastName = lastName;
   }
   
 
 
   public String getUserName()
   {
     return this.userName;
   }
   
 
 
   public void setUserName(String userName)
   {
     this.userName = userName;
   }
   
 
 
   public String getActiveFlag()
   {
     return this.activeFlag;
   }
   
 
 
   public void setActiveFlag(String activeFlag)
   {
     this.activeFlag = activeFlag;
   }
   
 
 
   public String getOrgName()
   {
     return this.orgName;
   }
   
 
 
   public void setOrgName(String orgName)
   {
     this.orgName = orgName;
   }
   
 
 
   public String getCreationDate()
   {
     return this.creationDate;
   }
   
 
 
   public void setCreationDate(String creationDate)
   {
     this.creationDate = creationDate;
   }
   
 
 
   public String getCreatedByUser()
   {
     return this.createdByUser;
   }
   
 
 
   public void setCreatedByUser(String createdByUser)
   {
     this.createdByUser = createdByUser;
   }
   
 
 
   public String getEffectiveFrom()
   {
     return this.effectiveFrom;
   }
   
 
 
   public void setEffectiveFrom(String effectiveFrom)
   {
     this.effectiveFrom = effectiveFrom;
   }
   
 
 
   public String getEffectiveTo()
   {
     return null == this.effectiveTo ? "-" : this.effectiveTo;
   }
   
 
 
   public void setEffectiveTo(String effectiveTo)
   {
     this.effectiveTo = effectiveTo;
   }
   
 
 
   public String getUserId()
   {
     return this.userId;
   }
   
 
 
   public void setUserId(String userId)
   {
     this.userId = userId;
   }
   
 
 
   public String getLanguage2()
   {
     return this.language2;
   }
   
 
 
   public void setLanguage2(String language2)
   {
     this.language2 = language2;
   }
   
 
 
   public String getLanguage1()
   {
     return this.language1;
   }
   
 
 
   public void setLanguage1(String language1)
   {
     this.language1 = language1;
   }
   
 
 
   public String getSkillClass()
   {
     return this.skillClass;
   }
   
 
 
   public void setSkillClass(String skillClass)
   {
     this.skillClass = skillClass;
   }
   
 
 
   public String getEmployeeClass()
   {
     return this.employeeClass;
   }
   
 
 
   public void setEmployeeClass(String employeeClass)
   {
     this.employeeClass = employeeClass;
   }
   
 
 
   public String getLastLogon()
   {
     return this.lastLogon;
   }
   
 
 
   public void setLastLogon(String lastLogon)
   {
     this.lastLogon = lastLogon;
   }
   
 
 
   public ArrayList<RespData> getRespList()
   {
     return this.respList;
   }
   
 
 
   public void setRespList(ArrayList<RespData> respList)
   {
     this.respList = respList;
   }
   
   public void addResponsibility(String id, String name, String toDate) {
     this.respList.add(new RespData(id, name, toDate));
   }
   
 
 
   public String getEmail()
   {
     return this.email;
   }
   
   public String isActiveHTML() {
     return "YES".equals(this.activeFlag) ? "<FONT COLOR=GREEN><B>ACTIVE</B></FONT>" : "<FONT COLOR=RED><B>INACTIVE</B></FONT>";
   }
   
 
 
 
   public void setEmail(String email)
   {
     this.email = email;
   }
   
 
 
   public String getCurrentResp()
   {
     return this.currentResp;
   }
   
 
 
   public void setCurrentResp(String currentResp)
   {
     this.currentResp = currentResp;
   }
   
 
 
   public String getAccessLevel()
   {
     return this.accessLevel;
   }
   
 
 
   public void setAccessLevel(String accessLevel)
   {
     this.accessLevel = accessLevel;
   }

    /**
     * @return the lastUpdateDate
     */
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * @param lastUpdateDate the lastUpdateDate to set
     */
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * @return the lastUpdatedBy
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * @param lastUpdatedBy the lastUpdatedBy to set
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    
    
    public String htmlStatusColor() {
      
       switch(activeFlag){
           
           case "YES":
               return "#009933"; //Green
           default:
               return "#FF1919"; //Red 
       }
    }
    
 }

//GE Confidential