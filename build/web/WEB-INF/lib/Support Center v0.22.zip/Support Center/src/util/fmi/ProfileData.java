/*
  v 0.16
  - Added
*/

package util.fmi;

import java.util.ArrayList;

public class ProfileData {

   private String profileId;
   private String profileName;
   private String description;
   private String creationDate;
   private String lastUpdateDate;
   private String createdBy;
   private String lastUpdatedBy;
   private String softwareFMIFlag;
   private String programTiming;
   private String fmiHoursUnit;
   private String noTestUnits;
   private String noTestDays;
   private String status;
   private ArrayList<ProfileApprovalData> approvals;
   private boolean assignedUnits;
   private boolean assignedTasks;

   public ProfileData(String profileId,String profileName,String description,String creationDate,String lastUpdateDate,
        String createdBy,String lastUpdatedBy,String softwareFMIFlag,String programTiming,String fmiHoursUnit,
        String noTestUnits,String noTestDays,String status){
        this.profileId = profileId;
        this.profileName = profileName;
        this.description = description;
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.createdBy = createdBy;
        this.lastUpdatedBy = lastUpdatedBy;
        this.softwareFMIFlag = softwareFMIFlag;
        this.programTiming = programTiming;
        this.fmiHoursUnit = fmiHoursUnit;
        this.noTestUnits = noTestUnits;
        this.noTestDays = noTestDays;
        this.status = status;
        approvals = new ArrayList<>();
        assignedUnits = assignedTasks = false;
   }
   
    /**
     * @return the profileId
     */
    public String getProfileId() {
        return profileId;
    }

    /**
     * @param profileId the profileId to set
     */
    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    /**
     * @return the profileName
     */
    public String getProfileName() {
        return profileName;
    }

    /**
     * @param profileName the profileName to set
     */
    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the creationDate
     */
    public String getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastUpdateDate
     */
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * @param lastUpdateDate the lastUpdateDate to set
     */
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the lastUpdatedBy
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * @param lastUpdatedBy the lastUpdatedBy to set
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /**
     * @return the softwareFMIFlag
     */
    public String getSoftwareFMIFlag() {
        return softwareFMIFlag;
    }

    /**
     * @param softwareFMIFlag the softwareFMIFlag to set
     */
    public void setSoftwareFMIFlag(String softwareFMIFlag) {
        this.softwareFMIFlag = softwareFMIFlag;
    }

    /**
     * @return the programTiming
     */
    public String getProgramTiming() {
        return programTiming;
    }

    /**
     * @param programTiming the programTiming to set
     */
    public void setProgramTiming(String programTiming) {
        this.programTiming = programTiming;
    }

    /**
     * @return the fmiHoursUnit
     */
    public String getFmiHoursUnit() {
        return fmiHoursUnit;
    }

    /**
     * @param fmiHoursUnit the fmiHoursUnit to set
     */
    public void setFmiHoursUnit(String fmiHoursUnit) {
        this.fmiHoursUnit = fmiHoursUnit;
    }

    /**
     * @return the noTestUnits
     */
    public String getNoTestUnits() {
        return noTestUnits;
    }

    /**
     * @param noTestUnits the noTestUnits to set
     */
    public void setNoTestUnits(String noTestUnits) {
        this.noTestUnits = noTestUnits;
    }

    /**
     * @return the noTestDays
     */
    public String getNoTestDays() {
        return noTestDays;
    }

    /**
     * @param noTestDays the noTestDays to set
     */
    public void setNoTestDays(String noTestDays) {
        this.noTestDays = noTestDays;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the approval
     */
    public ArrayList<ProfileApprovalData> getApprovals() {
        return approvals;
    }

    /**
     * @param approval the approval to set
     */
    public void setApprovals(ArrayList<ProfileApprovalData> approval) {
        this.approvals = approval;
    }
    
    public void addApproval(ProfileApprovalData p){
        this.approvals.add(p);
    }
    
    public String toString(){
        return this.profileName;
    }

    /**
     * @return the assignedUnits
     */
    public boolean hasAssignedUnits() {
        return assignedUnits;
    }

    /**
     * @param assignedUnits the assignedUnits to set
     */
    public void setAssignedUnits(boolean assignedUnits) {
        this.assignedUnits = assignedUnits;
    }

    /**
     * @return the assignedTasks
     */
    public boolean hasAssignedTasks() {
        return assignedTasks;
    }

    /**
     * @param assignedTasks the assignedTasks to set
     */
    public void setAssignedTasks(boolean assignedTasks) {
        this.assignedTasks = assignedTasks;
    }
}

//GE Confidential