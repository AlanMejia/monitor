
package util.lookup;

public class LookupValueData {
    
    private String id;
    private String typeId;
    private String code;
    private String valueMeaning;
    private String valueDescription;
    private String valueFlag;
    
    public LookupValueData(String id, String typeId, String code, String valueMeaning, String valueDescription, String valueFlag){
        this.id = id;
        this.typeId = typeId;
        this.code = code;
        this.valueMeaning = valueMeaning;
        this.valueDescription = valueDescription;
        this.valueFlag = valueFlag;
    }

    public LookupValueData(String code, String meaning, String description, String enabledFlag){
        this.valueDescription = description;
        this.valueMeaning = meaning;
        this.code = code;
        this.valueFlag = enabledFlag;
    }
    
    public LookupValueData(String code, String meaning, String description){
        this.valueDescription = description;
        this.valueMeaning = meaning;
        this.code = code;
    }    
    
    /**
     * @return the typeId
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * @param typeId the typeId to set
     */
    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the valueMeaning
     */
    public String getValueMeaning() {
        return valueMeaning;
    }

    /**
     * @param valueMeaning the valueMeaning to set
     */
    public void setValueMeaning(String valueMeaning) {
        this.valueMeaning = valueMeaning;
    }

    /**
     * @return the valueDescription
     */
    public String getValueDescription() {
        return valueDescription;
    }

    /**
     * @param valueDescription the valueDescription to set
     */
    public void setValueDescription(String valueDescription) {
        this.valueDescription = valueDescription;
    }

    /**
     * @return the valueFlag
     */
    public String getValueFlag() {
        return valueFlag;
    }

    /**
     * @param valueFlag the valueFlag to set
     */
    public void setValueFlag(String valueFlag) {
        this.valueFlag = valueFlag;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    
    public String toString(){
        return this.code;
    }
    
}

//GE Confidential