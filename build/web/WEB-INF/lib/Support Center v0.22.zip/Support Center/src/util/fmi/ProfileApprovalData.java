/*
    v 0.16
    - Added
 */

package util.fmi;

public class ProfileApprovalData {
    private String organization;
    private String customer;
    private String engApproval;
    private String fieldApproval;
    private String customerApproval;
    private String startDate;
    private String priority;
    private String priorityComment;

    public ProfileApprovalData(String organization, String customer, String engApproval, String fieldApproval,
            String customerApproval, String startDate, String priority, String priorityComment){
        this.organization = organization;
        this.customer = customer;
        this.engApproval = engApproval;
        this.fieldApproval = fieldApproval;
        this.customerApproval = customerApproval;
        this.startDate = startDate;
        this.priority = priority;
        this.priorityComment = priorityComment;        
    }
    
    /**
     * @return the organization
     */
    public String getOrganization() {
        return organization;
    }

    /**
     * @param organization the organization to set
     */
    public void setOrganization(String organization) {
        this.organization = organization;
    }

    /**
     * @return the customer
     */
    public String getCustomer() {
        return customer;
    }

    /**
     * @param customer the customer to set
     */
    public void setCustomer(String customer) {
        this.customer = customer;
    }

    /**
     * @return the engApproval
     */
    public String getEngApproval() {
        return engApproval;
    }

    /**
     * @param engApproval the engApproval to set
     */
    public void setEngApproval(String engApproval) {
        this.engApproval = engApproval;
    }

    /**
     * @return the fieldApproval
     */
    public String getFieldApproval() {
        return fieldApproval;
    }

    /**
     * @param fieldApproval the fieldApproval to set
     */
    public void setFieldApproval(String fieldApproval) {
        this.fieldApproval = fieldApproval;
    }

    /**
     * @return the customerApproval
     */
    public String getCustomerApproval() {
        return customerApproval;
    }

    /**
     * @param customerApproval the customerApproval to set
     */
    public void setCustomerApproval(String customerApproval) {
        this.customerApproval = customerApproval;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(String priority) {
        this.priority = priority;
    }

    /**
     * @return the priorityComment
     */
    public String getPriorityComment() {
        return priorityComment;
    }

    /**
     * @param priorityComment the priorityComment to set
     */
    public void setPriorityComment(String priorityComment) {
        this.priorityComment = priorityComment;
    }
}

//GE Confidential