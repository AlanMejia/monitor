/*
  v 0.15
  - Added constructor for Feedback Summary
  - Added "Sorted" field, for the Feedback Summary
*/ 

package util.feedback;
 
 import java.sql.Date;
 
 public class FeedbackData
 {
   private String feedbackId;
   private Date feedbackDate;
   private Date feedbackTime;
   private String status;
   private String userId;
   private String userName;
   private String customerLocation;
   private String customer;
   private String subsection;
   private String suggestion;
   private String contactEmail;
   private String response;
   private String critical;
   private String phoneNumber;
   private String responseBy;
   private String roadNumber;
   private Date responseDate;
   private String currentStatus;
   private String itComments;
   private String workNotes;
   private String personalNotes;
   private String assignedTo;
   private Date lastAssigned;
   private boolean sorted;
   
   public FeedbackData() {}
   
   public FeedbackData(String feedbackId, Date feedbackDate, Date feedbackTime, String status, String userId, String userName, String customerLocation, String customer, String subsection, String suggestion, String contactEmail, String response, String critical, String phoneNumber, String responseBy, String roadNumber, String currentStatus, String itComments)
   {
     this.feedbackId = feedbackId;
     this.feedbackDate = feedbackDate;
     this.feedbackTime = feedbackTime;
     this.status = status;
     this.userId = userId;
     this.userName = userName;
     this.customerLocation = customerLocation;
     this.customer = customer;
     this.subsection = subsection;
     this.suggestion = suggestion;
     this.contactEmail = contactEmail;
     this.response = response;
     this.critical = critical;
     this.phoneNumber = phoneNumber;
     this.responseBy = responseBy;
     this.roadNumber = roadNumber;
     this.currentStatus = currentStatus;
     this.itComments = itComments;
     this.sorted = false;
   }
   
   public FeedbackData(String feedbackId, Date feedbackDate, String status, String subsection, String customer, String customerLocation, String suggestion, String responseBy, Date responseDate, String response, String critical, String workNotes, String personalNotes, String assignedTo, Date lastAssigned)
   {
     this.feedbackId = feedbackId;
     this.feedbackDate = feedbackDate;
     this.status = status;
     this.customerLocation = customerLocation;
     this.customer = customer;
     this.subsection = subsection;
     this.suggestion = suggestion;
     this.response = response;
     this.critical = critical;
     this.responseBy = responseBy;
     this.responseDate = responseDate;
     this.workNotes = workNotes;
     this.personalNotes = personalNotes;
     this.assignedTo = assignedTo;
     this.lastAssigned = lastAssigned;
     this.sorted = false;     
   }
   
   public FeedbackData(String feedbackId, Date feedbackDate, String status, String userName, String customerLocation, 
           String subsection, String suggestion, String itComments){
       this.feedbackId = feedbackId;
       this.feedbackDate = feedbackDate;
       this.status = status;
       this.userName = userName;
       this.customerLocation = customerLocation;
       this.subsection = subsection;
       this.suggestion = suggestion;
       this.itComments = itComments;       
       this.sorted = false;
   }
 
   // Added constructor for FB Summary
   public FeedbackData(String feedbackId, Date feedbackDate, String critical, String customerLocation, String userId, 
           String subsection, String userFullName, String suggestion, String roadNumber, String itComments, String currentStatus,
           String custName, String response){
       this.feedbackId = feedbackId;
       this.feedbackDate = feedbackDate;
       this.critical = critical;
       this.customerLocation = customerLocation;
       this.userId = userId;
       this.userName = userFullName;
       this.subsection = subsection;
       this.suggestion = suggestion;
       this.roadNumber = roadNumber;
       this.itComments = itComments;
       this.currentStatus = currentStatus;      
       this.customer = custName;
       this.response = response;
       this.sorted = false;
   }
   
   public String getFeedbackId()
   {
     return this.feedbackId;
   }
   
   public void setFeedbackId(String feedbackId)
   {
     this.feedbackId = feedbackId;
   }
   
   public Date getFeedbackDate()
   {
     return this.feedbackDate;
   }
   
   public void setFeedbackDate(Date feedbackDate)
   {
     this.feedbackDate = feedbackDate;
   }
   
   public String getStatus()
   {
     return this.status;
   }
   
   public void setStatus(String status)
   {
     this.status = status;
   }
   
   public String getUserId()
   {
     return this.userId;
   }
   
   public void setUserId(String userId)
   {
     this.userId = userId;
   }
   
   public String getUserName()
   {
     return this.userName;
   }
   
   public void setUserName(String userName)
   {
     this.userName = userName;
   }
   
   public String getCustomerLocation()
   {
     return this.customerLocation;
   }
   
   public void setCustomerLocation(String customerLocation)
   {
     this.customerLocation = customerLocation;
   }
   
   public String getCustomer()
   {
     return this.customer;
   }
   
   public void setCustomer(String customer)
   {
     this.customer = customer;
   }
   
   public String getSubsection()
   {
     return this.subsection;
   }
   
   public void setSubsection(String subsection)
   {
     this.subsection = subsection;
   }
   
   public String getSuggestion()
   {
     return this.suggestion;
   }
   
   public void setSuggestion(String suggestion)
   {
     this.suggestion = suggestion;
   }
   
   public String getContactEmail()
   {
     return this.contactEmail;
   }
   
   public void setContactEmail(String contactEmail)
   {
     this.contactEmail = contactEmail;
   }
   
   public String getResponse()
   {
     return this.response;
   }
   
   public void setResponse(String response)
   {
     this.response = response;
   }
   
   public String getCritical()
   {
     return this.critical;
   }
   
   public void setCritical(String critical)
   {
     this.critical = critical;
   }
   
   public String getPhoneNumber()
   {
     return this.phoneNumber;
   }
   
   public void setPhoneNumber(String phoneNumber)
   {
     this.phoneNumber = phoneNumber;
   }
   
   public Date getFeedbackTime()
   {
     return this.feedbackTime;
   }
   
   public void setFeedbackTime(Date feedbackTime)
   {
     this.feedbackTime = feedbackTime;
   }
   
 
 
   public String getResponseBy()
   {
     return this.responseBy;
   }
   
 
 
   public void setResponseBy(String responseBy)
   {
     this.responseBy = responseBy;
   }
   
 
 
   public String getRoadNumber()
   {
     return this.roadNumber;
   }
   
 
 
   public void setRoadNumber(String roadNumber)
   {
     this.roadNumber = roadNumber;
   }
   
 
 
   public Date getResponseDate()
   {
     return this.responseDate;
   }
   
 
 
   public void setResponseDate(Date responseDate)
   {
     this.responseDate = responseDate;
   }
   
 
 
   public String getWorkNotes()
   {
     return this.workNotes;
   }
   
 
 
   public void setWorkNotes(String workNotes)
   {
     this.workNotes = workNotes;
   }
   
 
 
   public String getPersonalNotes()
   {
     return this.personalNotes;
   }
   
 
 
   public void setPersonalNotes(String personalNotes)
   {
     this.personalNotes = personalNotes;
   }
   
 
 
   public String getAssignedTo()
   {
     return this.assignedTo;
   }
   
 
 
   public void setAssignedTo(String assignedTo)
   {
     this.assignedTo = assignedTo;
   }
   
 
 
   public Date getLastAssigned()
   {
     return this.lastAssigned;
   }
   
 
 
   public void setLastAssigned(Date lastAssigned)
   {
     this.lastAssigned = lastAssigned;
   }
   
 
 
   public String getCurrentStatus()
   {
     return this.currentStatus;
   }
   
 
 
   public void setCurrentStatus(String currentStatus)
   {
     this.currentStatus = currentStatus;
   }
   
 
 
   public String getItComments()
   {
     return null == this.itComments ? "-" : this.itComments;
   }
   
 
 
   public void setItComments(String itComments)
   {
     this.itComments = itComments;
   }

    /**
     * @return the sorted
     */
    public boolean isSorted() {
        return sorted;
    }

    /**
     * @param sorted the sorted to set
     */
    public void setSorted(boolean sorted) {
        this.sorted = sorted;
    }
 }


//GE Confidential