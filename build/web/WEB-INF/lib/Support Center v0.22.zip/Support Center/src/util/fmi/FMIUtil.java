 package util.fmi;
 
 
 
 public class FMIUtil
 {
   public static String translateMandatoryStatus(String status){
       if(null == status){
           return "None";
       }
       switch(status){
           case "1":
               return "Mandatory";
           case "2":
               return "Auto-Assign";
           case "3":
               return "Regular";
           default:
               return "Regular";               
       }
   }  
     
   public static String translateProfileStatus(String status)
   {
     if (null == status) {
       return "000";
     }
     switch (Integer.parseInt(status)) {
     case 100: 
       return "IN-PROCESS";
     case 200: 
       return "AUTHOR APPROVED";
     case 250: 
       return "MATERIAL APPROVED";
     case 300: 
       return "TOLLGATE APPROVED";
     case 400: 
       return "SUSPENDED";
     case 800: 
       return "CANCELLED";
     case 900: 
       return "CLOSED";
     }
     return "ERROR";
   }
   
 
   public static String translateFMIStatus(String status)
   {
     if (null == status) {
       return "000";
     }
     switch (Integer.parseInt(status)) {
     case 100: 
       return "Being Authored";
     case 200: 
       return "Field Review";
     case 250: 
       return "Material Complete";
     case 300: 
       return "Released to Field";
     case 400: 
       return "Suspended";
     case 800: 
       return "Cancelled";
     case 900: 
       return "Closed";
     }
     return "ERROR";
   }
 }


//GE Confidential