 package util;
 
 import java.io.IOException;
 import java.util.Properties;
 
 public class PropertyManager
 {
   private Properties properties;
   public static final int USER_NAME = 0;
   public static final int BUILD = 1;
   
   public PropertyManager()
   {
     loadProperties();
   }
   
   private void storeProperties() {
     try {
       this.properties.store(new java.io.FileOutputStream("SupportCenter.properties"), null);
     }
     catch (IOException ex) {}
   }
   
   private void loadProperties() {
     this.properties = new Properties();
     try {
       this.properties.load(new java.io.FileInputStream("SupportCenter.properties"));
       if (null == this.properties.getProperty("username")) {
         this.properties.setProperty("username", "-");
       }
       if (null == this.properties.getProperty("BUILD")) {
         this.properties.setProperty("BUILD", "0");
       }
     } catch (java.io.FileNotFoundException e) {
       setDefaultProperties();
       try {
         this.properties.store(new java.io.FileOutputStream("SupportCenter.properties"), null);
       }
       catch (IOException ex) {}
     }
     catch (IOException e) {}catch (Exception e) {
       setDefaultProperties();
     }
   }
   
 
   private void setDefaultProperties()
   {
     this.properties.setProperty("username", "-");
     this.properties.setProperty("BUILD", "0");
   }
   
   public String getProperty(int key) {
     switch (key) {
     case 0: 
       return this.properties.getProperty("username", "-");
     case 1: 
       return this.properties.getProperty("BUILD", "0");
     }
     return new String();
   }
   
 
   public void setProperty(int key, String value)
   {
     switch (key) {
     case 0: 
       this.properties.setProperty("username", value);
       break;
     case 1: 
       this.properties.setProperty("build", value);
       break;
     }
     
     
 
     storeProperties();
   }
 }


//GE Confidential