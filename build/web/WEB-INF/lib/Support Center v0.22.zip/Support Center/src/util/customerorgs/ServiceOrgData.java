 package util.customerorgs;
 
 public class ServiceOrgData
 {
   private String customerId;
   private String id;
   private String code;
   private String name;
   private String customerName;
   
   public ServiceOrgData(String customerId, String id, String code, String name) {
     this.customerId = customerId;
     this.id = id;
     this.code = code;
     this.name = name;
   }
   
   public ServiceOrgData(String customerId, String customerName, String id, String code, String name) {
     this.customerId = customerId;
     this.id = id;
     this.code = code;
     this.name = name;
     this.customerName = customerName;
   }
   
 
 
   public String getCustomerId()
   {
     return this.customerId;
   }
   
 
 
   public void setCustomerId(String customerId)
   {
     this.customerId = customerId;
   }
   
 
 
   public String getId()
   {
     return this.id;
   }
   
 
 
   public void setId(String id)
   {
     this.id = id;
   }
   
 
 
   public String getCode()
   {
     return this.code;
   }
   
 
 
   public void setCode(String code)
   {
     this.code = code;
   }
   
 
 
   public String getName()
   {
     return this.name;
   }
   
 
 
   public void setName(String name)
   {
     this.name = name;
   }
   
 
 
   public String getCustomerName()
   {
     return this.customerName;
   }
   
 
 
   public void setCustomerName(String customerName)
   {
     this.customerName = customerName;
   }
   
   public String toString() {
     return getName();
   }
 }


//GE Confidential