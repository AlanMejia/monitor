/*
  v 0.15
  - Added the EGU/DCD/WCD/SDIS and CAB entries.
  v 0.16
  - Corrected the download validation. 
*/ 

package util.workorder;
 
 public class WorkorderData
 {
   private String id;
   private String number;   
   private String lastUpdateDate;   
   private String lastUpdatedBy;   
   private String creationDate;   
   private String createdBy;   
   private String status;   
   private String inshopReason;   
   private String outOfShopRepair;   
   private String serviceOrg;   
   private String locomotiveId;
   private String egu;
   private String cab;
   private String sdis;
   private String dcd;
   private String wcd;
   private String software;
   private String woComments;
   private String turnoverNotes;
   
 
   public WorkorderData() {}
   
   public WorkorderData(String id, String number, String lastUpdateDate, String lastUpdatedBy, 
           String creationDate, String createdBy, String status, String inshopReason, String outOfShopRepair, 
           String serviceOrg, String locomotiveId, String egu, String cab, String sdis, String dcd, String wcd, 
           String software, String woComments, String turnoverNotes)
   {
     this.id = id;
     this.number = number;
     this.lastUpdateDate = lastUpdateDate;
     this.lastUpdatedBy = lastUpdatedBy;
     this.creationDate = creationDate;
     this.createdBy = createdBy;
     this.status = status;
     this.inshopReason = inshopReason;
     this.outOfShopRepair = outOfShopRepair;
     this.serviceOrg = serviceOrg;
     this.locomotiveId = locomotiveId;
     this.egu = egu;
     this.cab = cab;
     this.sdis = sdis;
     this.woComments = woComments;
     this.turnoverNotes = turnoverNotes;
     if(dcd == null){
        this.dcd = "no value";
     } else {
        this.dcd = dcd;
     }
     
     if(wcd == null){
        this.wcd = "no value";
     } else {
        this.wcd = wcd;
     }
     this.software = software;
   }
   
   public WorkorderData(String id, String number, String status) {
     this.id = id;
     this.number = number;
     this.status = status;
   }
   
 
 
   public String getId()
   {
     return this.id;
   }
   
 
 
   public void setId(String id)
   {
     this.id = id;
   }
   
 
 
   public String getNumber()
   {
     return this.number;
   }
   
 
 
   public void setNumber(String number)
   {
     this.number = number;
   }
   
   public String toString() {
     return this.number + " (" + WorkorderUtil.translateWOStatus(this.status) + ")";
   }
   
 
 
   public String getLastUpdateDate()
   {
     return this.lastUpdateDate;
   }
   
 
 
   public void setLastUpdateDate(String lastUpdateDate)
   {
     this.lastUpdateDate = lastUpdateDate;
   }
   
 
 
   public String getLastUpdatedBy()
   {
     return this.lastUpdatedBy;
   }
   
 
 
   public void setLastUpdatedBy(String lastUpdatedBy)
   {
     this.lastUpdatedBy = lastUpdatedBy;
   }
   
 
 
   public String getCreationDate()
   {
     return this.creationDate;
   }
   
 
 
   public void setCreationDate(String creationDate)
   {
     this.creationDate = creationDate;
   }
   
 
 
   public String getCreatedBy()
   {
     return this.createdBy;
   }
   
 
 
   public void setCreatedBy(String createdBy)
   {
     this.createdBy = createdBy;
   }
   
 
 
   public String getStatus()
   {
     return this.status;
   }
   
 
 
   public void setStatus(String status)
   {
     this.status = status;
   }
   
 
 
   public String getInshopReason()
   {
     return this.inshopReason;
   }
   
 
 
   public void setInshopReason(String inshopReason)
   {
     this.inshopReason = inshopReason;
   }
   
 
 
   public String getOutOfShopRepair()
   {
     return this.outOfShopRepair;
   }
   
 
 
   public void setOutOfShopRepair(String outOfShopRepair)
   {
     this.outOfShopRepair = outOfShopRepair;
   }
   
 
 
   public String getServiceOrg()
   {
     return this.serviceOrg;
   }
   
 
 
   public void setServiceOrg(String serviceOrg)
   {
     this.serviceOrg = serviceOrg;
   }
   
 
 
   public String getLocomotiveId()
   {
     return this.locomotiveId;
   }
   
 
 
   public void setLocomotiveId(String locomotiveId)
   {
     this.locomotiveId = locomotiveId;
   }

    /**
     * @return the egu
     */
    public String getEgu() {
        
        if(null == egu)
            return getClass().getResource("/util/resources/na.gif").toString();
        
        switch(egu){
            case "0":
                return getClass().getResource("/util/resources/red_egu.gif").toString();
            case "1":
                return getClass().getResource("/util/resources/green_egu.gif").toString();
            case "2":
                return getClass().getResource("/util/resources/na.gif").toString();                
        }
        return "0";
    }

    /**
     * @param egu the egu to set
     */
    public void setEgu(String egu) {
        this.egu = egu;
    }

    /**
     * @return the cab
     */
    public String getCab() {
        
        if(null == cab){
            return getClass().getResource("/util/resources/na.gif").toString();
        }
        
        switch(cab){
            case "0":
                return getClass().getResource("/util/resources/green_cab.gif").toString();
            case "1":
                return getClass().getResource("/util/resources/red_cab.gif").toString();
            case "2":
                return getClass().getResource("/util/resources/na.gif").toString();                
        }
        return "0";

    }

    /**
     * @param cab the cab to set
     */
    public void setCab(String cab) {
        this.cab = cab;
    }

    /**
     * @return the sdis
     */
    public String getSdis() {
        
        if(null == sdis){
            return getClass().getResource("/util/resources/na.gif").toString();                            
        }
        
        switch(sdis){
            case "4":
                return getClass().getResource("/util/resources/red_sdis.gif").toString();
            case "3":
                return getClass().getResource("/util/resources/green_sdis.gif").toString();
            case "2":
                return getClass().getResource("/util/resources/na.gif").toString();                
        }
        return "0";
    }

    /**
     * @param sdis the sdis to set
     */
    public void setSdis(String sdis) {
        this.sdis = sdis;
    }

    public String validateDCDWCD(){        
         
        if(dcd.equals("Fail") || wcd.equals("Fail")){
            return getClass().getResource("/util/resources/yellow_dcd.gif").toString();
        } else        
        if(dcd.equals("Pass") && wcd.equals("Pass")){
            return getClass().getResource("/util/resources/green_dcd.gif").toString();
        } else {
            return getClass().getResource("/util/resources/red_dcd.gif").toString();
        }               
    }
    
    /**
     * @return the dcd
     */
    public String getDcd() {
        return dcd;
    }

    /**
     * @param dcd the dcd to set
     */
    public void setDcd(String dcd) {
        this.dcd = dcd;
    }

    /**
     * @return the wcd
     */
    public String getWcd() {
        return wcd;
    }

    /**
     * @param wcd the wcd to set
     */
    public void setWcd(String wcd) {
        this.wcd = wcd;
    }

    /**
     * @return the software
     */
    public String getSoftware() {
        if(null == software){
            return getClass().getResource("/util/resources/na.gif").toString();
        } else 
        if(software.equals("N/A")){
            return getClass().getResource("/util/resources/na.gif").toString();
        } else
        if(software.equals("No")){
            return getClass().getResource("/util/resources/red_sw.gif").toString();
        } else
        if(software.equals("Yes")){
            return getClass().getResource("/util/resources/green_sw.gif").toString();
        } else {
            return getClass().getResource("/util/resources/na_sw.gif").toString();
        }               
    }

    /**
     * @param software the software to set
     */
    public void setSoftware(String software) {
        this.software = software;
    }

    /**
     * @return the woComments
     */
    public String getWoComments() {
        return woComments;
    }

    /**
     * @param woComments the woComments to set
     */
    public void setWoComments(String woComments) {
        this.woComments = woComments;
    }

    /**
     * @return the turnoverNotes
     */
    public String getTurnoverNotes() {
        return turnoverNotes;
    }

    /**
     * @param turnoverNotes the turnoverNotes to set
     */
    public void setTurnoverNotes(String turnoverNotes) {
        this.turnoverNotes = turnoverNotes;
    }
 }


//GE Confidential