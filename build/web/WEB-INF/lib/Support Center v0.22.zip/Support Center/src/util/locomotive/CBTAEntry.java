 package util.locomotive;
 
 public class CBTAEntry
 {
   private String configValueid;   
   private String value;   
   private String paramId;   
 
   public CBTAEntry(String configValueid, String value, String paramId)
   {
     this.configValueid = configValueid;
     this.value = value;
     this.paramId = paramId;
   }
    
 
   public String getId()
   {
     return this.configValueid;
   }
   
 
 
   public void setId(String configValueid)
   {
     this.configValueid = configValueid;
   }
   
 
 
   public String getValue()
   {
     return this.value;
   }
   
 
 
   public void setValue(String value)
   {
     this.value = value;
   }
   
 
 
   public String getParamID()
   {
     return this.paramId;
   }
   
 
 
   public void setParamID(String paramID)
   {
     this.paramId = paramID;
   }
   
   public String toString() {
     return this.value;
   }
   
   public boolean equals(Object obj) {
     if (null == obj) {
       return false;
     }
     
     if (getClass() != obj.getClass()) {
       return false;
     }
     
     CBTAEntry val = (CBTAEntry)obj;
     if (!getValue().toLowerCase().equals(val.getValue().toLowerCase())) {
       return false;
     }
     return true;
   }
 }

//GE Confidential