 /*
   v 0.21
   - Added status of "50" for ASSIGNED. For the Loco_assign table.
*/

 package util.servicesheet;
  
 public class ServiceSheetUtil
 {
   public static String translateSSStatus(String status)
   {
     if (null == status) {
       return "000";
     }
     switch (Integer.parseInt(status)) {
     case 900: 
       return "CLOSED";
     case 300: 
       return "OPEN";
     case 100: 
       return "PENDING";
     case 750: 
       return "DEFERRED";
     case 50:
       return "ASSIGNED";
     }
     return "ERROR";
   }
 }

//GE Confidential