
package util.lookup;

import java.util.ArrayList;

public class LookupTypeData {
    private String typeId;
    private String type;
    private String typeMeaning;
    private String typeDescription;
    private ArrayList<LookupValueData> values;
    
    public LookupTypeData(String typeId, String type, String typeMeaning, String typeDescription, ArrayList<LookupValueData> values){
        this.typeId = typeId;
        this.type = type;
        this.typeMeaning = typeMeaning;
        this.typeDescription = typeDescription;
        this.values = values;
    }

    public LookupTypeData(String typeId, String type, String typeMeaning, String typeDescription){
        this.typeId = typeId;
        this.type = type;
        this.typeMeaning = typeMeaning;
        this.typeDescription = typeDescription;
        this.values = new ArrayList<>();
    }    

    //For the OracleLookup type, much more primitive.
    public LookupTypeData(String type){
        this.type = type;
        this.values = new ArrayList<>();
    }
    /**
     * @return the typeId
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * @param typeId the typeId to set
     */
    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the typeMeaning
     */
    public String getTypeMeaning() {
        return typeMeaning;
    }

    /**
     * @param typeMeaning the typeMeaning to set
     */
    public void setTypeMeaning(String typeMeaning) {
        this.typeMeaning = typeMeaning;
    }

    /**
     * @return the typeDescription
     */
    public String getTypeDescription() {
        return typeDescription;
    }

    /**
     * @param typeDescription the typeDescription to set
     */
    public void setTypeDescription(String typeDescription) {
        this.typeDescription = typeDescription;
    }

    /**
     * @return the values
     */
    public ArrayList<LookupValueData> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(ArrayList<LookupValueData> values) {
        this.values = values;
    }
    
    public void addValue(LookupValueData d){
        values.add(d);
    }
    
    public String toString(){
        return this.type;
    }
    
}

//GE Confidential