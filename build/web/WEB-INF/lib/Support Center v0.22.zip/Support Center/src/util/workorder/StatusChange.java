
package util.workorder;

public class StatusChange {
    
    private String WO_ID;
    private String Status;
    private String New_Date;

 public StatusChange(String wo,String stat,String date){     
     this.WO_ID=wo;
     this.Status=stat;
     this.New_Date=date;     
  }
    /**
     * @return the WO_ID
     */
    public String getWO_ID() {
        return WO_ID;
    }

    /**
     * @param WO_ID the WO_ID to set
     */
    public void setWO_ID(String WO_ID) {
        this.WO_ID = WO_ID;
    }

    /**
     * @return the Status
     */
    public String getStatus() {
        return Status;
    }

    /**
     * @param Status the Status to set
     */
    public void setStatus(String Status) {
        this.Status = Status;
    }

    /**
     * @return the New_Date
     */
    public String getNew_Date() {
        return New_Date;
    }

    /**
     * @param New_Date the New_Date to set
     */
    public void setNew_Date(String New_Date) {
        this.New_Date = New_Date;
    }
    
    public String toString(){     
           return "<HTML><B>Wo_Id: </B>"+ this.WO_ID+", <B>Status:</B> "+this.Status+", <B>Date:</B> "+this.New_Date;         
    }       

    
    
}
