 package util;
 
 import eservicesmanager.SupportCenter;
 import java.io.File;
 import java.io.PrintStream;
 import java.text.DateFormat;
 import java.text.SimpleDateFormat;
 import java.util.Date;
 import org.apache.commons.io.FileUtils;
 
 public class JErrorLog
 {
   public static void createErrorLog(String failedIn, String query, String error)
   {
     try
     {
       Date date = new Date();
       StringBuffer buf = new StringBuffer();
       DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy-HH_mm_ss");
       buf.append("******** ERROR LOG INFORMATION FOE ESERVICES MANAGER V. " + SupportCenter.getVersion() + " ********\n");
       buf.append("******************* ERROR IN " + failedIn + "*******************\n");
       buf.append("Happened on: " + dateFormat.format(date) + "\n");
       buf.append("--- Query Ran --- \n\n");
       buf.append(query);
       buf.append("\n\n-----------------\n");
       buf.append("--- Error information---\n\n");
       buf.append(error);
       buf.append("\n\n------------------------\n");
       
       FileUtils.write(new File("ErrorLog_" + dateFormat.format(date) + ".log"), buf.toString());
     } catch (Exception e) {
       System.out.println("AAAAAYIIIIIEEEEEEEEEEEEEEEEEEE");
       e.printStackTrace();
     }
   }
 }


//GE Confidential