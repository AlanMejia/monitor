/*
  v 0.15
  - Created.
*/

package util.material;

public class ComponentData {
    
   private String serviceOrg;
   private String componentID;
   private String componentName;
   private String traceable;
   private String emissionCritical;
   private String software;
   private String positionTracked;
   private String removalReasonRequired;

   public ComponentData(String serviceOrg, String componentID, String componentName, String traceable, String emissionCritical,            
           String positionTracked, String removalReasonRequired, String software){
       this.serviceOrg = serviceOrg;
       this.componentID = componentID;
       this.componentName = componentName;
       this.traceable = traceable;
       this.emissionCritical = emissionCritical;
       this.software = software;
       this.positionTracked = positionTracked;
       this.removalReasonRequired = removalReasonRequired;
   }
   
    /**
     * @return the serviceOrg
     */
    public String getServiceOrg() {
        return serviceOrg;
    }

    /**
     * @param serviceOrg the serviceOrg to set
     */
    public void setServiceOrg(String serviceOrg) {
        this.serviceOrg = serviceOrg;
    }

    /**
     * @return the componentID
     */
    public String getComponentID() {
        return componentID;
    }

    /**
     * @param componentID the componentID to set
     */
    public void setComponentID(String componentID) {
        this.componentID = componentID;
    }

    /**
     * @return the traceable
     */
    public String getTraceable() {
        return traceable;
    }

    /**
     * @param traceable the traceable to set
     */
    public void setTraceable(String traceable) {
        this.traceable = traceable;
    }

    /**
     * @return the emissionCritical
     */
    public String getEmissionCritical() {
        return emissionCritical;
    }

    /**
     * @param emissionCritical the emissionCritical to set
     */
    public void setEmissionCritical(String emissionCritical) {
        this.emissionCritical = emissionCritical;
    }

    /**
     * @return the software
     */
    public String getSoftware() {
        return software;
    }

    /**
     * @param software the software to set
     */
    public void setSoftware(String software) {
        this.software = software;
    }

    /**
     * @return the positionTracked
     */
    public String getPositionTracked() {
        return positionTracked;
    }

    /**
     * @param positionTracked the positionTracked to set
     */
    public void setPositionTracked(String positionTracked) {
        this.positionTracked = positionTracked;
    }

    /**
     * @return the removalReasonRequired
     */
    public String getRemovalReasonRequired() {
        return removalReasonRequired;
    }

    /**
     * @param removalReasonRequired the removalReasonRequired to set
     */
    public void setRemovalReasonRequired(String removalReasonRequired) {
        this.removalReasonRequired = removalReasonRequired;
    }

    /**
     * @return the componentName
     */
    public String getComponentName() {
        return componentName;
    }

    /**
     * @param componentName the componentName to set
     */
    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }
   
    
}

//GE Confidential