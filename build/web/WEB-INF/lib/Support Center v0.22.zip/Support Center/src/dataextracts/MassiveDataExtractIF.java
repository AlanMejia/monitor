/*
  v 0.18
  - Added
  v 0.19
  - Added a validation to the amount of available lines, no funny business: no negative amounts and nothing more than 10k lines.
  v 0.20
  - It will now truncate the existing DataExtract.xls file if it finds it.
  - The extracted file will now contain the query that was run at the bottom. Added an option to print out the SQL in a different file for those that think it more useful that way.
  - Added a "Output file name" field, if filled it will create the extract/query file with that description. If the field is empty it will use the default "DataExtract".
  v 0.22
  - Text file name and SQL in another file checkbox did not protect themselves when the program was running. This has been corrected.

 Pending.
 - Color the SQL?
 
*/

package dataextracts;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;
import javax.swing.event.InternalFrameEvent;
import jsyntaxpane.DefaultSyntaxKit;
import org.apache.commons.io.FileUtils;
import util.OracleConnectionManager;

public class MassiveDataExtractIF extends JInternalFrame {
    
    private ArrayList<String> columnNames;
    private boolean done = false;
    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;  
    private StringBuffer buf;    
    private SimpleDateFormat dateFormatter;
    private File dumpDirectory;
    private int lines;
    private long total;
    
    public MassiveDataExtractIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) { 

      super(title, resizable, closable, maximizable, iconifiable);
         
      columnNames = new ArrayList<>();
      dateFormatter = new SimpleDateFormat("HH:mm");
      lines = 0;
      total = 0;
      
      initComponents();
         
      this.getRootPane().setDefaultButton(btnPullData);
     addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
       public void internalFrameOpened(InternalFrameEvent e) {}
       
       public void internalFrameClosing(InternalFrameEvent e) { MassiveDataExtractIF.this.cleanClose(); }
       
       public void internalFrameClosed(InternalFrameEvent e) {}
       
       public void internalFrameIconified(InternalFrameEvent e) {}
       
       public void internalFrameDeiconified(InternalFrameEvent e) {}
       
       public void internalFrameActivated(InternalFrameEvent e) {}
       
       public void internalFrameDeactivated(InternalFrameEvent e) {}
     });
           
     progressBar.setVisible(false);
     
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/     
     
    }
   
   private void cleanClose() { 
       dispose();
       try {
        rs.close();       
       }catch(Exception e){
           
       }
   }

   private void fetchMassiveData() {
     new Thread(new Runnable() {
       public void run() {
         loadMassiveData();
         while (!done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         javax.swing.SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }       
   
   private void loadMassiveData(){
      
       //Initialize
       protectFields();
       buf = new StringBuffer();
       areaLog.setText("Initiating massive data extraction.");
       
       try {
        //1. Validate the SQL
        conn = util.OracleConnectionManager.getConnection(getComboConnection());

       if (conn == null) {
         log("Database Connection could not be established, please check your network status.");
         releaseFields();
         return;
       }       
           
       log("Connection to DB established, validating SQL...");
       
       //Try to verify the SQL
       prepStm = conn.prepareStatement(areaSQL.getText());
       rs = prepStm.executeQuery();
       
       //2. Ask the user where to put the file
       log("SQL validated. Where should I put the file?");
       JFileChooser fc = new JFileChooser();
       fc.setFileFilter(new util.FolderFilter());
       fc.setFileSelectionMode(1);
     
       int returnVal = fc.showOpenDialog(this);
       
       String fileName = (txtFileName.getText().trim().isEmpty() ? "DataExtract." : txtFileName.getText().trim());
     
        if (returnVal == 0) {
          try {
            String ext = sanitizeExtension();
            String filePath = fc.getSelectedFile().getAbsolutePath() + "\\\\" + fileName + "." + ext;
            dumpDirectory = new File(filePath);
            dumpDirectory.delete(); //Clear the file if it already exists.
            dumpDirectory = new File(filePath);
            log("Folder selection successful. Creating file in \"" + dumpDirectory.getAbsolutePath() + "\"");
          } catch (Exception e) {
            log("Problem while selecting folder. Error message: " + e.getMessage());
            releaseFields();
            return;
          }       
        } else {
            log("Folder selection cancelled.");
            releaseFields();
            return;
        }
        
        //3. Now start pulling the data.
        //First lets get which columns we're pulling
        log("Pulling data...");
        ResultSetMetaData meta = prepStm.getMetaData();        
        for(int i = 1; i <= meta.getColumnCount(); i++){
            columnNames.add(meta.getColumnName(i));
        }
        
        buf = new StringBuffer();
        int counter = 0;
        int times = 1;
        total = 0;
        String delimiter = getDelimiter();
        if(rs.next()){
            
            //Set the headers.
            for(String c : columnNames){
                buf.append(c + " " + delimiter);
            }            
            buf.append("\n");            
            
            //Now the data
            do{
                for(String c : columnNames){
                    buf.append(rs.getString(c) + delimiter);
                }
                buf.append("\n");
                
                //Report progress
                counter++;
                if(counter == lines){
                    try {                
                        FileUtils.writeStringToFile(dumpDirectory, buf.toString(), true);
                    } catch (IOException ex) {
                        log("Could not write to file. Reason: " + ex.getMessage());
                        releaseFields();
                        return;
                    }
                    buf = new StringBuffer();
                    total += counter;
                    counter = 0;
                    log("Saved " + (times++ * lines) + " records.");                
                }                
            }while(rs.next());
            
            total += counter;
            //Done, save the remnant
            try {                
                //Does the user want the SQL in another file?
                if(chkBoxSQLSeparate.isSelected()){
                    String sqlFilePath = fc.getSelectedFile().getAbsolutePath() + "\\\\" + fileName + ".sql";
                    File sqlDumpDirectory = new File(sqlFilePath);                    
                    FileUtils.writeStringToFile(sqlDumpDirectory, areaSQL.getText(), false);
                    FileUtils.writeStringToFile(dumpDirectory, buf.toString(), true);
                } else {
                    buf.append("\n\nQuery Run:\n" + areaSQL.getText());
                    FileUtils.writeStringToFile(dumpDirectory, buf.toString(), true);
                }
            } catch (IOException ex) {
                log("Could not write to file. Reason: " + ex.getMessage());
                releaseFields();
                return;
            }
            log("Finished! Saved " + total + " lines. phew!");   
            releaseFields();
            
            
        } else {
            log("No data found.");
            releaseFields();
            return;
        }
        
          }catch(SQLException e){
              log("Invalid SQL. Error message: " + e.getMessage());
              releaseFields();
              return;
          } 

   }
      
   private String sanitizeExtension(){
       String ext = txtExtension.getText().replace(".", "").trim(); //clean up the data extension in case the add the "."
       if(ext.toLowerCase().equals("sql") && chkBoxSQLSeparate.isSelected())
           return "csv";
       else 
           return ext;
   }
   
   private String getDelimiter(){
       if(radioDelimiterTab.isSelected())
           return "\t";
       else if(radioDelimiterComma.isSelected())
           return ",";
       else if(radioDelimiterSemicolon.isSelected())
           return ";";
       else if(radioDelimiterOther.isSelected())
           return txtDelimiterOther.getText().trim();
       else
           return "\t";
   }
   
   private void protectFields(){       
    radioDelimiterTab.setEnabled(false);
    radioDelimiterComma.setEnabled(false);
    radioDelimiterSemicolon.setEnabled(false);
    radioDelimiterOther.setEnabled(false);
    txtDelimiterOther.setEditable(false);
    btnPullData.setEnabled(false);
    txtLines.setEditable(false);
    txtExtension.setEditable(false);
    comboEnvironment.setEnabled(false);
    areaSQL.setEditable(false);
    txtFileName.setEditable(false);
    chkBoxSQLSeparate.setEnabled(false);
    progressBar.setVisible(true);
    
   }

   private void releaseFields(){
    radioDelimiterTab.setEnabled(true);
    radioDelimiterComma.setEnabled(true);
    radioDelimiterSemicolon.setEnabled(true);
    radioDelimiterOther.setEnabled(true);
    txtDelimiterOther.setEditable(true);
    btnPullData.setEnabled(true);
    txtLines.setEditable(true);
    txtExtension.setEditable(true);
    comboEnvironment.setEnabled(true);
    areaSQL.setEditable(true);
    txtFileName.setEditable(true);
    chkBoxSQLSeparate.setEnabled(true);    
    progressBar.setVisible(false);       
   }
      
   private void log(String l){
       areaLog.setText(areaLog.getText() + "\n\n" + dateFormatter.format(Calendar.getInstance().getTime()) + ": " + l);
       areaLog.setCaretPosition(areaLog.getText().length());   
   }
   
   private int getComboConnection()
   {
     switch (comboEnvironment.getSelectedIndex()) {
     case 0: 
       return OracleConnectionManager.PROD;
     case 1: 
       return OracleConnectionManager.STG;
     case 2: 
       return OracleConnectionManager.DEV;
     case 3: 
       return OracleConnectionManager.INT_DEV;
     }
     return 0;
   }     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgDelimiters = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        scrollSQL = new javax.swing.JScrollPane();
        areaSQL = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        radioDelimiterTab = new javax.swing.JRadioButton();
        radioDelimiterComma = new javax.swing.JRadioButton();
        radioDelimiterSemicolon = new javax.swing.JRadioButton();
        radioDelimiterOther = new javax.swing.JRadioButton();
        txtDelimiterOther = new javax.swing.JTextField();
        btnPullData = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtLines = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtExtension = new javax.swing.JTextField();
        chkBoxSQLSeparate = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaLog = new javax.swing.JTextArea();
        progressBar = new javax.swing.JProgressBar();
        comboEnvironment = new javax.swing.JComboBox();
        txtFileName = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        jLabel1.setText("Input your query below:");

        areaSQL.setColumns(20);
        areaSQL.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        areaSQL.setLineWrap(true);
        areaSQL.setRows(5);
        areaSQL.setWrapStyleWord(true);
        scrollSQL.setViewportView(areaSQL);

        jLabel2.setText("Results delimited by a:");

        bgDelimiters.add(radioDelimiterTab);
        radioDelimiterTab.setSelected(true);
        radioDelimiterTab.setText("Tab");
        radioDelimiterTab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDelimiterTabActionPerformed(evt);
            }
        });

        bgDelimiters.add(radioDelimiterComma);
        radioDelimiterComma.setText("Comma");
        radioDelimiterComma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDelimiterCommaActionPerformed(evt);
            }
        });

        bgDelimiters.add(radioDelimiterSemicolon);
        radioDelimiterSemicolon.setText("Semicolon");
        radioDelimiterSemicolon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDelimiterSemicolonActionPerformed(evt);
            }
        });

        bgDelimiters.add(radioDelimiterOther);
        radioDelimiterOther.setText("Other: ");
        radioDelimiterOther.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDelimiterOtherActionPerformed(evt);
            }
        });

        txtDelimiterOther.setEnabled(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(radioDelimiterOther)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDelimiterOther, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(radioDelimiterSemicolon)
                    .addComponent(radioDelimiterComma)
                    .addComponent(jLabel2)
                    .addComponent(radioDelimiterTab))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(radioDelimiterTab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(radioDelimiterComma)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(radioDelimiterSemicolon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioDelimiterOther)
                    .addComponent(txtDelimiterOther, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnPullData.setText("Pull Data!");
        btnPullData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPullDataActionPerformed(evt);
            }
        });

        jLabel3.setText("Report progress every:");

        txtLines.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtLines.setText("5000");
        txtLines.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLinesFocusGained(evt);
            }
        });

        jLabel4.setText("lines");

        jLabel5.setText("File extension: ");

        txtExtension.setText("xls");
        txtExtension.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtExtensionFocusGained(evt);
            }
        });

        chkBoxSQLSeparate.setText("SQL in separate file");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtExtension, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(chkBoxSQLSeparate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(txtLines, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLines, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(chkBoxSQLSeparate)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtExtension, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel6.setText("Log:");

        areaLog.setEditable(false);
        areaLog.setColumns(20);
        areaLog.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        areaLog.setLineWrap(true);
        areaLog.setRows(5);
        areaLog.setWrapStyleWord(true);
        jScrollPane2.setViewportView(areaLog);

        progressBar.setIndeterminate(true);

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        txtFileName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFileNameFocusGained(evt);
            }
        });

        jLabel7.setText("Output file name:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(112, 112, 112)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFileName, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(scrollSQL))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboEnvironment, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnPullData, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFileName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnPullData))
                    .addComponent(scrollSQL))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void radioDelimiterOtherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDelimiterOtherActionPerformed
        txtDelimiterOther.setEnabled(true);
    }//GEN-LAST:event_radioDelimiterOtherActionPerformed

    private void radioDelimiterSemicolonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDelimiterSemicolonActionPerformed
        hideOtherTextDelimiter();
    }//GEN-LAST:event_radioDelimiterSemicolonActionPerformed

    private void radioDelimiterCommaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDelimiterCommaActionPerformed
        hideOtherTextDelimiter();
    }//GEN-LAST:event_radioDelimiterCommaActionPerformed

    private void radioDelimiterTabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDelimiterTabActionPerformed
        hideOtherTextDelimiter();
    }//GEN-LAST:event_radioDelimiterTabActionPerformed

    private void btnPullDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPullDataActionPerformed
        
        if(txtLines.getText().trim().isEmpty() || txtExtension.getText().trim().isEmpty()){
            areaLog.setText("Please make sure the Line and Extension text fields have values.");
            return;
        }
        
        if(radioDelimiterOther.isSelected() && txtDelimiterOther.getText().trim().isEmpty()){
            areaLog.setText("Please type a delimeter to use between the fields.");
            return;            
        }
        
        try {
           lines = Integer.parseInt(txtLines.getText().trim()); 
           if(lines <= 0 && lines > 10000){
               areaLog.setText("Please set a number of lines no more than 10,000.");
               return;
           }
               
        }catch(Exception e){
            areaLog.setText("Line counter should be a number.");
        }
                
        fetchMassiveData();
    }//GEN-LAST:event_btnPullDataActionPerformed

    private void txtLinesFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLinesFocusGained
        txtLines.selectAll();
    }//GEN-LAST:event_txtLinesFocusGained

    private void txtExtensionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtExtensionFocusGained
        txtExtension.selectAll();
    }//GEN-LAST:event_txtExtensionFocusGained

    private void txtFileNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFileNameFocusGained
        txtFileName.selectAll();
    }//GEN-LAST:event_txtFileNameFocusGained

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
       // scrollSQL.setViewportView(areaSQL);
    }//GEN-LAST:event_formComponentResized

    private void hideOtherTextDelimiter(){
        txtDelimiterOther.setText("");
        txtDelimiterOther.setEnabled(false);        
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaLog;
    private javax.swing.JTextArea areaSQL;
    private javax.swing.ButtonGroup bgDelimiters;
    private javax.swing.JButton btnPullData;
    private javax.swing.JCheckBox chkBoxSQLSeparate;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JRadioButton radioDelimiterComma;
    private javax.swing.JRadioButton radioDelimiterOther;
    private javax.swing.JRadioButton radioDelimiterSemicolon;
    private javax.swing.JRadioButton radioDelimiterTab;
    private javax.swing.JScrollPane scrollSQL;
    private javax.swing.JTextField txtDelimiterOther;
    private javax.swing.JTextField txtExtension;
    private javax.swing.JTextField txtFileName;
    private javax.swing.JTextField txtLines;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential
