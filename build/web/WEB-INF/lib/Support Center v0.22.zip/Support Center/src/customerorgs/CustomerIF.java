
/* Change notes:
  0.9
  - BugFix: Table will go to 100% width
  - BugFix: all text boxes should now select the text when they gain focus.
 0.12
  - Restored as a netbeans form.
  - Blank Customer Phonetics will now come up as "-" instead of "null"
 v 0.17
  - Added a checkbox to optionally filter out customers without service orgs. It will be checked by default.
 v 0.19
  - Changed button from "Run!" to "Search" for consistency
  - Added the Search Button as default button. Now the "Enter" key will default to the search action. Lovely.
 v 0.20
  - Implemented search functionality.
  - Added a validation to inform when there is no network connection.
*/

package customerorgs;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.customerorgs.*;

public class CustomerIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;
    private boolean done = false;
    private StringBuffer buf = new StringBuffer();
    private ArrayList<CustomerData> customers;
    private ArrayList<Integer> findHits;
    private int hitIndex;
    private String findText;
    
    public CustomerIF(final JDesktopPane desktop, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){

        super(title, resizable, closable, maximizable, iconifiable);        
        initComponents();

        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
        
        
        this.getRootPane().setDefaultButton(btnSearch);
        customers = new ArrayList<CustomerData>();
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { CustomerIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );   
    
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     
    }

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }     
    
    private void cleanClose() {
     // this.parent.customerInfoClosed();
      dispose();
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtCustomerName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCustomerPhonetic = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtCustomerId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCustomerNumber = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        comboEnvironment = new javax.swing.JComboBox();
        chkBoxWithOrgs = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        jLabel1.setText("Name:");

        txtCustomerName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCustomerNameFocusGained(evt);
            }
        });

        jLabel2.setText("Phonetic:");

        txtCustomerPhonetic.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCustomerPhoneticFocusGained(evt);
            }
        });

        jLabel3.setText("ID:");

        txtCustomerId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCustomerIdFocusGained(evt);
            }
        });

        jLabel4.setText("Number:");

        txtCustomerNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCustomerNumberFocusGained(evt);
            }
        });

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        chkBoxWithOrgs.setSelected(true);
        chkBoxWithOrgs.setText("with Orgs only");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCustomerName))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCustomerPhonetic, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCustomerId, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCustomerNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(chkBoxWithOrgs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chkBoxWithOrgs))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCustomerPhonetic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtCustomerId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtCustomerNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch)
                    .addComponent(jLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        if(txtCustomerName.getText().isEmpty() && txtCustomerId.getText().isEmpty() && txtCustomerNumber.getText().isEmpty()
                && txtCustomerPhonetic.getText().isEmpty()){
            editorResults.setText("Please fill at least one field.");
        } else {   
           loadList();
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtCustomerNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCustomerNameFocusGained
        txtCustomerName.selectAll();
    }//GEN-LAST:event_txtCustomerNameFocusGained

    private void txtCustomerPhoneticFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCustomerPhoneticFocusGained
        txtCustomerPhonetic.selectAll();
    }//GEN-LAST:event_txtCustomerPhoneticFocusGained

    private void txtCustomerIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCustomerIdFocusGained
        txtCustomerId.selectAll();
    }//GEN-LAST:event_txtCustomerIdFocusGained

    private void txtCustomerNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCustomerNumberFocusGained
        txtCustomerNumber.selectAll();
    }//GEN-LAST:event_txtCustomerNumberFocusGained

    private void loadList(){
        new Thread(new Runnable() {
          public void run() {        
            fetchCustomerList();
            while (!done)
              try {
                Thread.sleep(100L);
              }
              catch (InterruptedException ie) {
              }
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                //progressBar.setValue((int)(Math.random() * 100.0D));
              }
            });
          }
        }).start();        
    }

    //To call whenever the form is running, so as to avoid corrupted data
    private void protectFields(){
       btnSearch.setEnabled(false);
       txtCustomerName.setEditable(false); 
       txtCustomerId.setEditable(false);
       txtCustomerNumber.setEditable(false);
       txtCustomerPhonetic.setEditable(false);
       comboEnvironment.setEnabled(false);
    }
    
    //To call whenever the form is done running, to allow editing again
    private void releaseFields(){
       btnSearch.setEnabled(true);
       txtCustomerName.setEditable(true); 
       txtCustomerId.setEditable(true);
       txtCustomerNumber.setEditable(true);
       txtCustomerPhonetic.setEditable(true);        
       comboEnvironment.setEnabled(true);
    }
    
    private void fetchCustomerList(){
        
        String customerQuery = "";
      try {
            done = false;
            protectFields();
            editorResults.setText("");
            buf = new StringBuffer();            
            customers.clear();
                   
            editorResults.setText("<HTML><H2>Pulling Records...</H2></HTML>");
            
            //Fetch the user Information first           
            conn = OracleConnectionManager.getConnection(getComboConnection());

            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            customerQuery = " select cust.customer_id, cust.customer_name, cust.customer_number, NVL(cust.customer_name_phonetic, '-') as customer_name_phonetic  \n" +
                    "from ar_customers cust\n" +
                    "where 1 = 1 \n" +
                    (txtCustomerId.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(customer_id) = '" + txtCustomerId.getText().trim().toLowerCase() + "' ") +
                    (txtCustomerName.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(customer_name) like '%" + txtCustomerName.getText().trim().toLowerCase() + "%' ") +                  
                    (txtCustomerNumber.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(customer_number) = '" + txtCustomerNumber.getText().trim().toLowerCase() + "' ") +                  
                    (txtCustomerPhonetic.getText().trim().toLowerCase().isEmpty() ? "" : " AND lower(customer_name_phonetic) like '%" + txtCustomerPhonetic.getText().trim().toLowerCase() + "%' ") +                  
                    (chkBoxWithOrgs.isSelected() ? " AND exists (select * from gets_lms_customer_orgs_v where customer_id = cust.customer_id)" : "") +
                    " order by customer_name asc ";
            prepStm = conn.prepareStatement(customerQuery); 
            rs = prepStm.executeQuery();
            if(rs.next()){
                do {
                   customers.add(new CustomerData(rs.getString("customer_id"),
                   rs.getString("customer_name"),
                   rs.getString("customer_number"),
                   rs.getString("customer_name_phonetic")));
                } while(rs.next());
            } else  {
                buf.append("No customers found with this criteria.");
                editorResults.setText(buf.toString());
                releaseFields();
                done = true;
                return;
            }
            
            //Pull the service Orgs, if any
            prepStm.close();
            rs.close();    

            
            for(CustomerData c : customers){
                prepStm = conn.prepareStatement("select orgs.service_organization_id, orgs.organization_code, orgs.name  from gets_lms_customer_orgs_v orgs\n" +
                                "where orgs.customer_id = " + c.getCustomerId() + " \n" +
                                "order by name asc");
                rs = prepStm.executeQuery();
                if(rs.next()){
                  do {
                      c.addServiceOrg(new ServiceOrgData(c.getCustomerId(),
                           rs.getString("service_organization_id"),
                      rs.getString("organization_code"),
                      rs.getString("name")));
                  }while(rs.next());
                } else {
                    c.addServiceOrg(new ServiceOrgData("-", "-", "-", "No Service Organizations available."));
                }
                
                prepStm.close();
                rs.close();
            }
                
            //Display the data
            buf.append("<html> <body>");            
            for(CustomerData c : customers){
                buf.append(" <table border= 1 width=100%> " +
                "<tr>"+
                 "<TD colwidth=33% bgcolor=\"#92CDDC\"><B>Customer: </B></TD>"+
                 "<TD colwidth=66% colspan = 2><B> " + c.getCustomerName() + " </B></TD>"+
                "</tr>"+
                "<tr>"+
                  "  <td colspan=\"1\" colwidth=33% ><B>ID: </B>" + c.getCustomerId() + "</td>" +
                  "  <td colspan=\"1\" colwidth=33% ><B>Number: </B>" + c.getCustomerNumber() + "</td>" +
                  "  <td colspan=\"1\" colwidth=33% ><B>Phonetic: </B>" + c.getCustomerPhonetic() + "</td>" +
                "</tr> ");
                buf.append("<tr><TD align=\"CENTER\" bgcolor=\"#92CDDC\" colspan=3><B>Service Shops</B></TD></tr><tr>" +
                    "<td colspan=\"1\" align=\"CENTER\" colwidth=70% bgcolor=\"#92CDDC\"><B>Name</B></td>\n" +
                    "<td colspan=\"1\" align=\"CENTER\" colwidth=15% bgcolor=\"#92CDDC\"><B>Code</B></td>\n" +
                    "<td colspan=\"1\" align=\"CENTER\" colwidth=15% bgcolor=\"#92CDDC\"><B>Id</B></td>\n" +
                    "</tr> ");
                for(ServiceOrgData o : c.getServiceOrgs()){
                    buf.append("<tr>\n" +
                        "<td colspan=\"1\">" + o.getName() + "</td>" +
                        "<td colspan=\"1\" align=\"CENTER\" >" + o.getCode() + "</td>" +
                        "<td colspan=\"1\" align=\"CENTER\" >" + o.getId() + "</td>" +
                     "</tr>");                    
                }
                buf.append("</table><BR>");                                
            }
            
            buf.append("</body></html>");
            
            editorResults.setText(buf.toString());
            releaseFields();
            done = true;
            
      }catch(Exception e){
                //------- Logging begins ----------------
                buf = new StringBuffer("");
                buf.append("-- Fields --\n");
                buf.append("txtCustomerName: \"" + txtCustomerName.getText() + "\"\n");
                buf.append("txtCustomerPhonetic: \"" + txtCustomerPhonetic.getText() + "\"\n");
                buf.append("txtCustomerId: \"" + txtCustomerId.getText() + "\"\n");
                buf.append("txtCustomerNumber: " + txtCustomerNumber.getText() + "\"\n");
                buf.append("Environment: " + getComboConnection() + "\"\n");
                buf.append("-- Exception --\n");
                buf.append("Could not pull Customer details because: \n");                
                buf.append(e.getMessage());
                JErrorLog.createErrorLog("Class: CustomerIF, Method: fetchCustomerList",
                        customerQuery + "\n\n", buf.toString());
                //------- Logging ends ----------------       
                //Escape gracefully
                editorResults.setText("An Error occurred, please check the logs.");
                releaseFields();                
      }
    }

    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            case 3: 
                return OracleConnectionManager.INT_DEV;                
            default:
                return OracleConnectionManager.PROD;
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JCheckBox chkBoxWithOrgs;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCustomerId;
    private javax.swing.JTextField txtCustomerName;
    private javax.swing.JTextField txtCustomerNumber;
    private javax.swing.JTextField txtCustomerPhonetic;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential