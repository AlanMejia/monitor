
/* Change notes:
  0.9
  - BugFix: NULL service sheet comments now correctly show as blank.
  - BugFix: Fixed display of workorders with no service sheets to span the entire table.
  0.10
  - Enh: If there is a mismatch between the service sheet's Loco ID and the workscope's loco ID, the service_sheet_id will light up red.
  0.13
  - Restored from version 0.10
  - Validated the entry from the workorder id functionality. (Thanks Jaime!)
  - Fixed a typo on the log's output.
  - Added an aggregator function to the service sheet's query to avoid issues with duplicated values in inner queries (Thanks Jaime!)
  v 0.15
  - Cleaned up the display of the workorder details a bit, tried to make it easier on the eyes, please let me know if you do not think it so.
  - Added a small table that will display the information on the monitor board, it will show: egu, cab, sdis, dcd/wcd and SW download.
  v 0.16
  - (Hopefully) fixed the hilariously broken monitor board settings.
  - changed the editorWO to editorResults and added a validation in case there is no connection when you look for a wo.
  - Changed the display of dates to a consistent format 'DD-Mon-yyyy HH24:MI:SS'
  v 0.17
  - Fixed a typo in the logging report which would not include the txtWorkorderId in the report.
  - Corrected a problem that would hang the form if an error occurred when looking for a locomotive.
  v 0.19  
  - Added a friendly "pulling records" message to note that something is happening. The progress bar messes up all the layouts. Because Swing.
  - Added the "Workorder Comments" and "Turnover Notes" fields to the workorder details.
  v 0.20
  - Added a NVL function to the "Workorder Comments" and "Turnover Notes" so we don't get those ugly "null"s.
  - Search implemented.
*/

package workorder;

import eservicesmanager.SupportCenter;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.net.URI;
import java.sql.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import servicesheet.DefectInfoHelperIF;
import servicesheet.FMIInfoHelperIF;
import servicesheet.MaterialInfoHelperIF;
import servicesheet.OpenTaskInfoHelperIF;
import util.JErrorLog;
import util.OracleConnectionManager;
import util.servicesheet.ServiceSheetUtil;
import util.workorder.WorkorderData;
import util.workorder.WorkorderUtil;

public class WorkorderIF extends JInternalFrame {

    private Connection conn;
    private PreparedStatement prepStm;
    private ResultSet rs;    
    private boolean done = false;    
    private SimpleDateFormat dateFormatter;    
    private StringBuffer buf;
    private SupportCenter parent;
    private ArrayList<WorkorderData> workorders;
    private DefaultListModel model;
    private int selIndexWO;
    private WorkorderData selectedWO;
    private ArrayList<Integer> findHits;
    private int hitIndex;   
    private String findText;
    private JDesktopPane desktop;
    
    /**
     * Creates new form WorkorderIF
     */
    public WorkorderIF() {
        initComponents();
    }

    public WorkorderIF(final JDesktopPane desktop, SupportCenter parent, String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable){

        super(title, resizable, closable, maximizable, iconifiable);        
        this.parent = parent;
        this.desktop = desktop;
        model = new DefaultListModel();
        model.addElement("Click Go Button");
        initComponents();
        
        /*********************************** Implement FIND functionality ************************************/
        findHits = new ArrayList<>();
        hitIndex = 0;
        editorResults.getActionMap().put("find", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    findText = JOptionPane.showInputDialog(null, "Find text: ", "Find in Results", JOptionPane.QUESTION_MESSAGE);
                    if(null != findText && !findText.isEmpty())
                        findTextInResults();
                }
            });        
        editorResults.getActionMap().put("next result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(++hitIndex == findHits.size())
                        hitIndex = 0;
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });  
        editorResults.getActionMap().put("previous result", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    if(null == findText || findText.isEmpty())
                        return;
                    
                    if(hitIndex == 0){
                        hitIndex = findHits.size() - 1;                        
                    } else {
                        hitIndex--;
                    }
                    editorResults.setCaretPosition(findHits.get(hitIndex));                    
                }
            });           
        
        InputMap inputMap = editorResults.getInputMap();
        //CTRL+F = finds
        KeyStroke ctrlF = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK);
        inputMap.put(ctrlF, "find");
        //F3 searches forward
        KeyStroke f3 = KeyStroke.getKeyStroke("F3");
        inputMap.put(f3, "next result");
        //SHIFT+F3 searches backwards
        KeyStroke shiftF3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.SHIFT_MASK);
        inputMap.put(shiftF3, "previous result");        
        /*********************************** Implement FIND functionality ************************************/
        
        this.getRootPane().setDefaultButton(btnFetchWOList);
        
        listWO.setModel(model);
        //listWO = new JList(model);
        listWO.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        listWO.setLayoutOrientation(JList.VERTICAL);                                    
        workorders = new ArrayList();
        selectedWO = new WorkorderData();
        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm z");
        
    addInternalFrameListener(new InternalFrameListener() {
      public void internalFrameOpened(InternalFrameEvent e) {  }

      public void internalFrameClosing(InternalFrameEvent e) { WorkorderIF.this.cleanClose(); } 
      public void internalFrameClosed(InternalFrameEvent e) {
      }
      public void internalFrameIconified(InternalFrameEvent e) {
      }
      public void internalFrameDeiconified(InternalFrameEvent e) {
      }
      public void internalFrameActivated(InternalFrameEvent e) {
      }
      public void internalFrameDeactivated(InternalFrameEvent e) {
      } } );              
    
     /************************* IMPLEMENT ESC TO CLOSE *****************************/
     KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
     Action action = new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
             desktop.getSelectedFrame().dispose();
         }
     };
     desktop.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape, "escape");
     desktop.getActionMap().put("escape", action); 
     /************************* IMPLEMENT ESC TO CLOSE *****************************/    
    }
    
    private void cleanClose() {    
      dispose();
    }      
    

    private void findTextInResults(){
        Document document = editorResults.getDocument();
        editorResults.getHighlighter().removeAllHighlights();
        findHits.clear();
        try {
            String find = findText.toLowerCase();
            for (int index = 0; index + find.length() < document.getLength(); index++) {
                String match = document.getText(index, find.length());
                if (find.equals(match.toLowerCase())) {
                    DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                    editorResults.getHighlighter().addHighlight(index, index + find.length(), highlightPainter);
                    findHits.add(index);
                }
            }
            
            editorResults.setCaretPosition(findHits.get(hitIndex));
            
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        scrollWOList = new javax.swing.JScrollPane();
        listWO = new javax.swing.JList();
        jPanel3 = new javax.swing.JPanel();
        btnFetchWOList = new javax.swing.JButton();
        chkBoxWildCard = new javax.swing.JCheckBox();
        txtRoadNumber = new javax.swing.JTextField();
        txtLocomotiveId = new javax.swing.JTextField();
        txtAARRoad = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        comboEnvironment = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorResults = new javax.swing.JEditorPane();
        btnFMIDetails = new javax.swing.JButton();
        btnMaterials = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtWorkorderId = new javax.swing.JTextField();
        btnFetchWODetails = new javax.swing.JButton();
        btnDefects = new javax.swing.JButton();
        btnTasks = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        listWO.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        listWO.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listWO.setLayoutOrientation(javax.swing.JList.VERTICAL_WRAP);
        listWO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listWOMouseClicked(evt);
            }
        });
        scrollWOList.setViewportView(listWO);

        btnFetchWOList.setText("Go");
        btnFetchWOList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFetchWOListActionPerformed(evt);
            }
        });

        chkBoxWildCard.setText("%%");
        chkBoxWildCard.setToolTipText("Check for wildcard comparison");

        txtRoadNumber.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtRoadNumber.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtRoadNumber.setText("RN");
        txtRoadNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRoadNumberFocusGained(evt);
            }
        });

        txtLocomotiveId.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtLocomotiveId.setText("Locomotive ID");
        txtLocomotiveId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtLocomotiveIdFocusGained(evt);
            }
        });

        txtAARRoad.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        txtAARRoad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAARRoad.setText("AAR Road");
        txtAARRoad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAARRoadFocusGained(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(txtLocomotiveId)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkBoxWildCard))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(txtAARRoad, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFetchWOList))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFetchWOList)
                    .addComponent(txtRoadNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAARRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkBoxWildCard)
                    .addComponent(txtLocomotiveId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollWOList)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(10, 10, 10))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(scrollWOList, javax.swing.GroupLayout.DEFAULT_SIZE, 409, Short.MAX_VALUE))
        );

        comboEnvironment.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRD", "STG", "DEV", "INT DEV" }));

        editorResults.setEditable(false);
        editorResults.setContentType("text/html"); // NOI18N
        jScrollPane1.setViewportView(editorResults);

        btnFMIDetails.setText("FMI Details");
        btnFMIDetails.setEnabled(false);
        btnFMIDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFMIDetailsActionPerformed(evt);
            }
        });

        btnMaterials.setText("Materials");
        btnMaterials.setEnabled(false);
        btnMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaterialsActionPerformed(evt);
            }
        });

        jLabel2.setText("WO ID:");

        txtWorkorderId.setText("#########");
        txtWorkorderId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtWorkorderIdFocusGained(evt);
            }
        });

        btnFetchWODetails.setText("Go");
        btnFetchWODetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFetchWODetailsActionPerformed(evt);
            }
        });

        btnDefects.setText("Defects");
        btnDefects.setEnabled(false);
        btnDefects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDefectsActionPerformed(evt);
            }
        });

        btnTasks.setText("Tasks");
        btnTasks.setEnabled(false);
        btnTasks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTasksActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(btnFMIDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDefects, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTasks, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtWorkorderId, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnFetchWODetails)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 250, Short.MAX_VALUE)
                        .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboEnvironment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(txtWorkorderId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFetchWODetails))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFMIDetails)
                    .addComponent(btnMaterials)
                    .addComponent(btnDefects)
                    .addComponent(btnTasks)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFetchWOListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFetchWOListActionPerformed
       if(txtRoadNumber.getText().isEmpty() && txtAARRoad.getText().isEmpty() && txtLocomotiveId.getText().isEmpty()){
          editorResults.setText("Please fill at least one field.");  
       } else if(txtRoadNumber.getText().equals("RN") && txtAARRoad.getText().equals("AAR Road") && txtLocomotiveId.getText().equals("Locomotive ID")){
          editorResults.setText("Please fill at least one field.");  
       } else {
          editorResults.setText("");
          fetchWOList();        
       }
    }//GEN-LAST:event_btnFetchWOListActionPerformed

    private void txtAARRoadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAARRoadFocusGained
        txtAARRoad.selectAll();
    }//GEN-LAST:event_txtAARRoadFocusGained

    private void txtRoadNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRoadNumberFocusGained
        txtRoadNumber.selectAll();
    }//GEN-LAST:event_txtRoadNumberFocusGained

    private void listWOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listWOMouseClicked
     if (evt.getClickCount() == 2) {
       selIndexWO = listWO.locationToIndex(evt.getPoint());
       protectFields();
       btnMaterials.setEnabled(false);
       btnFMIDetails.setEnabled(false);
       btnDefects.setEnabled(false);
       btnTasks.setEnabled(false);
       fetchWODetails(((WorkorderData)workorders.get(selIndexWO)).getId());
     }
    }//GEN-LAST:event_listWOMouseClicked

    private void txtLocomotiveIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtLocomotiveIdFocusGained
        txtLocomotiveId.selectAll();
    }//GEN-LAST:event_txtLocomotiveIdFocusGained

    private void txtWorkorderIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtWorkorderIdFocusGained
        txtWorkorderId.selectAll();
    }//GEN-LAST:event_txtWorkorderIdFocusGained

    private void btnFMIDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFMIDetailsActionPerformed
        new FMIInfoHelperIF(desktop, parent, selectedWO, getComboConnection(), "FMI info for " + selectedWO.getNumber(), 
        true, true, true, true);
    }//GEN-LAST:event_btnFMIDetailsActionPerformed

    private void btnMaterialsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaterialsActionPerformed
        new MaterialInfoHelperIF(desktop, parent, selectedWO, getComboConnection(), "Material info for " + selectedWO.getNumber(), 
        true, true, true, true);
    }//GEN-LAST:event_btnMaterialsActionPerformed

    private void btnFetchWODetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFetchWODetailsActionPerformed
        if(txtWorkorderId.getText().equals("#########")){
            editorResults.setText("Please enter a WO ID.");
        } else {
            //is it a number? Lets try
            try {
              int woId = Integer.parseInt(txtWorkorderId.getText().trim());
              if(woId > 0){
                protectFields();
                btnMaterials.setEnabled(false);
                btnFMIDetails.setEnabled(false);
                btnDefects.setEnabled(false);
                btnTasks.setEnabled(false);
                fetchWODetails(txtWorkorderId.getText().trim());                  
              }else {
                editorResults.setText("Please enter a WO ID.");                  
              }
            } catch(Exception e){
                editorResults.setText("Please enter a WO ID.");
            }
        }
    }//GEN-LAST:event_btnFetchWODetailsActionPerformed

    private void btnDefectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDefectsActionPerformed
        new DefectInfoHelperIF(desktop, parent, selectedWO, getComboConnection(), "Defect info for " + selectedWO.getNumber(), true, true, true, true);
    }//GEN-LAST:event_btnDefectsActionPerformed

    private void btnTasksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTasksActionPerformed
        new OpenTaskInfoHelperIF(desktop, parent, selectedWO, getComboConnection(), "Open Task info for " + selectedWO.getNumber(), true, true, true, true);
    }//GEN-LAST:event_btnTasksActionPerformed

    private void fetchWOList(){
        new Thread(new Runnable() {
          public void run() {        
            fetchWOListing();
            while (!done)
              try {
                Thread.sleep(100L);
              }
              catch (InterruptedException ie) {
              }
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                //progressBar.setValue((int)(Math.random() * 100.0D));
              }
            });
          }
        }).start();        
    }   

   private void fetchWODetails(final String workorderId)
   {
     new Thread(new Runnable() {
       public void run() {
         fetchWOFullDetails(workorderId);
         while (!WorkorderIF.this.done) {
           try {
             Thread.sleep(100L);
           }
           catch (InterruptedException ie) {}
         }
         SwingUtilities.invokeLater(new Runnable()
         {
           public void run() {}
         });
       }
     }).start();
   }    
    
   private void protectFields()
   {
     btnFetchWOList.setEnabled(false);
     listWO.setEnabled(false);
     txtLocomotiveId.setEditable(false);
     txtAARRoad.setEditable(false);
     txtRoadNumber.setEditable(false);
     chkBoxWildCard.setEnabled(false);
     comboEnvironment.setEnabled(false);
     btnFetchWODetails.setEnabled(false);
     
     
   }
   
   private void releaseFields() {
     btnFetchWOList.setEnabled(true);
     listWO.setEnabled(true);
     txtLocomotiveId.setEditable(true);
     txtAARRoad.setEditable(true);
     txtRoadNumber.setEditable(true);
     chkBoxWildCard.setEnabled(true);
     comboEnvironment.setEnabled(true);
     btnFetchWODetails.setEnabled(true);
     
     
   }
    
   private void fetchWOFullDetails(String workorderId) {
     String serviceSheetQuery = "";
     String serviceStatusQuery = "";
     String woDetailsQuery = "";
     boolean isOnMonitorBoard = false;
     try
     {
       conn = OracleConnectionManager.getConnection(getComboConnection());       
       if (conn == null) {
         editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
         releaseFields();
         return;
       }                   
       
       buf = new StringBuffer();
       editorResults.setText("<HTML><H2>Pulling Workorder Details...</H2></HTML>");
       protectFields();
       
       woDetailsQuery = " select to_char(wo.last_update_date, 'DD-Mon-yyyy HH24:MI:SS') as last_update_date, to_char(wo.creation_date, 'DD-Mon-yyyy HH24:MI:SS') as creation_date, workorder_status_code, wo.inshop_reason_code, wo.out_of_shop_repair_flag,\n" +
        " (select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = wo.last_updated_by) as last_updated_by,\n" +
        " (select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = wo.created_by) as created_by,\n" +
        " (select name from gets_lms_customer_orgs_v where service_organization_id = wo.service_organization_id) as service_org, wo.locomotive_id, \n" +
        " (select count(*) from gets_lms_service_sheet where service_workorder_id = wo.service_workorder_id and fmi_flag = 'Y') as fmi_exists,  \n" +
        " (select count(*) from gets_lms_material_usage where service_workorder_id = wo.service_workorder_id) as material_exists,  \n" +
        " (select count(*) from gets_lms_qa_results qa, getS_lms_qa_chars cha where qa.char_id = cha.char_id AND qa.service_Workorder_id = wo.service_workorder_id and qa.column_value is null and qa.performed_flag = 'Y' and (cha.char_type_code = 'VARIABLE' or cha.char_type_code = 'LOV') ) as open_tasks, \n" +
        " wo.service_workorder_id, wo.workorder_number, wo.workorder_status_code, obj.flt_not_processed as SDIS, \n" +
        " obj.egu_download_processed as EGU, obj.software_status, obj.cab_download_processed as CAB, obj.dcd, obj.wcd," +
        " NVL(wo.workorder_comments,'-') as workorder_comments, NVL(wo.workorder_notes,'-') as turnover_notes \n" +
        " from gets_lms_service_workorder wo, gets_lms_object_parameters obj\n" +
        "    where wo.service_workorder_id = obj.service_workorder_id(+) "
           + " and wo.service_workorder_id = " + workorderId;
       
       prepStm = conn.prepareStatement(woDetailsQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
         selectedWO = new WorkorderData(rs.getString("service_workorder_id"), 
                 rs.getString("workorder_number"), 
                 rs.getString("last_update_date"), 
                 rs.getString("last_updated_by"), 
                 rs.getString("creation_date"), 
                 rs.getString("created_by"), 
                 rs.getString("workorder_status_code"), 
                 rs.getString("inshop_reason_code"), 
                 rs.getString("out_of_shop_repair_flag"), 
                 rs.getString("service_org"), 
                 rs.getString("Locomotive_id"), 
                 rs.getString("egu"),
                 rs.getString("cab"),
                 rs.getString("sdis"),
                 rs.getString("dcd"),
                 rs.getString("wcd"),
                 rs.getString("software_status"),
                 rs.getString("workorder_comments"),
                 rs.getString("turnover_notes"));
         
         if (!"0".equals(rs.getString("fmi_exists"))) {
           btnFMIDetails.setEnabled(true);
         }
         if (!"0".equals(rs.getString("material_exists"))) {
           btnMaterials.setEnabled(true);
         }
                  
         btnTasks.setEnabled(true);          
         btnDefects.setEnabled(true);
       }
       else {
         editorResults.setText("OH GODS! SOMETHING IS WRONG WITH THIS WO, PLEASE CHECK THE LOGFILE!");
         releaseFields();
         
         buf = new StringBuffer("");
         buf.append("-- Fields --\n");
         buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
         buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
         buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");
         buf.append("txtWorkorderId: \"" + txtWorkorderId.getText() + "\"\n");
         buf.append("chkBoxWildCard checked?: \"" + chkBoxWildCard.isSelected() + "\"\n");
         buf.append("Selected WO: " + selectedWO.toString() + "\"\n");
         buf.append("Environment: " + getComboConnection() + "\"\n");
         buf.append("-- Exception --\n");
         buf.append("Could not pull workorder details.");
         JErrorLog.createErrorLog("Class: WorkorderIF, Method: fetchWOFullDetails", woDetailsQuery + "\n\n" + serviceSheetQuery + "\n\n" + serviceStatusQuery + "\n\n", buf.toString());          
         return;
       }
        
       buf.append("<HTML><BODY>"
               + "<TABLE border = 0 width= 100%>"
               + "<TR>" 
               + "   <TD align = center bgcolor=\"#92CDDC\" colspan=2><B>General Workorder Information</B></TD>"
               + "</TR>"
               + "<TR>"
               + "   <TD align = center><FONT COLOR=BLUE><B>" + selectedWO.getNumber() + " </B></FONT>(<B>" + selectedWO.getInshopReason() + ": " + util.workorder.WorkorderUtil.translateWOStatus(selectedWO.getStatus()).toUpperCase() + "</B>)</TD>" 
               + "   <TD align = center><B>Shopped in </B> " + selectedWO.getServiceOrg() + ("N".equals(selectedWO.getOutOfShopRepair()) ? "" : " <B><FONT COLOR=RED>(OOR)</FONT></B>") + "</TD>" 
               + "</TR>" 
               + "<TR>" 
               + "   <TD align=center><B>Workorder ID: </B> " + selectedWO.getId() + "</TD>" 
               + "   <TD align=center><B>Locomotive ID: </B> " + selectedWO.getLocomotiveId() + "</TD>" + "</TR>"
               + "<TR>" 
               + "   <TD colspan=2 align = center><B>Created on: </B> " + selectedWO.getCreationDate() + ", <B>By: </B>" + selectedWO.getCreatedBy() +"</TD>" 
               + "</TR>"
               + "<TR>" 
               + "   <TD colspan=2 align = center><B>Last Upd on: </B> " + selectedWO.getLastUpdateDate() + ", " + "<B>By: </B>" + selectedWO.getLastUpdatedBy() + "</TD>" 
               + "</TR>"                
               + "<TR>" 
               + "   <TD colspan=2 ><B>Workorder Comments: </B> " + selectedWO.getWoComments() + "</TD>" 
               + "</TR>"                
               + "<TR>" 
               + "   <TD colspan=2 ><B>Turnover Notes: </B> " + selectedWO.getTurnoverNotes() + "</TD>" 
               + "</TR>"                               
               + "</TABLE>");
         
       //Did we get a null? Then it does not exist in the gets_lms_object_parameters       
       if(Integer.parseInt(selectedWO.getStatus()) <= 700){
           buf.append("<TABLE width = 100%>"
                   + "<TR>"
                   + "  <TD align=center  bgcolor=\"#92CDDC\"><B>SDIS</B></TD>"
                   + "  <TD align=center  bgcolor=\"#92CDDC\"><B>CAB</B></TD>"
                   + "  <TD align=center  bgcolor=\"#92CDDC\"><B>EGU</B></TD>"
                   + "  <TD align=center  bgcolor=\"#92CDDC\"><B>DCD/WCD</B></TD>"
                   + "  <TD align=center  bgcolor=\"#92CDDC\"><B>SW</B></TD>"
                   + "</TR>");
           buf.append("<TR>"
                   + "  <TD align=center ><IMG SRC=\"" + selectedWO.getSdis() + "\"></IMG></TD>"
                   + "  <TD align=center ><IMG SRC=\"" + selectedWO.getCab() + "\"></IMG></TD>"
                   + "  <TD align=center ><IMG SRC=\"" + selectedWO.getEgu() + "\"></IMG></TD>"
                   + "  <TD align=center ><IMG SRC=\"" + selectedWO.validateDCDWCD() + "\"></IMG></TD>"
                   + "  <TD align=center ><IMG SRC=\"" + selectedWO.getSoftware() + "\"></IMG></TD>"
                   + "</TR>"
                   + "</TABLE>");                      
       }
       
       prepStm.close();
       rs.close();       
        
       buf.append("<BR><TABLE width=100%><TR>"
               + "   <TD colspan=4 ALIGN=\"CENTER\" bgcolor=\"#92CDDC\"><B>Service Status Information</B></TD>"
               + "</TR>");         
       buf.append("<TR>"
               + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Seq</B></TD>"
               + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Code</B></TD>"
               + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Status Date</B></TD>"
               + "   <TD ALIGN=\"CENTER\"  bgcolor=\"#92CDDC\"><B>Status By</B></TD>"
               + "</TR>");
       
       serviceStatusQuery = "select ss.status_sequence, ss.status_code, to_char(ss.status_date, 'DD-Mon-yyyy HH24:MI:SS') as status_date, "
               + "(select employee_firstname || ' ' || employee_lastname || ' (' || user_name || ')' from gets_lms_service_employee where user_id = ss.last_updated_by) as status_by, "
               + "wo_ss_id "
               + "from gets_lms_service_status ss where ss.wo_ss_id = " + selectedWO.getId() + "and ss.status_type_code = 'WORKORDER' order by ss.status_sequence asc ";
 
       prepStm = conn.prepareStatement(serviceStatusQuery);
       rs = prepStm.executeQuery();
       
       int row = 0;
       if (rs.next()) {
         do {
           buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                   + "   <TD align=center>" + rs.getString("status_sequence") + "</TD>" 
                   + "   <TD align=center>" + rs.getString("status_code") + "</TD>" 
                   + "   <TD align=center>" + rs.getString("status_date") + "</TD>" 
                   + "   <TD align=center>" + rs.getString("status_by") + "</TD>" 
                   + "</TR>"); 
           row++;
         }
         while (rs.next());
       } else {
         buf.append("No Service Status for this workorder, something is wrong.");
       }
       buf.append("</TABLE>");
       
       prepStm.close();
       rs.close();       
 
       serviceSheetQuery = "select ss.service_sheet_id, ss.locomotive_id, ss.service_type_code, ss.service_sheet_comments, "
               + " ss.service_sheet_status_code, ss.fmi_flag, ss.due_flag, ss.profile_id, ss.fmi_id, "
               + " (select max(fmi_number) from gets_fmi_entries where fmi_id = ss.fmi_id) as fmi_number, "
               + " (select max(profile_approve_status) from gets_fmi_profile where profile_id = ss.profile_id) as profile_status,"
               + " NVL((select service_item from ESV_WRKSCPE.ESV_SERVICE_ITEM where service_item_id = ss.service_item_id), '-') as service_item \n"
               + "from gets_lms_service_sheet ss where ss.service_workorder_id = " + selectedWO.getId();
       
       buf.append("<BR><TABLE border = 0 width = 100%>"
               + "<TR>"
               + "   <TD colspan=6  bgcolor=\"#92CDDC\" align=center><B>Service Sheet Information</B></TD>"
               + "</TR>");
       
       buf.append("<TR>"
               + "<TD align=\"center\" width=10% bgcolor=\"#92CDDC\"><B>SS ID</B></TD>"
               + "<TD align=\"center\" width=10% bgcolor=\"#92CDDC\"><B>Type</B></TD>"
               + "<TD align=\"center\" width=40% bgcolor=\"#92CDDC\"><B>Service Sheet Comments</B></TD>"
               + "<TD align=\"center\" width=10% bgcolor=\"#92CDDC\"><B>Status</B></TD>"
               + "<TD align=\"center\" width=10% bgcolor=\"#92CDDC\"><B>Due?</B></TD>"
               + "<TD align=\"center\" width=20% bgcolor=\"#92CDDC\"><B>Service Item / FMI</B></TD>"
               + "</TR>");
 
       prepStm = conn.prepareStatement(serviceSheetQuery);
       rs = prepStm.executeQuery();
       
       if (rs.next()) {
           row = 0;
         do {
               buf.append("<TR " + (row % 2 == 0 ? "" : " bgcolor=#DDDDDD " + ">")
                   + "<TD align=\"center\" >" + (!rs.getString("locomotive_id").equals(selectedWO.getLocomotiveId()) ? "<FONT COLOR=\"RED\"><B>" + rs.getString("service_sheet_id") + "</B>" : rs.getString("service_sheet_id")) + "</TD>\n" 
                   + "   <TD align=\"center\" >" + rs.getString("service_type_code") + "</TD>" 
                   + "   <TD>" + (null == rs.getString("service_sheet_comments") ? "" : rs.getString("service_sheet_comments")) + "</TD>" 
                   + "   <TD align=\"CENTER\">" + util.servicesheet.ServiceSheetUtil.translateSSStatus(rs.getString("service_sheet_status_code")) + "</TD>" 
                   + "   <TD align=\"center\" >" + rs.getString("due_flag") + "</TD>" 
                   + "   <TD align=\"center\" >" + ("Y".equals(rs.getString("FMI_FLAG")) ? "<B>" + rs.getString("fmi_number") + "</B>" + " (" + rs.getString("fmi_id") + "), <B>Profile id:</B> " + (("900".equals(rs.getString("profile_status"))) || ("800".equals(rs.getString("profile_status"))) || ("400".equals(rs.getString("profile_status"))) ? "<FONT COLOR = RED>" + rs.getString("profile_id") + "</FONT>" : rs.getString("profile_id")) 
                           : rs.getString("service_item")) + "</TD>"
                   + "" + "</TR>");
               row++;
         }
         while (rs.next());
       } else {
         buf.append("<TR><TD colspan = 6>No Service Sheets found for this workorder.</TD></TR>");
       }
       
       buf.append("</TABLE></BODY></HTML>");
       editorResults.setText(buf.toString());
       releaseFields();
     }
     catch (Exception e) {
       buf = new StringBuffer("");
       buf.append("-- Fields --\n");
       buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
       buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
       buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");
       buf.append("txtWorkorderId: \"" + txtWorkorderId.getText() + "\"\n");
       buf.append("chkBoxWildCard checked?: " + chkBoxWildCard.isSelected() + "\"\n");
       buf.append("Selected WO: " + selectedWO.toString() + "\"\n");
       buf.append("Environment: " + getComboConnection() + "\"\n");
       buf.append("-- Exception --\n");
       buf.append("Exception info:" + e.getMessage());
       JErrorLog.createErrorLog("Class: WorkorderIF, Method: fetchWOFullDetails", woDetailsQuery + "\n\n" + serviceSheetQuery + "\n\n" + serviceStatusQuery + "\n\n", buf.toString());
       
       editorResults.setText("An Error occurred, please check the logs.");
       releaseFields();
     }
   }
   
    private void fetchWOListing(){
        String woListQuery = "";
        try {
            done = false;            
            protectFields();
            model.clear();
            DefaultListModel tempModel = new DefaultListModel(); //Bug with refresh and concurrency, needed to show the listing            
            buf = new StringBuffer();
            workorders.clear();
            
            //Disable the buttons
            btnFMIDetails.setEnabled(false);
            btnMaterials.setEnabled(false);
            btnDefects.setEnabled(false);
            btnTasks.setEnabled(false);
            
            editorResults.setText("<HTML><H3>Fetching workorder list...</H3></HTML>");
            
            //Fetch the wo list Information first
            conn = OracleConnectionManager.getConnection(getComboConnection());
            
            if (conn == null) {
              editorResults.setText("<HTML><H2>Database Connection could not be established, please check your network status.</H2></HTML>");
              releaseFields();
              return;
            }            
            
            woListQuery = "SELECT wo.service_workorder_id, wo.workorder_number, wo.workorder_status_code from gets_lms_service_workorder wo, gets_lms_locomotive_all la\n" +
                "WHERE la.locomotive_id = wo.locomotive_id\n" +
                (txtAARRoad.getText().trim().toLowerCase().isEmpty() || txtAARRoad.getText().trim().toLowerCase().equals("aar road") ? 
                   "" : " and lower(la.aar_road) " + (chkBoxWildCard.isSelected() ? " like " : " = ") + "'" + txtAARRoad.getText().trim().toLowerCase() + "'") + 
                (txtRoadNumber.getText().trim().toLowerCase().isEmpty() || txtRoadNumber.getText().trim().toLowerCase().equals("rn") ? 
                   "" : " and lower(la.road_Number) " + (chkBoxWildCard.isSelected() ? " like " : " = ") + "'" + txtRoadNumber.getText().trim().toLowerCase() + "'") + 
                (txtLocomotiveId.getText().trim().toLowerCase().isEmpty() || txtLocomotiveId.getText().trim().toLowerCase().equals("locomotive id") ? 
                   "" : " and lower(la.locomotive_id) " + (chkBoxWildCard.isSelected() ? " like " : " = ") + "'" + txtLocomotiveId.getText().trim().toLowerCase() +  "'") + 
                    " order by wo.customer_id, wo.service_workorder_id desc"; 
                        
            prepStm = conn.prepareStatement(woListQuery);
            rs = prepStm.executeQuery();
                                    
            if(rs.next()){
                do {
                    workorders.add(new WorkorderData(rs.getString("service_workorder_id"),
                    rs.getString("workorder_number"), rs.getString("workorder_status_code")));                    
                    tempModel.addElement(new WorkorderData(rs.getString("service_workorder_id"),rs.getString("workorder_number"), rs.getString("workorder_status_code")));
                } while(rs.next());
            } else  {                                
                tempModel.addElement(new WorkorderData("0","No WOs for that unit.", "0"));
                //listWO.setModel(tempModel);              
            }
                                    
            prepStm.close();
            rs.close();
            listWO.setModel(tempModel);            
            releaseFields();
            editorResults.setText("<HTML><H3>Please double click on a workorder to fetch its details.</H3></HTML>");
            done = true;
            
        }catch(Exception e){
             //------- Logging begins ----------------
             buf = new StringBuffer("");
             buf.append("-- Fields --\n");
             buf.append("txtAARRoad: \"" + txtAARRoad.getText() + "\"\n");
             buf.append("txtRoadNumber: \"" + txtRoadNumber.getText() + "\"\n");
             buf.append("txtLocomotiveId: \"" + txtLocomotiveId.getText() + "\"\n");
             buf.append("txtWorkorderId: \"" + txtWorkorderId.getText() + "\"\n");
             buf.append("chkBoxWildCard checked?: " + chkBoxWildCard.isSelected() + "\"\n");
             buf.append("Selected WO: " + selectedWO.toString() + "\"\n");
             buf.append("Environment: " + getComboConnection() + "\"\n");
             buf.append("-- Exception --\n");
             buf.append("Exception info:" + e.getMessage());
             JErrorLog.createErrorLog("Class: WorkorderIF, Method: fetchWOListing",
                 woListQuery, buf.toString());
             //------- Logging ends ----------------   
             editorResults.setText("An error occurred, please check the logs.");
             releaseFields();
        }           
    }
        
    private int getComboConnection(){
        switch(comboEnvironment.getSelectedIndex()){
            case 0: 
                return OracleConnectionManager.PROD;
            case 1: 
                return OracleConnectionManager.STG;
            case 2: 
                return OracleConnectionManager.DEV;
            case 3:
                return OracleConnectionManager.INT_DEV;
            default:
                return OracleConnectionManager.PROD;
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDefects;
    private javax.swing.JButton btnFMIDetails;
    private javax.swing.JButton btnFetchWODetails;
    private javax.swing.JButton btnFetchWOList;
    private javax.swing.JButton btnMaterials;
    private javax.swing.JButton btnTasks;
    private javax.swing.JCheckBox chkBoxWildCard;
    private javax.swing.JComboBox comboEnvironment;
    private javax.swing.JEditorPane editorResults;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listWO;
    private javax.swing.JScrollPane scrollWOList;
    private javax.swing.JTextField txtAARRoad;
    private javax.swing.JTextField txtLocomotiveId;
    private javax.swing.JTextField txtRoadNumber;
    private javax.swing.JTextField txtWorkorderId;
    // End of variables declaration//GEN-END:variables
}

//GE Confidential